<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fumigation extends Model
{
    protected $table = 'fumigation';
}
