<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AccountGroups extends Model
{
    //
    protected $table = 'account_groups';
    
}
