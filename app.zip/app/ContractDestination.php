<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContractDestination extends Model
{
    //
    protected $table = 'contract_destination';
}
