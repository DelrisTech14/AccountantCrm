<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FumigationDosage extends Model
{
    protected $table = 'fumigation_dosage';
}
