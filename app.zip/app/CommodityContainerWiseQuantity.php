<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommodityContainerWiseQuantity extends Model
{
    protected $table = 'commodity_container_wise_quantity';
}
