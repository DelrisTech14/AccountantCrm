<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AccountCommodityWiseDefault extends Model
{
    protected $table = 'account_commodity_wise_default';
}
