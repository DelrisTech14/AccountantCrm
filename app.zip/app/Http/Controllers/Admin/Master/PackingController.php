<?php

namespace App\Http\Controllers\Admin\Master;

use App\Http\Controllers\Controller;
use App\Packing;
use Illuminate\Http\Request;

class PackingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Packing  $packing
     * @return \Illuminate\Http\Response
     */
    public function show(Packing $packing)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Packing  $packing
     * @return \Illuminate\Http\Response
     */
    public function edit(Packing $packing)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Packing  $packing
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Packing $packing)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Packing  $packing
     * @return \Illuminate\Http\Response
     */
    public function destroy(Packing $packing)
    {
        //
    }
}
