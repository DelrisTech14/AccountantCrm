<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuantityIn extends Model
{
    //
    protected $table = 'quantity_in';

}
