<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpensesName extends Model
{
    //
    protected $table = 'expenses_name';

}
