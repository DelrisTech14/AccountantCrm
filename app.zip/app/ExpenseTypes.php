<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpenseTypes extends Model
{
    //
    protected $table = 'expense_types';

}
