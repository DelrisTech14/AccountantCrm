<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tolerance extends Model
{
    //
    protected $table = 'tolerance';

}
