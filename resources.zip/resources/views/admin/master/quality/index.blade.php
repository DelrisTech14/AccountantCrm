@extends('adminlte::page')

@section('title', 'Dhaval Agri | Quality')

@section('content_header')
<h1>Quality</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <div id="error_msg"></div>
        {{ Form::open(['id' => 'save_quality', 'method' => 'post', 'enctype' => 'multipart/form-data', 'data-parsley-validate' => '']) }}
        {{ csrf_field() }}
        {{ Form::hidden('id', $quality_data->id ?? '', ['id' => 'quality_id']) }}
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    {{ Form::label('commodity_id', 'Commodity', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                    <select class="form-control" id="commodity_id" name="commodity_id"></select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    {{ Form::label('quality', 'Quality', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                    {{ Form::text('quality', $quality_data->quality ?? '', ['class' => 'form-control', 'required' => 'required', 'autofocus' => 'autofocus']) }}
                </div>
            </div>
            <div class="col-md-2">
                <label>&nbsp;</label><br>
                {{ Form::submit('Save', ['class' => 'btn btn-primary module_save_btn']) }}
            </div>
        </div>
        {{ Form::close() }}
    </div>
</div>
<div class="card">
    <div class="card-body">
        @include ('error')

        <div class="table-responsive">
            <table id="dataTable-quality" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="100px">Action</th>
                        <th>Commodity</th>
                        <th>Quality</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        <div class="modal fade" id="deleteQualityModel" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Confirmation</h4>
                    </div>
                    <form action="{{url('admin/QualityDelete')}}" method="post" id="dform">
                        <div class="modal-body">
                            <p>Are you sure you want remove this Quality ?</p>
                            @csrf
                            <input type="hidden" name="delete_quality_id" id="delete_quality_id">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Yes</button>
                            <button type="button" class="btn btn-default btn-outline" data-dismiss="modal">No</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
        var qualityTable;
        $(document).ready( function(){
            initAjaxSelect2($("#commodity_id"), "{{ URL::to('/commodity_select2_source') }}");
            $(document).on('submit', '#save_quality', function(){
                var postData = new FormData(this);
                $('.module_save_btn').attr('disabled', 'disabled');
                $.ajax({
                    url: "{{ URL::to('/admin/save_quality') }}",
                    type: "POST",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: postData,
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#error_msg').html('');
                        if (json['errors']) {
                            var error_msg_html = '<div class="alert alert-danger"><ul>';
                            $(json['errors']).each(function( index,value ) {
                                error_msg_html += '<li>'+value+'</li>';
                            });
                            error_msg_html += '</ul></div>';
                            $('#error_msg').html(error_msg_html);
                        } else if (json['success'] == 'Added') {
                            $('#commodity_id').val(null).trigger('change');
                            $('#quality').val('');
                            qualityTable.draw();
                            bootbox.alert('<span class="text-success">Quality Successfully Created</span>');
                        } else if (json['success'] == 'Updated') {
                            $('#quality_id').val('');
                            $('#commodity_id').val(null).trigger('change');
                            $('#quality').val('');
                            qualityTable.draw();
                            bootbox.alert('<span class="text-success">Quality Successfully Updated</span>');
                            $('.module_save_btn').val('Save');
                        } else {
                            bootbox.alert('<span class="text-danger">Something error occurred</span>');
                            return false;
                        }
                        return false;
                    },
                });
                return false;
            });

            $(document).on('click', '.edit_quality', function(){
                $('#commodity_id').val(null).trigger('change');
                var quality_id = $(this).attr('data-quality_id');
                $.ajax({
                    url: "quality/" + quality_id + "/edit",
                    type: "GET",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: {},
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#quality_id').val(json['quality_data'].id);
                        setSelect2Value($("#commodity_id"),"{{ URL::to('/set_commodity_select2_val_by_id') }}/" + json['quality_data'].commodity_id);
                        $('#quality').val(json['quality_data'].quality);
                        $('.module_save_btn').val('Update');
                        $("html, body").animate({scrollTop: 0}, "slow");
                        return false;
                    },
                });
                return false;
            });

            $(document).on('click', '.delete_quality', function(){
                var delete_quality_id = $(this).attr('data-quality_id');
                $('#delete_quality_id').val(delete_quality_id);
                $('#deleteQualityModel').modal('show');
                return false;
            });

            qualityTable = $('#dataTable-quality').DataTable({
                "bServerSide": true,
                "processing": true,
                "bRetrieve": true,
                "pageLength": 10,
                "ajax": {
                    "url": "{{ URL::to('/admin/getQualityDatatable/') }}",
                    "type": "GET",
                    "data": function (d) {
//                        d.quality_id = $('#quality_id').val();
                    },
                },
                "columns": [{
                    "data": 'id',
                    "sClass": 'text-nowrap',
                    "render": function( data, type, full, meta ) {
                        var edit_button = '<button class="btn btn-sm btn-info edit_quality" data-quality_id="'+ data +'"><i class="fa far fa-edit"></i></button>';
                        var delete_button = '<button class="btn btn-sm btn-danger delete_quality" data-quality_id="'+ data +'" title="Delete"><span class="fa fa-times-circle"></span></button>';
                        return edit_button + ' ' + delete_button;
                    }
                }, {
                    "data": "commodity_name",
                    "defaultContent": '-',
                    "searchable": false,
                }, {
                    "data": "quality",
                    "defaultContent": '-',
                    "searchable": false,
                }
                ],
                "ordering": false,
                "searching": false,
            });
        });
    </script>
@stop