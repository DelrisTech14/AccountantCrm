@extends('adminlte::page')

@section('title', 'Dhaval Agri | Exchange Rate')

@section('content_header')
<h1>Exchange Rate</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <div id="error_msg"></div>
        {{ Form::open(['id' => 'save_exchange_rate', 'method' => 'post', 'enctype' => 'multipart/form-data', 'data-parsley-validate' => '']) }}
        {{ csrf_field() }}
        {{ Form::hidden('id', '', ['id' => 'exchange_rate_id']) }}
        <div class="row">
            <div class="col-md-2">
                <div class="form-group">
                    {{ Form::label('from_rate', 'From Rate', ['class' => 'control-label']) }} <span class="text-danger"></span>
                    {{ Form::text('from_rate', '1', ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly', 'autofocus' => 'autofocus']) }}
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    {{ Form::label('from_currency_id', 'From Currency', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                    <select name="from_currency_id" id="from_currency_id" class="form-control select2" ></select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    {{ Form::label('to_currency_id', 'To Currency', ['class' => 'control-label']) }} <span class="text-danger"></span>
                    {{ Form::text('to_currency_id', 'INR', ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly', 'autofocus' => 'autofocus']) }}
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    {{ Form::label('to_rate', 'To Rate', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                    {{ Form::text('to_rate', '', ['class' => 'form-control', 'required' => 'required', 'autofocus' => 'autofocus']) }}
                </div>
            </div>
            <div class="col-md-2">
                <label>&nbsp;</label><br>
                {{ Form::submit('Save', ['class' => 'btn btn-primary module_save_btn']) }}
            </div>
        </div>
        {{ Form::close() }}
    </div>
</div>
<div class="card">
    <div class="card-body">
        @include ('error')

        <div class="table-responsive">
            <table id="dataTable-exchange_rate" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="100px">Action</th>
                        <th class="text-right">From Rate</th>
                        <th>From Currency</th>
                        <th>To Currency</th>
                        <th class="text-right">To Rate</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
    var exchange_rateTable;
        $(document).ready( function(){
            initAjaxSelect2($("#from_currency_id"), "{{ URL::to('/currency_select2_source') }}");

            $(document).on('submit', '#save_exchange_rate', function(){
                var postData = new FormData(this);
                $('.module_save_btn').attr('disabled', 'disabled');
                $.ajax({
                    url: "{{ URL::to('/admin/save_exchange_rate') }}",
                    type: "POST",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: postData,
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#error_msg').html('');
                        if (json['errors']) {
                            var error_msg_html = '<div class="alert alert-danger"><ul>';
                            $(json['errors']).each(function( index,value ) {
                                error_msg_html += '<li>'+value+'</li>';
                            });
                            error_msg_html += '</ul></div>';
                            $('#error_msg').html(error_msg_html);
                        } else if (json['success'] == 'Added') {
                            $('#from_currency_id').val(null).trigger('change');
                            $('#to_rate').val('');
                            exchange_rateTable.draw();
                            bootbox.alert('<span class="text-success">Exchange Rate Successfully Created</span>');
                        } else if (json['success'] == 'Updated') {
                            $('#exchange_rate_id').val('');
                            $('#from_currency_id').val(null).trigger('change');
                            $('#to_rate').val('');
                            exchange_rateTable.draw();
                            bootbox.alert('<span class="text-success">Exchange Rate Successfully Updated</span>');
                            $('.module_save_btn').val('Save');
                        } else {
                            bootbox.alert('<span class="text-danger">Something error occurred</span>');
                            return false;
                        }
                        return false;
                    },
                });
                return false;
            });

            $(document).on('click', '.edit_exchange_rate', function(){
                var exchange_rate_id = $(this).attr('data-exchange_rate_id');
                $.ajax({
                    url: "currency/" + exchange_rate_id + "/edit",
                    type: "GET",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: {},
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#exchange_rate_id').val(json['currency_data'].id);
                        setSelect2Value($("#from_currency_id"),"{{ URL::to('/set_currency_select2_val_by_id') }}/" + json['currency_data'].id);
                        $('#to_rate').val(json['currency_data'].in_inr);
                        $('.module_save_btn').val('Update');
                        $("html, body").animate({scrollTop: 0}, "slow");
                        return false;
                    },
                });
                return false;
            });

            exchange_rateTable = $('#dataTable-exchange_rate').DataTable({
                "bServerSide": true,
                "processing": true,
                "bRetrieve": true,
                "pageLength": 10,
                "ajax": {
                    "url": "{{ URL::to('/admin/getCurrencyDatatable/') }}",
                    "type": "GET",
                    "data": function (d) {
//                        d.exchange_rate_id = $('#exchange_rate_id').val();
                    },
                },
                "columns": [{
                    "data": 'id',
                    "sClass": 'text-nowrap',
                    "render": function( data, type, full, meta ) {
                        var edit_button = '<button class="btn btn-sm btn-info edit_exchange_rate" data-exchange_rate_id="'+ data +'"><i class="fa far fa-edit"></i></button>';
                        return edit_button;
                    }
                }, {
                    "defaultContent": '1',
                    "searchable": false,
                    "sClass": 'text-right',
                }, {
                    "data": "currency",
                    "defaultContent": '-',
                    "searchable": false,
                }, {
                    "defaultContent": 'INR',
                    "searchable": false,
                }, {
                    "data": "in_inr",
                    "defaultContent": '-',
                    "searchable": false,
                    "sClass": 'text-right',
                }],
                "ordering": false,
                "searching": false,
            });
        });
    </script>
@stop