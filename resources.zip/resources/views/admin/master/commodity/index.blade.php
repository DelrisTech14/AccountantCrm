@extends('adminlte::page')

@section('title', 'Dhaval Agri | Commodity')

@section('content_header')
<h1>Commodity</h1>
@stop

@section('css')
    <link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        @include ('error')

        <p class="float-right">
            <a class="btn btn-primary" href="{{ url('admin/commodity/create') }}"><i class="fa fa-plus"></i> Create Commodity</a>
        </p>
        <div class="table-responsive">
            <table id="dataTable-commodity" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="100px">Action</th>
                        <th>Commodity</th>
                        <th>Quantity Unit</th>
                        <th>Price Unit</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
        <div class="modal fade" id="deleteCommodityModel" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Confirmation</h4>
                    </div>
                    <form action="{{url('admin/CommodityDelete')}}" method="post" id="dform">
                        <div class="modal-body">
                            <p>Are you sure you want remove this Commodity?</p>
                            @csrf
                            <input type="hidden" name="delete_commodity_id" id="delete_commodity_id">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Yes</button>
                            <button type="button" class="btn btn-default btn-outline" data-dismiss="modal">No</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
</div>
@stop

@section('js')
<script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
<script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
<script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
<script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
<script>
    var commodityTable;
    $(document).ready(function () {

        $(document).on('click', '.delete_commodity', function () {
            var delete_commodity_id = $(this).attr('data-commodity_id');
            $('#delete_commodity_id').val(delete_commodity_id);
            $('#deleteCommodityModel').modal('show');
            return false;
        });

        commodityTable = $('#dataTable-commodity').DataTable({
            "bServerSide": true,
            "processing": true,
            "bRetrieve": true,
            "pageLength": 10,
            "ajax": {
                "url": "{{ URL::to('/admin/getCommodityDatatable/') }}",
                "type": "GET",
                "data": function (d) {
    //                        d.commodity_id = $('#commodity_id').val();
                },
            },
            "columns": [{
                "data": 'id',
                "sClass": 'text-nowrap',
                "render": function( data, type, full, meta ) {
                    var edit_button = ''; // '<button class="btn btn-sm btn-info edit_commodity" data-commodity_id="'+ data +'"><i class="fa far fa-edit"></i></button>';
                    var delete_button = '<button class="btn btn-sm btn-danger delete_commodity" data-commodity_id="'+ data +'" title="Delete"><span class="fa fa-times-circle"></span></button>';
                    return edit_button + ' ' + delete_button;
                }
            }, {
                "data": "name",
                "defaultContent": '-',
                "searchable": false,
            }, {
                "data": "quantity_unit",
                "defaultContent": '-',
                "searchable": false,
            }, {
                "data": "price_unit",
                "defaultContent": '-',
                "searchable": false,
            }],
            "ordering": false,
            "searching": false,
        });
    });
</script>
@stop