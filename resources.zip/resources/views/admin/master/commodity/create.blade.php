@extends('adminlte::page')

@section('title', 'Dhaval Agri | Commodity')

@section('content_header')
<h1>Commodity</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        @include ('error')
        <form id="commodity_form" method="post" action="{{ url('admin/commodity') }}">
            {{ csrf_field() }}
            <div class="row">
                  <div class="col-md-4">
                      <div class="form-group">
                          {{ Form::label('commodity_name', 'Commodity Name', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                          {{ Form::text('commodity_name','', ['id' => 'commodity_name', 'class' => 'form-control', 'placeholder' => 'Commodity Name']) }}
                          <p class="error_msg text-danger d-none">@error('commodity_name'){{$message}}@enderror</p>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          {{ Form::label('quantity_unit_id', 'Quantity Unit', ['class' => 'control-label']) }}<span class="text-danger">*</span>
                          <select name="quantity_unit_id" id="quantity_unit_id" class="form-control select2" ></select>
                          <p class="error_msg text-danger d-none">@error('quantity_unit_id'){{$message}}@enderror</p>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          {{ Form::label('price_unit_id', 'Price Unit', ['class' => 'control-label']) }}<span class="text-danger">*</span>
                          <select name="price_unit_id" id="price_unit_id" class="form-control select2" ></select>
                          <p class="error_msg text-danger d-none">@error('price_unit_id'){{$message}}@enderror</p>
                      </div>
                  </div>
                  <div class="col-md-4"><br>
                      {{ Form::submit('Save', ['class' => 'btn btn-primary module_save_btn']) }}
                  </div>
            </div>
        </form>
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
        $(document).ready( function(){
            initAjaxSelect2($("#quantity_unit_id"), "{{ URL::to('/quantity_in_select2_source') }}");
            initAjaxSelect2($("#price_unit_id"), "{{ URL::to('/quantity_in_select2_source') }}");

            $(document).on('submit', '#save_commodity', function(){
                var postData = new FormData(this);
                $('.module_save_btn').attr('disabled', 'disabled');
                $.ajax({
                    url: "{{ URL::to('/admin/save_commodity') }}",
                    type: "POST",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: postData,
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#error_msg').html('');
                        if (json['errors']) {
                            var error_msg_html = '<div class="alert alert-danger"><ul>';
                            $(json['errors']).each(function( index,value ) {
                                error_msg_html += '<li>'+value+'</li>';
                            });
                            error_msg_html += '</ul></div>';
                            $('#error_msg').html(error_msg_html);
                        } else if (json['success'] == 'Added') {
                            $('#commodity_name').val('');
                            bootbox.alert('<span class="text-success">City Successfully Created</span>');
                        } else if (json['success'] == 'Updated') {
                            $('#commodity_id').val('');
                            $('#commodity_name').val('');
                            bootbox.alert('<span class="text-success">City Successfully Updated</span>');
                            $('.module_save_btn').val('Save');
                        } else {
                            bootbox.alert('<span class="text-danger">Something error occurred</span>');
                            return false;
                        }
                        return false;
                    },
                });
                return false;
            });

            $(document).on('click', '.edit_commodity', function(){
                var commodity_name_id = $(this).attr('data-commodity_id');
                $.ajax({
                    url: "commodity/" + commodity_name_id + "/edit",
                    type: "GET",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: {},
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#commodity_id').val(json['commodity_data'].id);
                        $('#commodity_name').val(json['commodity_data'].commodity_name);
                        $('.module_save_btn').val('Update');
                        $("html, body").animate({scrollTop: 0}, "slow");
                        return false;
                    },
                });
                return false;
            });
        });
    </script>
@stop