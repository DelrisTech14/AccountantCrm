{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dhaval Agri | Expense')

@section('content_header')
<h1>Expense</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
<style>
    div.dataTables_wrapper div.dataTables_length select {
    width: 100%;
  }
</style>
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <div id="error_msg"></div>
        {{ Form::open(['id' => 'save_expense', 'method' => 'post', 'enctype' => 'multipart/form-data', 'data-parsley-validate' => '']) }}
        {{ csrf_field() }}
        {{ Form::hidden('id', $document_data->id ?? '', ['id' => 'document_id']) }}
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    {{ Form::label('buyer_id', 'Buyer', ['class' => 'control-label']) }}
                    <select class="form-control select2" id="buyer_id" name="buyer_id"></select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    {{ Form::label('commodity_id', 'Commodity', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                    <select class="form-control select2" id="commodity_id" name="commodity_id"></select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    {{ Form::label('container_type_id', 'Container Type', ['class' => 'control-label']) }} <span class="text-danger"></span>
                    <select class="form-control select2" id="container_type_id" name="container_type_id"></select>
                </div>
            </div>
            <div class="col-md-4 lab_selection_check_div">
                <div class="form-group">
                    <label></label><br>
                    <div class="checkbox icheck-success">
                        <input type="checkbox" name="is_lab_expense" id="is_lab_expense" />
                        <label for="is_lab_expense">Is Lab Expense?</label>
                    </div>
                </div>
            </div>
            <div class="col-md-2 lab_selection d-none">
                <div class="form-group">
                    {{ Form::label('lab_id', 'Lab', ['class' => 'control-label']) }} <span class="text-danger"></span>
                    <select class="form-control select2" id="lab_id" name="lab_id"></select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    {{ Form::label('expenses_name_id', 'Expenses Name', ['class' => 'control-label']) }} <span class="text-danger"></span>
                    <select class="form-control select2" id="expenses_name_id" name="expenses_name_id"></select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    {{ Form::label('expense_type_id', 'Expense Type', ['class' => 'control-label']) }} <span class="text-danger"></span>
                    <select class="form-control select2" id="expense_type_id" name="expense_type_id"></select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2 quantity_in_selection d-none">
                <div class="form-group">
                    {{ Form::label('quantity_in_id', 'Quantity In', ['class' => 'control-label']) }}
                    <select class="form-control select2" id="quantity_in_id" name="quantity_in_id"></select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    {{ Form::label('rate', 'Rate', ['class' => 'control-label']) }}
                    {{ Form::text('rate', '', ['class' => 'form-control positive_num_only', 'placeholder' => 'Rate ']) }}
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    {{ Form::label('currency_id', 'Currency', ['class' => 'control-label']) }}
                    <select class="form-control select2" id="currency_id" name="currency_id"></select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    {{ Form::label('gst', 'GST', ['class' => 'control-label']) }}
                    <select class="form-control select2" id="gst" name="gst"></select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label>&nbsp;</label><br>
                {{ Form::submit('Save', ['class' => 'btn btn-primary module_save_btn']) }}
            </div>
        </div>
        {{ Form::close() }}
    </div>
</div>
<div class="card">
    <div class="card-body">
        @include ('error')

        <div class="table-responsive">
            <table id="dataTable-Expense" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="100px">Action</th>
                        <th>Buyer</th>
                        <th>Commodity</th>
                        <th>Container Type</th>
                        <th>Is Lab?</th>
                        <th>Lab</th>
                        <th>Expenses Name</th>
                        <th>Expense Type</th>
                        <th>Quantity In</th>
                        <th>Rate</th>
                        <th>Currency</th>
                        <th>GST</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        <div class="modal fade" id="deletedocumentModel" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Confirmation</h4>
                    </div>
                    <form action="{{url('admin/DocumentDelete')}}" method="post" id="dform">
                        <div class="modal-body">
                            <p>Are you sure you want remove this document?</p>
                            @csrf
                            <input type="hidden" name="delete_document_id" id="delete_document_id">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Yes</button>
                            <button type="button" class="btn btn-default btn-outline" data-dismiss="modal">No</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
        var ExpenseTable;
        var expense_type_id_weights = '<?php echo Config::get('constants.EXPENSE_TYPES.ID_WEIGHTS'); ?>';
        $(document).ready( function(){
            
            $("#buyer_id").attr("data-placeholder","Common");
            var account_group_id_buyer = ["<?= Config::get('constants.ACCOUNT_GROUP.ID_BUYER') ?>"];
            initAjaxSelect2($("#buyer_id"), "{{ URL::to('/account_select2_source') }}/?ids="  + account_group_id_buyer);
            initAjaxSelect2($("#commodity_id"), "{{ URL::to('/commodity_select2_source') }}");
            initAjaxSelect2($("#container_type_id"), "{{ URL::to('/container_type_select2_source') }}");
            initAjaxSelect2($("#currency_id"), "{{ URL::to('/currency_select2_source') }}");
            initAjaxSelect2($("#expense_type_id"), "{{ URL::to('/expense_type_select2_source') }}");
            initAjaxSelect2($("#expenses_name_id"), "{{ URL::to('/expenses_name_select2_source') }}");
            initAjaxSelect2($("#lab_id"), "{{ URL::to('/lab_select2_source') }}");
            initAjaxSelect2($("#gst"), "{{ URL::to('/gst_select2_source') }}");
            initAjaxSelect2($("#quantity_in_id"), "{{ URL::to('/quantity_in_select2_source') }}");
            
            
            $(document).on('change', '#commodity_id', function(){
                ExpenseTable.draw();
            });
            $(document).on('change', '#container_type_id', function(){
                ExpenseTable.draw();
            });
            $(document).on('change', '#buyer_id', function(){
                ExpenseTable.draw();
            });
            
            $(document).on('change', '#is_lab_expense', function(){
                $(".lab_selection").addClass('d-none');
                $(".lab_selection_check_div").addClass('col-md-4');
                $(".lab_selection_check_div").removeClass('col-md-2');
                if($("#is_lab_expense").is(':checked')){  // checked
                    $(".lab_selection").removeClass('d-none');
                    $(".lab_selection_check_div").removeClass('col-md-4');
                    $(".lab_selection_check_div").addClass('col-md-2');
                }
            });

            $(document).on('change', '#expense_type_id', function(){
                $(".quantity_in_selection").addClass('d-none');
                var expense_type_id = $('#expense_type_id').val();
                if( expense_type_id == expense_type_id_weights){
                    $(".quantity_in_selection").removeClass('d-none');
                }
            });

            $(document).on('submit', '#save_expense', function(){
                if ($.trim($("#commodity_id").val()) == '') {
                    bootbox.alert('<span class="text-danger">Commodity required !</span>');
                    return false;
                }
                var postData = new FormData(this);
                $('.module_save_btn').attr('disabled', 'disabled');
                $.ajax({
                    url: "{{ URL::to('/admin/save_expense') }}",
                    type: "POST",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: postData,
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#error_msg').html('');
                        if (json['errors']) {
                            var error_msg_html = '<div class="alert alert-danger"><ul>';
                            $(json['errors']).each(function( index,value ) {
                                error_msg_html += '<li>'+value+'</li>';
                            });
                            error_msg_html += '</ul></div>';
                            $('#error_msg').html(error_msg_html);
                        } else if (json['success'] == 'Added') {
                            $('#rate').val('');
                            $("#currency_id").val('').trigger("change");
                            $("#expense_type_id").val('').trigger("change");
                            $("#expenses_name_id").val('').trigger("change");
                            $("#gst").val('').trigger("change");
                            $("#is_lab_expense").prop('checked', false);
                            $(".lab_selection").addClass('d-none');
                            $(".lab_selection_check_div").addClass('col-md-4');
                            $(".lab_selection_check_div").removeClass('col-md-2');
                            $("#lab_id").val('').trigger("change");
                            $("#quantity_in_id").val('').trigger("change");
                            ExpenseTable.draw();
                            bootbox.alert('<span class="text-success">Expense Successfully Created</span>');
                        } else if (json['success'] == 'Updated') {
                            $('#link').val('');
                            ExpenseTable.draw();
                            bootbox.alert('<span class="text-success">Expense Successfully Updated</span>');
                            $('.module_save_btn').val('Save');
                        } else {
                            bootbox.alert('<span class="text-danger">Something error occurred</span>');
                            return false;
                        }
                        return false;
                    },
                });
                return false;
            });

            $(document).on('click', '.edit_document', function(){
                var document_name_id = $(this).attr('data-document_id');
                $.ajax({
                    url: "document/" + document_name_id + "/edit",
                    type: "GET",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: {},
                    datatype: 'json',
                    async: false,
                    success: function (response) {
                        $('.module_save_btn').removeAttr('disabled', 'disabled');
                        var json = $.parseJSON(response);
                        $('#document_id').val(json['document_data'].id);
                        $('#document_name').val(json['document_data'].document_name);
                        $('city_id').val(json['document_data'].city_id);
                        $('.module_save_btn').val('Update');
                        $("html, body").animate({scrollTop: 0}, "slow");
                        return false;
                    },
                });
                return false;
            });

            $(document).on('click', '.delete_document', function(){
                var delete_document_id = $(this).attr('data-document_id');
                $('#delete_document_id').val(delete_document_id);
                $('#deletedocumentModel').modal('show');
                return false;
            });

            ExpenseTable = $('#dataTable-Expense').DataTable({
                "bServerSide": true,
                "processing": true,
                "bRetrieve": true,
                "pageLength": 10,
                "ajax": {
                    "url": "{{ URL::to('/admin/getExpenseDatatable/') }}",
                    "type": "GET",
                    "data": function (d) {
                        d.buyer_id = $('#buyer_id').val();
                        d.commodity_id = $('#commodity_id').val();
                        d.container_type_id = $('#container_type_id').val();
                    },
                },
                "columns": [
                    {
                        "data": 'id',
                        "sClass": 'text-nowrap',
                        "render": function( data, type, full, meta ) {
    //                        var edit_button = '<button class="btn btn-sm btn-info edit_document" data-document_id="'+ data +'"><i class="fa far fa-edit"></i></button>';
//                            var delete_button = '<button class="btn btn-sm btn-danger delete_document" data-document_id="'+ data +'" title="Delete"><span class="fa fa-times-circle"></span></button>';
    //                        return edit_button + ' ' + delete_button;
                            return '';
                        }
                    }, 
                    {
                        "data": "buyer_name",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "commodity_name",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "container_type_name",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "is_lab",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "lab_name",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "expense_name",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "expense_type_name",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "quantity_in_name",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "rate",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    {
                        "data": "currency",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    
                    {
                        "data": "gst",
                        "defaultContent": '-',
                        "searchable": false,
                    },
                    
                ],
                "ordering": false,
                "searching": false,
            });
        });
    </script>
@stop
