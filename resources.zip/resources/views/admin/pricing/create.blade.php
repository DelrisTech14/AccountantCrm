{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dhaval Agri | Pricing')

@section('content_header')
    <h1>Pricing</h1>
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/datepicker/datepicker3.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/select2/css/select2.min.css') }}">
@stop

@section('content')
    @include('error')
    <div class="box-body">
        <div class="card-body bg-white">
            {{ Form::open(['id' => 'save_pricing', 'method' => 'post', 'url' => 'admin/item/store', 'enctype' => 'multipart/form-data', 'data-parsley-validate' => '']) }}
            {{ csrf_field() }}
            {{ Form::hidden('id', $pricing_data->id ?? '') }}
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('buyer_id', 'Buyer', ['class' => 'control-label']) }} <span
                            class="text-danger">*</span>
                        <select class="form-control" id="buyer_id" name="buyer_id"></select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('commodity_id', 'Commodity', ['class' => 'control-label']) }} <span
                            class="text-danger">*</span>
                        <select class="form-control" id="commodity_id" name="commodity_id"></select>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="m-sm-4"><b id="quality_print"></b></label>
                    {{-- <table class="table table-bordered table-hover" style="margin: 14px 0px 0px 0px;">
                        <tr class="bg-success">
                            <th>Final</th>
                            <td align="right" id="top_final_usd1"></td>
                            <td align="right" id="new_top_final_usd"></td>
                            <td align="right" id="top_final_inr"></td>
                            <td align="right" id="top_final_4"></td>
                        </tr>
                    </table> --}}
                </div>
            </div>
            <div class="row">

                <div class="col-md-9">
                    <table class="table table-bordered table-hover">
                        
                        <tr>
                            <th>No. of Fcls</th>
                            <th>1</th>
                            <th>2</th>
                            <th>3</th>
                            <th>4</th>
                            <th>5</th>
                            <th>6</th>
                            <th>8</th>
                            <th>10</th>
                        </tr>
                        <tr>
                            <td></td>
                            <td id="table_top_final_usd1_1mt"></td>
                            <td id="table_top_final_usd2_1mt"></td>
                            <td id="table_top_final_usd3_1mt"></td>
                            <td id="table_top_final_usd4_1mt"></td>
                            <td id="table_top_final_usd5_1mt"></td>
                            <td id="table_top_final_usd6_1mt"></td>
                            <td id="table_top_final_usd8_1mt"></td>
                            <td id="table_top_final_usd10_1mt"></td>
                        </tr>
                        <tr>
                            {{-- // old 27-07-2022
                            <td></td>
                            <td id="table_top_final_usd1"></td>
                            <td id="table_top_final_usd2"></td>
                            <td id="table_top_final_usd3"></td>
                            <td id="table_top_final_usd4"></td>
                            <td id="table_top_final_usd5"></td>
                            <td id="table_top_final_usd6"></td>
                            <td id="table_top_final_usd8"></td>
                            <td id="table_top_final_usd10"></td> --}}
                            <td></td>
                            <td id="table_top_perton_final_usd1"></td>
                            <td id="table_top_perton_final_usd2"></td>
                            <td id="table_top_perton_final_usd3"></td>
                            <td id="table_top_perton_final_usd4"></td>
                            <td id="table_top_perton_final_usd5"></td>
                            <td id="table_top_perton_final_usd6"></td>
                            <td id="table_top_perton_final_usd8"></td>
                            <td id="table_top_perton_final_usd10"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td id="table_new_top_final_usd"></td>
                            <td id="table_new_top_final_usd2"></td>
                            <td id="table_new_top_final_usd3"></td>
                            <td id="table_new_top_final_usd4"></td>
                            <td id="table_new_top_final_usd5"></td>
                            <td id="table_new_top_final_usd6"></td>
                            <td id="table_new_top_final_usd8"></td>
                            <td id="table_new_top_final_usd10"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td id="table_top_final_inr"></td>
                            <td id="table_top_final_inr2"></td>
                            <td id="table_top_final_inr3"></td>
                            <td id="table_top_final_inr4"></td>
                            <td id="table_top_final_inr5"></td>
                            <td id="table_top_final_inr6"></td>
                            <td id="table_top_final_inr8"></td>
                            <td id="table_top_final_inr10"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td id="table_top_final_4"></td>
                            <td id="table_top_final_4_2"></td>
                            <td id="table_top_final_4_3"></td>
                            <td id="table_top_final_4_4"></td>
                            <td id="table_top_final_4_5"></td>
                            <td id="table_top_final_4_6"></td>
                            <td id="table_top_final_4_8"></td>
                            <td id="table_top_final_4_10"></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('rate', 'Rate', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('rate', $pricing_data->rate ?? '', ['class' => 'form-control num_only', 'placeholder' => 'Rate']) }}
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        {{ Form::label('quantity', 'Quantity', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('quantity', $pricing_data->quantity ?? '', ['class' => 'form-control num_only', 'placeholder' => 'Quantity']) }}
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        {{ Form::label('price_in_id', 'Price In', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        <select class="form-control select2" id="price_in_id" name="price_in_id"></select>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('change_lab_to', 'Change Lab To', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        <select name="change_lab_to" id="change_lab_to" class="form-control select2"></select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('ex_rate', 'Ex. Rate', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('ex_rate', $pricing_data->ex_rate ?? $currency_data->in_inr, ['class' => 'form-control num_only', 'placeholder' => 'Ex. Rate']) }}
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('days', 'Days', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('days', $pricing_data->days ?? '', ['class' => 'form-control num_only days', 'placeholder' => 'Days']) }}
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('fumigation_dosage_id', 'Fumigation Dosage', ['class' => 'control-label']) }}
                        <span class="text-danger"></span>
                        <select name="fumigation_dosage_id" id="fumigation_dosage_id" class="form-control select2"></select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('freight', 'Freight', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('freight', $pricing_data->freight ?? '', ['class' => 'form-control num_only', 'placeholder' => 'Freight']) }}
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('discount_per', 'Disc. %', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('discount_per', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only', 'placeholder' => 'Disc. %']) }}
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('packing_id', 'Packing', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        <select name="packing_id" id="packing_id" class="form-control select2"></select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group"> 
                        {{ Form::label('container_type_id', 'Container Type', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        <select name="container_type_id" id="container_type_id" class="form-control select2" onchange="set_dropdown(this)"></select>
                                

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('quantity_in_id', 'Quantity In', ['class' => 'control-label']) }}
                        <select class="form-control select2" id="quantity_in_id" name="quantity_in_id"></select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('no_of_fcls', 'No. Of Fcls', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('no_of_fcls', $pricing_data->no_of_fcls ?? '1', ['class' => 'form-control num_only', 'placeholder' => 'No. Of Fcls']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('currency_id', 'Currency', ['class' => 'control-label']) }}
                        <select class="form-control select2" id="currency_id" name="currency_id"></select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('broker_id', 'Broker', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        <select class="form-control select2" id="broker_id" name="broker_id"></select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('brokerage_per', 'Brokerage(%)', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('brokerage_per', '', ['id' => 'brokerage_per', 'class' => 'form-control num_only', 'placeholder' => 'Brokerage(%)']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('brokerage_amt', 'Brokerage Amt', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('brokerage_amt', '', ['id' => 'brokerage_amt', 'class' => 'form-control num_only', 'placeholder' => 'Brokerage Amt']) }}
                    </div>
                </div>
                {{-- <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('penal_interest', 'Penal Interest', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('penal_interest', '', ['id' => 'penal_interest', 'class' => 'form-control num_only', 'placeholder' => 'Penal Interest']) }}
                    </div>
                </div> --}}
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('destination_port_id', 'Port of Destination', ['class' => 'control-label']) }}
                        <span class="text-danger"></span>
                        <select name="destination_port_id" id="destination_port_id" class="form-control select2"></select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('insu_1', 'INSU_1', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('insu_1', '', ['id' => 'insu_1', 'class' => 'form-control num_only', 'placeholder' => 'INSU_1','step'=>"0.01"]) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('insu_2', 'INSU_2', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                        {{ Form::text('insu_2', '', ['id' => 'insu_2', 'class' => 'form-control num_only', 'placeholder' => 'INSU_2','step'=>"0.01"]) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('Quality', 'Quality', ['class' => 'control-label']) }} <span
                            class="text-danger"></span>
                            <select class="form-control select2" id="quality_box" name="quality">
                           
                            <option value=""></option>
                            
                            
                            </select>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                             <label>After Discount</label>

                             {{ Form::text('after_discount', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only after_discount', 'placeholder' => 'No. Of Fcls']) }}
                           
                            
                          

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                             <label>Bank Int Normal</label>

                             {{ Form::text('bank_int_normal', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only bank_int_normal', 'placeholder' => 'Bank Int Normal','id'=>'bank_int_normal']) }}
                           
                            
                          

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                             <label>Bank Int Panel</label>

                             {{ Form::text('bank_int_panel', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only bank_int_panel', 'placeholder' => 'Bank Int Panel','id'=>'bank_int_panel']) }}
                           
                            
                          

                    </div>
                </div>
                

                <div class="col-md-3">
                    <div class="form-group">
                             <label>Bank Int Total</label>

                             {{ Form::text('bank_int_total', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only bank_int_total', 'placeholder' => 'Bank Int Total']) }}
                           
                            
                          

                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="form-group">
                             <label>Final in Rs.</label>

                             {{ Form::text('final_in_rs', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only final_in_rs', 'placeholder' => 'Final in RS','id'=>'final_in_rs']) }}
                           
                            
                          

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                             <label>Insurance</label>

                             {{ Form::text('insurance_name', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only insurance_val', 'placeholder' => 'Insurance']) }}
                           
                            
                          

                    </div>
                </div>
                 

                <div class="col-md-3">
                    <div class="form-group">
                             <label>Freight 1800 / 19</label>

                             {{ Form::text('freight_1800', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only freight_1800', 'placeholder' => 'Freight 1800 / 19']) }}
                           
                            
                          

                    </div>
                </div>
                 
                <div class="col-md-3">
                    <div class="form-group">
                             <label>Packing 6 Dollar</label>

                             {{ Form::text('packing_6_dollar', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only packing_6_dollar', 'placeholder' => 'Packing 6 Dollar']) }}
                           
                    </div>
                </div>


                <div class="col-md-3">
                    <div class="form-group">
                             <label>Final Value</label>

                             {{ Form::text('final_value', $pricing_data->discount_per ?? '', ['class' => 'form-control num_only final_value', 'placeholder' => 'Final Value']) }}
                           
                    </div>
                </div>


            </div>
            <br />
            <div class="row">
                <div class="col-md-9 exp_div"></div>
                <div class="col-md-3 lab_div">

                <table class="table table-striped" id="expense_table" style="display:none;">
                    <div class="tttt"></div>
                    <thead>
                        <tr class="bg-gray">
                            <th scope="col">#</th>
                            <th scope="col">Add. Tests</th>
                            <th id="lab_names1" class="lab_names1" scope="col"> </th>
                        </tr>
                    </thead>
                    <tbody>
                    
                        <!-- <tr>
                            <th scope="row"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id"></th>
                            <td>Oil </td>
                            <td> 0 </td>
                        </tr>-->
                       

                    </tbody>
                    <tfoot>
                    <tr class="bg-primary">
                            <th scope="row"></th>
                            <td>Total </td>
                            <td align="right" style="float:right" id="expenses_total"> 0 </td>
                        </tr>
        </tfoot>

                </table>

                
                </div>
            </div>
            <br />
            {{ Form::submit('Save', ['class' => 'btn btn-primary module_save_btn']) }}
            {{ Form::close() }}
        </div>
    </div>
@stop

@section('js')
    <script src="{{ asset('vendor/datepicker/bootstrap-datepicker.js') }}"></script>
    <script src="{{ asset('vendor/select2/js/select2.min.js') }}"></script>
    <script>
        const TESTMODE = false;
        var currency_id_inr = '<?php echo Config::get('constants.CURRENCY.ID_INR'); ?>';
        var currency_id_usd = '<?php echo Config::get('constants.CURRENCY.ID_USD'); ?>';
        var expense_type_id_per_container = '<?php echo Config::get('constants.EXPENSE_TYPES.ID_PER_CONTAINER'); ?>';
        var ex_rate = '1';
        var no_of_fcls = '1';
        var discount_per = '0';
        var quantity = '1';
        var rate = '1';
        var exp_objectdata = [];
        var buyer_id = '';
        var commodity_id = '';
        var container_type_id = '';
        var fumigation_dosage_id = '';
        var destination_port_id = '';
        $(document).ready(function() {

            var acc_grp_ids_for_buyer = ["<?= Config::get('constants.ACCOUNT_GROUP.ID_BUYER') ?>"];

            
            initAjaxSelect2($("#buyer_id"), "{{ URL::to('/account_select2_source') }}/?ids=" +
                acc_grp_ids_for_buyer);
            initAjaxSelect2($("#change_lab_to"), "{{ URL::to('/change_lab_to_select2_source') }}");  
            initAjaxSelect2($("#commodity_id"), "{{ URL::to('/comodity_select2_source') }}");
            initAjaxSelect2($("#container_type_id"), "{{ URL::to('/container_type_select2_source') }}");
            initAjaxSelect2($("#quantity_in_id"), "{{ URL::to('/quantity_in_select2_source') }}");
            initAjaxSelect2($("#price_in_id"), "{{ URL::to('/quantity_in_select2_source') }}");
            initAjaxSelect2($("#fumigation_dosage_id"),"{{ URL::to('/fumigation_dosage_select2_source') }}?con_type_id=0");
            initAjaxSelect2($("#destination_port_id"), "{{ URL::to('/port_select2_source') }}");
            initAjaxSelect2($("#currency_id"), "{{ URL::to('/currency_select2_source') }}");
            //        initAjaxSelect2($("#currency_id_for_exp"), "{{ URL::to('/currency_select2_source') }}");
            initAjaxSelect2($("#packing_id"), "{{ URL::to('/packing_select2_source') }}");
            var acc_grp_ids_for_broker = ["<?= Config::get('constants.ACCOUNT_GROUP.ID_BROKER') ?>"];
            initAjaxSelect2($("#broker_id"), "{{ URL::to('/account_select2_source') }}/?ids=" +
                acc_grp_ids_for_broker);

            $(document).on('change', '#buyer_id', function() {


                buyer_id = $('#buyer_id').val();
               
                $('#days').val('');
                $('#discount_per').val('');
                $('#commodity_id').val(null).trigger('change');
                $('#destination_port_id').val(null).trigger('change');
                $('#currency_id').val(null).trigger('change');
                $('#broker_id').val(null).trigger('change');
                $('#brokerage_per').val('');
                $('#rate').val(1);

                if (buyer_id != null) {
                    $.ajax({
                        url: "{{ URL::to('/admin/get_account_data') }}/" + buyer_id,
                        type: "GET",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: {},
                        async: false,
                        success: function(response) {
                            var json = $.parseJSON(response);
                           // alert(json['account_data'].credit_days);
                            $('#days').val(json['account_data'].credit_days);
                            $('#discount_per').val(json['account_data'].discount_per).trigger(
                                'change');
                            if (json['account_data'].default_port) {
                                setSelect2Value($("#destination_port_id"),
                                    "{{ URL::to('/set_port_select2_val_by_id/') }}/" +
                                    json['account_data'].default_port);
                            }
                            if (json['account_data'].currency_id) {
                                setSelect2Value($("#currency_id"),
                                    "{{ URL::to('/set_currency_select2_val_by_id/') }}/" +
                                    json['account_data'].currency_id);
                            }
                            if (json['account_data'].broker_id) {
                                setSelect2Value($("#broker_id"),
                                    "{{ URL::to('/set_account_select2_val_by_id/') }}/" +
                                    json['account_data'].broker_id);
                            }
                            $('#brokerage_per').val(json['account_data'].brokerage_per);
                            return false;
                        },
                    });
                }

                set_amount();
            });

            $(document).on('input', '#brokerage_per', function() {
                set_amount();
            });

            $(document).on('change', '#commodity_id', function() {
        
                commodity_id = $('#commodity_id').val();
                $('#packing_id').val(null).trigger('change');
                $('#fumigation_dosage_id').val(null).trigger('change');
                $('#container_type_id').val(null).trigger('change');
                $('#quantity_in_id').val(null).trigger('change');
                $('#price_in_id').val(null).trigger('change');
                $('#rate').val(117002);
				//$('#change_lab_to').val().trigger('change');
				// alert(change_lab_to)
                $('#quality_print').html('');

                if (commodity_id != null) {
                    ex_rate = $('#ex_rate').val();
                    discount_per = $('#discount_per').val();
                    container_type_id = $('#container_type_id').val();

                    $.ajax({
                        url: "{{ URL::to('/admin/get_account_commodity_wise_default_data') }}?account_id=" +
                            buyer_id + '&commodity_id=' + commodity_id,
                        type: "GET",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: {},
                        async: false,
                        success: function(response) {
                         
                            var json = $.parseJSON(response);
							                           //Rashid Start cofe alert(json);
						  // alert(json['lab_id']);
						   if (json['lab_id']) {
                                setSelect2Value($("#change_lab_to"),
                                    "{{ URL::to('/set_lab_select2_val_by_id/') }}/" +
                                    json['lab_id']);
                            }
							//Rashid End code alert(json);
                            if (json['packing_id']) {
                                setSelect2Value($("#packing_id"),
                                    "{{ URL::to('/set_packing_select2_val_by_id/') }}/" +
                                    json['packing_id']);
                            }
                            if (json['fumigation_dosage_id']) {
                                setSelect2Value($("#fumigation_dosage_id"),
                                    "{{ URL::to('/set_fumigation_dosage_select2_val_by_id/') }}/" +
                                    json['fumigation_dosage_id']);
                            }
                            if (json['container_type_id']) {
                                setSelect2Value($("#container_type_id"),
                                

                                    "{{ URL::to('/set_container_type_select2_val_by_id/') }}/" +
                                    json['container_type_id']);
                            }
                            // code by rashid start//
                            
                            if (json['container_type_id']) {
                                setSelect2Value($("#container_type_id"),
                                

                                    "{{ URL::to('/set_container_type_select2_val_by_id/') }}/" +
                                    json['container_type_id']);
                            }
							
                           
                            // Code added  by rashid 7-6-2024//
                           

                             // Code added  by rashid 7-6-2024//

                            if (json['commodity_data'].quantity_unit_id) {
                                setSelect2Value($("#quantity_in_id"),
                                    "{{ URL::to('/set_quantity_in_select2_val_by_id/') }}/" +
                                    json['commodity_data'].quantity_unit_id);
                            }
                            if (json['commodity_data'].price_unit_id) {
                                setSelect2Value($("#price_in_id"),
                                    "{{ URL::to('/set_quantity_in_select2_val_by_id/') }}/" +
                                    json['commodity_data'].price_unit_id);
                            }
                            if(json['rate']){
                                $('#rate').val(json['rate']);
                            }
                            if(json['quality_name']){
                                $("#quality_print").html('Quality Name :- ' +json['quality_name']);
                            }
                            return false;
                        },
                    });

                    quantity = $('#quantity').val() || 1;
                    brokerage_per = $('#brokerage_per').val() || 0;
                    var quantity_in_id = $('#quantity_in_id').val();
                    var quantity_in_name = $('#quantity_in_id option:selected').html();
                    if (quantity_in_id == null || quantity_in_id == '') {
                        quantity_in_name = '';
                    }
                    var fumigation_dosage_id = $('#fumigation_dosage_id').val();
                    SetData(fumigation_dosage_id);

                    //Code By Rashid Start(lab Data) 

                    if (lab_id != null)
				{
                    $.ajax
					({
                        url: "{{ URL::to('/admin/get_lab_data') }}?lab_id=" +lab_id + "&commodity_id=" +commodity_id + "&buyer_id=" + buyer_id + "&container_type_id=" + container_type_id,
                        type: "GET",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: {},
                        async: false,
                        success: function(response) {
                            var json = $.parseJSON(response);
                           // alert(json.expemse_data);
                           //var lb= document.getElementById("lab_names");
                           //console.log($('#lab_names1').text());
                           var lab_values=json.lab_name;
                          // $('th', '#lab_names1').html(lab_values);
                           $('.lab_names1').html(lab_values);
                           var response_data=json.expemse_data_withbuyer;
                           var response_data1=json.expemse_data_withoutbuyer;
                           $("#expense_table").css("display", "block");
                           var TotalExpense =0;
                           $("#expense_table tbody").empty();
                           $.each(response_data, function(index, item) {
                            $("#expense_table tbody tr:odd").css("background-color", "#f9f9f9");
                            $("#expense_table tbody tr:even").css("background-color", "#fff");
                             var rowss = "<tr><td><input id='lab_expense_id' class='lab_expense_id' onchange='set_checkbox_checked_unchecked(this);' checked data-key=" + index +
                                " name='expenses_id' type='checkbox' value=" + item.expenses_name_id + " ></td><td>" + item.expense_name + "</td><td align='right' id='item_rates' class='item_rates'>" + item.rate + "</td></tr>";
                            $("#expense_table tbody").append(rowss);
                            TotalExpense += item.rate;
                            
                            });
                            $.each(response_data1, function(index, item) {
                            $("#expense_table tbody tr:odd").css("background-color", "#f9f9f9");
                            $("#expense_table tbody tr:even").css("background-color", "#fff");
                             var rowss = "<tr><td><input id='lab_expense_id' class='lab_expense_id' onchange='set_checkbox_checked_unchecked(this);' data-key=" + index +
                                " name='expenses_id' type='checkbox' value=" + item.expenses_name_id + " ></td><td>" + item.expense_name + "</td><td align='right' id='item_rates' class='item_rates'>" + item.rate + "</td></tr>";
                            $("#expense_table tbody").append(rowss);
                           // TotalExpense += item.rate;
                            
                            });
                           // alert(TotalExpense)
                            $("#expenses_total").text(TotalExpense);
                            
                          // console.log($('#lab_names1').text());
                           
                        },
                        
                    });
                }

                    //Code By Rashid End

                    // $.ajax({
                    //     url: "{{ URL::to('/admin/get_exp_data_from_commodity') }}?commodity_id=" +
                    //         commodity_id + "&buyer_id=" + buyer_id,
                    //     type: "GET",
                    //     processData: false,
                    //     contentType: false,
                    //     cache: false,
                    //     data: {},
                    //     async: false,
                    //     success: function(response) {
                    //         exp_objectdata = $.parseJSON(response);
                    //         if(fumigation_dosage_id != ''){
                    //             $.ajax({
                    //                     url: "{{ URL::to('/get_fumigation_dosage_val_by_id/') }}/" + fumigation_dosage_id,
                    //                     type: "GET",
                    //                     cache: false,
                    //                     data: {},
                    //                     async: false,
                    //                     success: function(response) {
                    //                         if(response.success){
                    //                             if(response.currency_id == 1){
                    //                                 fumigation_cost_usd= parseFloat(response.cost)/parseFloat(ex_rate);
                    //                                 fumigation_cost_inr= parseFloat(response.cost);
                    //                                 fumigation_cost_usd2= (parseFloat(response.cost)/parseFloat(ex_rate))*2
                    //                                 fumigation_cost_inr2= (parseFloat(response.cost))*2;
                    //                             }else if(response.currency_id == 2){
                    //                                 fumigation_cost_usd= parseFloat(response.cost);
                    //                                 fumigation_cost_inr= parseFloat(response.cost)*parseFloat(ex_rate);
                    //                                 fumigation_cost_usd2= (parseFloat(response.cost))*2;
                    //                                 fumigation_cost_inr2= (parseFloat(response.cost)*parseFloat(ex_rate))*2;
                    //                             }
                    //                             exp_objectdata.push({
                    //                                 id:fumigation_dosage_id,
                    //                                 rate:response.cost,
                    //                                 currency_id:response.currency_id,
                    //                                 gst:0,
                    //                                 gst_usd_amt:0,
                    //                                 gst_inr_amt:0,
                    //                                 usd_rate:fumigation_cost_usd,
                    //                                 inr_rate:fumigation_cost_inr,
                    //                                 gst_usd_amt2:0,
                    //                                 gst_inr_amt2:0,
                    //                                 usd_rate2:fumigation_cost_usd2,
                    //                                 inr_rate2:fumigation_cost_inr2,
                    //                                 is_checked:'1',
                    //                                 lab_name:'',
                    //                                 expense_name : 'FUMI',
                    //                                 buyer_id : buyer_id,
                    //                                 extypid : 1
                    //                             })
                    //                         }
                    //                     }
                    //                 });
                    //         }
                    //         set_amount();
                    //         return false;
                    //     },
                    // });
                }
            });

            // Code Start By Rashid on Change Lab Id Lab Expenses Show In Table//


            
$(document).on('change', '#change_lab_to', function()
 {


    lab_id = $('#change_lab_to').val();

if (lab_id != null) {
    $.ajax({
        url: "{{ URL::to('/admin/get_lab_data') }}?lab_id=" +lab_id + "&commodity_id=" +commodity_id + "&buyer_id=" + buyer_id + "&container_type_id=" + container_type_id,
                        type: "GET",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: {},
                        async: false,
                        success: function(response) {
                            var json = $.parseJSON(response);
                           // alert(json.expemse_data);
                           //var lb= document.getElementById("lab_names");
                          // console.log($('#lab_names1').text());
                           var lab_values=json.lab_name;
                          // $('th', '#lab_names1').html(lab_values);
                           $('.lab_names1').html(lab_values);
                           var response_data=json.expemse_data_withbuyer;
                           var response_data1=json.expemse_data_withoutbuyer;
                           $("#expense_table").css("display", "block");
                           var TotalExpense =0;
                           $("#expense_table tbody").empty();
                           $.each(response_data, function(index, item) {
                            $("#expense_table tbody tr:odd").css("background-color", "#f9f9f9");
                            $("#expense_table tbody tr:even").css("background-color", "#fff");
                             var rowss = "<tr><td><input onchange='set_checkbox_checked_unchecked(this);' checked data-key=" + index +
                                " name='expenses_id' type='checkbox' value=" + item.expenses_name_id + " ></td><td>" + item.expense_name + "</td><td id='item_rates' class='item_rates'>" + item.rate + "</td></tr>";
                            $("#expense_table tbody").append(rowss);
                            TotalExpense += item.rate;
                            
                            });
                            $.each(response_data1, function(index, item) {
                            $("#expense_table tbody tr:odd").css("background-color", "#f9f9f9");
                            $("#expense_table tbody tr:even").css("background-color", "#fff");
                             var rowss = "<tr><td><input onchange='set_checkbox_checked_unchecked(this);' data-key=" + index +
                                " name='expenses_id' type='checkbox' value=" + item.expenses_name_id + " ></td><td>" + item.expense_name + "</td><td id='item_rates' class='item_rates'>" + item.rate + "</td></tr>";
                            $("#expense_table tbody").append(rowss);
                           // TotalExpense += item.rate;
                            
                            });
                           // alert(TotalExpense)
                            $("#expenses_total").text(TotalExpense);
                            
                          // console.log($('#lab_names1').text());
                           
                        },
                        

    });

}

});
            // Code Start By Rashid on Change Lab Id Lab Expenses Show In Table//

            function SetData(fumigation_dosage_id){
                commodity_id = $('#commodity_id').val();
                buyer_id = $('#buyer_id').val();
                container_type_id = $('#container_type_id').val();
                $.ajax({
                        url: "{{ URL::to('/admin/get_exp_data_from_commodity') }}?commodity_id=" +commodity_id + "&buyer_id=" + buyer_id + "&container_type_id=" + container_type_id ,
                        type: "GET",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: {},
                        async: false,
                        success: function(response) {
							
                            exp_objectdata = $.parseJSON(response);
							
                            if(fumigation_dosage_id != ''){
                                $.ajax({
                                        url: "{{ URL::to('/get_fumigation_dosage_val_by_id/') }}/" + fumigation_dosage_id,
                                        type: "GET",
                                        cache: false,
                                        data: {},
                                        async: false,
                                        success: function(response) {
											
                                            if(response.success){
                                                if(response.currency_id == 1){
                                                    fumigation_cost_usd= parseFloat(response.cost)/parseFloat(ex_rate);
                                                    fumigation_cost_inr= parseFloat(response.cost);
                                                    fumigation_cost_usd2= (parseFloat(response.cost)/parseFloat(ex_rate))*2
                                                    fumigation_cost_inr2= (parseFloat(response.cost))*2;
                                                }else if(response.currency_id == 2){
                                                    fumigation_cost_usd= parseFloat(response.cost);
                                                    fumigation_cost_inr= parseFloat(response.cost)*parseFloat(ex_rate);
                                                    fumigation_cost_usd2= (parseFloat(response.cost))*2;
                                                    fumigation_cost_inr2= (parseFloat(response.cost)*parseFloat(ex_rate))*2;
                                                }
                                                exp_objectdata.push({
                                                    id:fumigation_dosage_id,
                                                    rate:response.cost,
                                                    currency_id:response.currency_id,
                                                    gst:0,
                                                    gst_usd_amt:0,
                                                    gst_inr_amt:0,
                                                    usd_rate:fumigation_cost_usd,
                                                    inr_rate:fumigation_cost_inr,
                                                    gst_usd_amt2:0,
                                                    gst_inr_amt2:0,
                                                    usd_rate2:fumigation_cost_usd2,
                                                    inr_rate2:fumigation_cost_inr2,
                                                    is_checked:'1',
                                                    lab_name:'',
                                                    expense_name : 'FUMI',
                                                    buyer_id : buyer_id,
                                                    extypid : 1
                                                })
                                            }
                                        }
                                    });
                            }
                            set_amount();
                            return false;
                        },
                });
   
            }

            $(document).on('change', '#container_type_id', function() {
                fumigation_dosage_id = $('#fumigation_dosage_id').val();
                SetData(fumigation_dosage_id);
            });

            $(document).on('change', '#container_type_id, #fumigation_dosage_id', function() {
                
                container_type_id = $('#container_type_id').val();
                if ($(this).attr('id') == 'container_type_id') {
                    if ($(this).val() != null) {
                        initAjaxSelect2($("#fumigation_dosage_id"),
                            "{{ URL::to('/fumigation_dosage_select2_source') }}?con_type_id=" + $(
                                this).val());
                    } else {
                        initAjaxSelect2($("#fumigation_dosage_id"),
                            "{{ URL::to('/fumigation_dosage_select2_source') }}?con_type_id=0");
                    }
                }
                fumigation_dosage_id = $('#fumigation_dosage_id').val();
                // $('#rate').val('');
                // if (container_type_id != null && fumigation_dosage_id != null) {
                //     $.ajax({
                //         url: "{{ URL::to('/admin/get_fumigation_dosage_data') }}?container_type_id=" +
                //             container_type_id + "&fumigation_dosage_id=" + fumigation_dosage_id,
                //         type: "GET",
                //         processData: false,
                //         contentType: false,
                //         cache: false,
                //         data: {},
                //         async: false,
                //         success: function(response) {
                //             var json = $.parseJSON(response);
                //             $('#rate').val(json['rate']);
                //             return false;
                //         },
                //     });
                // }

                $('#quantity').val(null).trigger('change');
                if (commodity_id != null && container_type_id != null)
				{
                    $.ajax
					({
                        url: "{{ URL::to('/admin/get_commodity_container_wise_quantity') }}?commodity_id=" +
                            commodity_id + "&container_type_id=" + container_type_id,
                        type: "GET",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: {},
                        async: false,
                        success: function(response) {
                            var json = $.parseJSON(response);
                            $('#quantity').val(json['quantity']).trigger('change');
                            return false;
                        },
                    });
                }

            });

            $(document).on('change', '#container_type_id, #destination_port_id', function() {
                if ($(this).attr('id') == 'container_type_id') {
                    if ($(this).val() != null) {
                        initAjaxSelect2($("#fumigation_dosage_id"),
                            "{{ URL::to('/fumigation_dosage_select2_source') }}?con_type_id=" + $(
                                this).val());
                    } else {
                        initAjaxSelect2($("#fumigation_dosage_id"),
                            "{{ URL::to('/fumigation_dosage_select2_source') }}?con_type_id=0");
                    }
                }
                destination_port_id = $('#destination_port_id').val();
                $('#freight').val('');
                if (commodity_id != null && container_type_id != null && destination_port_id != null) {
                    $.ajax({
                        url: "{{ URL::to('/admin/get_freight_data') }}?commodity_id=" +
                            commodity_id + "&container_type_id=" + container_type_id +
                            "&destination_port_id=" + destination_port_id,
                        type: "GET",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: {},
                        async: false,
                        success: function(response) {
                            var json = $.parseJSON(response);
                            $('#freight').val(json['freight']);
                            return false;
                        },
                    });
                }
            });

            $(document).on('keyup change', '#ex_rate', function() {
                ex_rate = $('#ex_rate').val();
                set_amount();
            });

            $(document).on('keyup change', '#no_of_fcls', function() {
                no_of_fcls = $('#no_of_fcls').val();
                set_amount();
            });
            $(document).on('keyup change', '#freight', function() {
                freight = $('#freight').val();
                set_amount();
            });
            $(document).on('keyup change', '#discount_per', function() {
                discount_per = $('#discount_per').val();
                set_amount();
            });

            $(document).on('keyup change', '#quantity', function() {
                quantity = $('#quantity').val();
                set_amount();
            });

            $(document).on('keyup change', '#rate', function() {
                rate = $('#rate').val();
                set_amount();
            });

            $(document).on('submit', '#save_pricing', function(e) {
                return false;
            });

        });
        function set_checkbox_checked(data)
         {
            if ($(data).is(":checked")) {
                exp_objectdata[$(data).attr('data-key')].is_checked = '1';
                set_amount();
            } else {
                exp_objectdata[$(data).attr('data-key')].is_checked = '0';
                set_amount();
            }
        }

        // $(document).on('change','.PenalAfterDay .penalper .normalper',function(){
        //     alert(123);
        //     set_amount();
        // })
        function set_checkbox_checked_unchecked(data)
         {
            
            if ($(data).is(":checked")) {
               // exp_objectdata[$(data).attr('data-key')].is_checked = '1';
                console.log('1');
                set_expenses();
            } else {
                //exp_objectdata[$(data).attr('data-key')].is_checked = '0';
            //  alert('2'); 
            console.log('2'); 
                set_expenses1();
            }
        }

        $(document).on('change','.PenalAfterDay',function(){
            set_amount();
        })

        $(document).on('change','.penalper',function(){
            set_amount();
        })

        $(document).on('change','.normalper',function(){
            set_amount();
        })

        $(document).on('change','.days',function(){
            set_amount();
        })

        $(document).on('change','#fumigation_dosage_id',function(){
            set_amount();
        })

        $(document).on('change','#insu_2',function(){
            set_amount();
        })

        $(document).on('change','#insu_1',function(){
            set_amount();
        })

        $(document).on('change','#freight',function(){
            set_amount();
        })

        $(document).on('change','#packing_id',function(){
            set_amount();
        })

        function set_amount() {
            var PenalAfterDay=25;
            var penalper=14;
            var normalper=11;
                if($('.PenalAfterDay').val() != undefined){
                    PenalAfterDay = $('.PenalAfterDay').val();
                }
                if($('.penalper').val() != undefined){
                    penalper = $('.penalper').val();
                }
                if($('.normalper').val() != undefined){
                    normalper = $('.normalper').val();
                }

            $('.exp_div').html('');

            $('#top_final_usd1').html('');
            $('#new_top_final_usd').html('');
            $('#top_final_inr').html('');
            $('#top_final_4').html('');
            $('#table_top_final_usd1').html('');
            $('#table_top_final_usd1_1mt').html('');
            $('#table_new_top_final_usd').html('');
            $('#table_top_final_inr').html('');
            $('#table_top_final_4').html('');

            // make this arry to clear top table using foreach loop wise name target
                var top_tb_no=[2,3,4,5,6,8,10];
            $.each(top_tb_no ,function(key,val){

                $('#top_final_usd'+val).html('');
                $('#new_top_final_usd'+val).html('');
                $('#top_final_inr'+val).html('');
                $('#top_final_4_'+val).html('');
                $('#table_top_final_usd'+val).html('');
                $('#table_new_top_final_usd'+val).html('');
                $('#table_top_final_inr'+val).html('');
                $('#table_top_final_4_'+val).html('');

            })
			lab_id=$('#change_lab_to').val();
			//alert(lab_id);
            commodity_id = $('#commodity_id').val();
            buyer_id = $('#buyer_id').val();

            quantity = $('#quantity').val() || 1;
            rate = $('#rate').val();
            brokerage_per = $('#brokerage_per').val() || 0;
            var quantity_in_id = $('#quantity_in_id').val();
            var quantity_in_name = $('#quantity_in_id option:selected').html();
            if (quantity_in_id == null || quantity_in_id == '') {
                quantity_in_name = '';
            }
            if (quantity == '' || quantity == null) {
                quantity = '1';
            }
            if (rate == '' || rate == null) {
                rate = '1';
            }
            if (ex_rate == '' || ex_rate == null) {
                ex_rate = '1';
            }
            if (no_of_fcls == '' || no_of_fcls == null) {
                no_of_fcls = '1';
            }
            if (discount_per == '' || discount_per == null) {
                discount_per = '0';
            }

            exp_html = '';
            if (exp_objectdata != '' && commodity_id != null && buyer_id != null) {
                var for_1_unit = 'For 1 ' + quantity_in_name;
                fumigation_cost_usd=0;
                fumigation_cost_inr=0;
                total_usd = 0;
                total_inr = 0;
                total_gst_usd_amt = 0;
                total_gst_inr_amt = 0;
                total_without_gst_usd_amt = 0;
                total_without_gst_inr_amt = 0;

                // 2
                fumigation_cost_usd2=0;
                fumigation_cost_inr2=0;
                total_usd2 = 0;
                total_inr2 = 0;
                total_gst_usd_amt2 = 0;
                total_gst_inr_amt2 = 0;
                total_without_gst_usd_amt2 = 0;
                total_without_gst_inr_amt2 = 0;

                // 3
                fumigation_cost_usd3=0;
                fumigation_cost_inr3=0;
                total_usd3 = 0;
                total_inr3 = 0;
                total_gst_usd_amt3 = 0;
                total_gst_inr_amt3 = 0;
                total_without_gst_usd_amt3 = 0;
                total_without_gst_inr_amt3 = 0;

                // 4
                fumigation_cost_usd4=0;
                fumigation_cost_inr4=0;
                total_usd4 = 0;
                total_inr4 = 0;
                total_gst_usd_amt4 = 0;
                total_gst_inr_amt4 = 0;
                total_without_gst_usd_amt4 = 0;
                total_without_gst_inr_amt4 = 0;

                // 5
                fumigation_cost_usd5=0;
                fumigation_cost_inr5=0;
                total_usd5 = 0;
                total_inr5 = 0;
                total_gst_usd_amt5 = 0;
                total_gst_inr_amt5 = 0;
                total_without_gst_usd_amt5 = 0;
                total_without_gst_inr_amt5 = 0;

                // 6
                fumigation_cost_usd6=0;
                fumigation_cost_inr6=0;
                total_usd6 = 0;
                total_inr6 = 0;
                total_gst_usd_amt6 = 0;
                total_gst_inr_amt6 = 0;
                total_without_gst_usd_amt6 = 0;
                total_without_gst_inr_amt6 = 0;

                // 8
                fumigation_cost_usd8=0;
                fumigation_cost_inr8=0;
                total_usd8 = 0;
                total_inr8 = 0;
                total_gst_usd_amt8 = 0;
                total_gst_inr_amt8 = 0;
                total_without_gst_usd_amt8 = 0;
                total_without_gst_inr_amt8 = 0;

                // 10
                fumigation_cost_usd10=0;
                fumigation_cost_inr10=0;
                total_usd10 = 0;
                total_inr10 = 0;
                total_gst_usd_amt10 = 0;
                total_gst_inr_amt10 = 0;
                total_without_gst_usd_amt10 = 0;
                total_without_gst_inr_amt10 = 0;

                exp_html += '<table class="table table-bordered table-hover" style="width: 100%;">';
                exp_html += '<tr class="bg-gray">';
                exp_html += '<th>&nbsp;</th>';
                exp_html += '<th>Particular</th>';
                exp_html += '<th>Lab</th>';
                if(TESTMODE){
                exp_html += '<th>EX TYP ID</th>';
                exp_html += '<th>EX TYP Name</th>';
                }
                exp_html += '<th>GST</th>';
                exp_html += '<th class="text-right">USD</th>';
                if(TESTMODE)
                exp_html += '<th class="text-right">USD2</th>';
                // exp_html += '<th class="" style="width: 150px;"><select class="form-control select2"  style="width: 150px;" id="currency_id_for_exp" name="currency_id_for_exp"></select></th>';
                exp_html += '<th class="text-right">INR</th>';
                if(TESTMODE)
                exp_html += '<th class="text-right">INR2</th>';
            // Code By Rashid Start//
                var basic_cost_inr_old = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls);
                $('.after_discount').val(basic_cost_inr_old);

                
                var basic_cost_inr =  parseFloat(rate) *(100-5)*parseFloat(quantity) /100;
                var days=25;
                var bank_int_panel=basic_cost_inr*(days-PenalAfterDay)*normalper;
                $('.bank_int_panel').val(bank_int_panel);
               

                var bank_int_total= 8633.45 +parseFloat(bank_int_panel);
                $('.bank_int_total').val(bank_int_total);
                var final_in_rs=basic_cost_inr+bank_int_total;
                $('.final_in_rs').val(final_in_rs);
               
                if(days<=25)
                {
                   // console.log(1);
                   // basic_cost_inr_with_tax= parseFloat($('#total_inr').text());
                   
                    //basic_cost_inr=1145894.40;
                    var bank_int_normal=parseFloat(basic_cost_inr+total_inr)*days*parseFloat(normalper)/36500;
                    // var bank_int_normal=1111519*25*11/36500;   
                   // console.log(bank_int_normal);
                }
                else
                {
                   // console.log(2);
                    var bank_int_normal=parseFloat(basic_cost_inr)*25*parseFloat(normalper)/36500;  
                   // console.log(bank_int_normal);    
                }
                
                $('.bank_int_normal').val(bank_int_normal);
                var insurance_val=final_in_rs*0*0/100;
                $('.insurance_val').val(insurance_val);
                var freight_1800=1800*82*1;
                $('.freight_1800').val(freight_1800);
                
                var packing_6_dollar=60*82*1;
                $('.packing_6_dollar').val(packing_6_dollar);
                var final_value=basic_cost_inr+8633.45+4920;
                $('.final_value').val(final_value);
                //Code By Rashid End//
                basic_cost_inr = parseFloat(basic_cost_inr).toFixed(2);
                total_inr = total_inr + parseFloat(basic_cost_inr);
                var basic_cost_usd = parseFloat(basic_cost_inr) / parseFloat(ex_rate);
                basic_cost_usd = parseFloat(basic_cost_usd).toFixed(2);
                total_usd = total_usd + parseFloat(basic_cost_usd);

                // 2
                var basic_cost_inr2 = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls)*2;
                basic_cost_inr2 = parseFloat(basic_cost_inr2).toFixed(2);
                total_inr2 = total_inr2 + parseFloat(basic_cost_inr2);
                var basic_cost_usd2 = parseFloat(basic_cost_inr2) / parseFloat(ex_rate)*2;
                basic_cost_usd2 = parseFloat(basic_cost_usd2).toFixed(2);
                total_usd2 = total_usd2 + parseFloat(basic_cost_usd2);

                // 3
                var basic_cost_inr3 = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls)*3;
                basic_cost_inr3 = parseFloat(basic_cost_inr3).toFixed(2);
                total_inr3 = total_inr3 + parseFloat(basic_cost_inr3);
                var basic_cost_usd3 = parseFloat(basic_cost_inr3) / parseFloat(ex_rate)*3;
                basic_cost_usd3 = parseFloat(basic_cost_usd3).toFixed(2);
                total_usd3 = total_usd3 + parseFloat(basic_cost_usd3);

                // 4
                var basic_cost_inr4 = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls)*4;
                basic_cost_inr4 = parseFloat(basic_cost_inr4).toFixed(2);
                total_inr4 = total_inr4 + parseFloat(basic_cost_inr4);
                var basic_cost_usd4 = parseFloat(basic_cost_inr4) / parseFloat(ex_rate)*4;
                basic_cost_usd4 = parseFloat(basic_cost_usd4).toFixed(2);
                total_usd4 = total_usd4 + parseFloat(basic_cost_usd4);

                // 5
                var basic_cost_inr5 = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls)*5;
                basic_cost_inr5 = parseFloat(basic_cost_inr5).toFixed(2);
                total_inr5 = total_inr5 + parseFloat(basic_cost_inr5);
                var basic_cost_usd5 = parseFloat(basic_cost_inr5) / parseFloat(ex_rate)*5;
                basic_cost_usd5 = parseFloat(basic_cost_usd5).toFixed(2);
                total_usd5 = total_usd5 + parseFloat(basic_cost_usd5);

                // 6
                var basic_cost_inr6 = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls)*6;
                basic_cost_inr6 = parseFloat(basic_cost_inr6).toFixed(2);
                total_inr6 = total_inr6 + parseFloat(basic_cost_inr6);
                var basic_cost_usd6 = parseFloat(basic_cost_inr6) / parseFloat(ex_rate)*6;
                basic_cost_usd6 = parseFloat(basic_cost_usd6).toFixed(2);
                total_usd6 = total_usd6 + parseFloat(basic_cost_usd6);

                // 8
                var basic_cost_inr8 = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls)*8;
                basic_cost_inr8 = parseFloat(basic_cost_inr8).toFixed(2);
                total_inr8 = total_inr8 + parseFloat(basic_cost_inr8);
                var basic_cost_usd8 = parseFloat(basic_cost_inr8) / parseFloat(ex_rate)*8;
                basic_cost_usd8 = parseFloat(basic_cost_usd8).toFixed(2);
                total_usd8 = total_usd8 + parseFloat(basic_cost_usd8);

                
                // 10
                var basic_cost_inr10 = parseFloat(quantity) * parseFloat(rate) * parseFloat(no_of_fcls)*10;
                basic_cost_inr10 = parseFloat(basic_cost_inr10).toFixed(2);
                total_inr10 = total_inr10 + parseFloat(basic_cost_inr10);
                var basic_cost_usd10 = parseFloat(basic_cost_inr10) / parseFloat(ex_rate)*10;
                basic_cost_usd10 = parseFloat(basic_cost_usd10).toFixed(2);
                total_usd10 = total_usd10 + parseFloat(basic_cost_usd10);

                exp_html += '</tr>';
                exp_html += '<tr class="">';
                exp_html += '<th>&nbsp;</th>';
                exp_html += '<th>Basic Cost of Goods</th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th></th>';
                exp_html += '<th class="text-right goods1">' + basic_cost_usd + '</th>';
                if(TESTMODE)
                exp_html += '<th class="text-right">' + basic_cost_usd2 + '</th>';
                exp_html += '<th class="text-right goods_inr">' + basic_cost_inr + '</th>';
                if(TESTMODE)
                exp_html += '<th class="text-right">' + basic_cost_inr2 + '</th>';
                exp_html += '</tr>';
                //initAjaxSelect2($("#currency_id_for_exp"), "{{ URL::to('/currency_select2_source') }}");
                $.each(exp_objectdata, function(index, value) {
                    if (value.expense_type_id != expense_type_id_per_container) {
                        no_of_fcls = '1';
                    }
                    var rate = parseFloat(value.rate) * parseFloat(no_of_fcls);
                    rate = parseFloat(rate).toFixed(2);
                    if (value.currency_id == currency_id_inr) {
                        if(value.extypid == 4){
                            var usd_rate = parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate = parseFloat(quantity)*parseFloat(rate);
                        }else{
                            var usd_rate = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate = rate;
                        }
                        if(value.extypid == 4){
                            // 2
                            var usd_rate2 = (parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate))*2;
                            var inr_rate2 = parseFloat(quantity)*parseFloat(rate)*2;

                            // 3
                            var usd_rate3 = parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate)*3;
                            var inr_rate3 = parseFloat(quantity)*parseFloat(rate)*3;

                            // 4
                            var usd_rate4 = parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate)*4;
                            var inr_rate4 = parseFloat(quantity)*parseFloat(rate)*4;

                            // 5
                            var usd_rate5 = parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate)*5;
                            var inr_rate5 = parseFloat(quantity)*parseFloat(rate)*5;

                            // 6
                            var usd_rate6 = parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate)*6;
                            var inr_rate6 = parseFloat(quantity)*parseFloat(rate)*6;

                            // 8
                            var usd_rate8 = parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate)*8;
                            var inr_rate8 = parseFloat(quantity)*parseFloat(rate)*8;

                            // 10
                            var usd_rate10 = parseFloat(quantity)*parseFloat(rate) / parseFloat(ex_rate)*10;
                            var inr_rate10 = parseFloat(quantity)*parseFloat(rate)*10;
                        }else if(value.extypid == 1){
                            // 2
                            var usd_rate2 = (parseFloat(rate) / parseFloat(ex_rate))*2;
                            var inr_rate2 = parseFloat(rate)*2;

                            // 3
                            var usd_rate3 = parseFloat(rate) / parseFloat(ex_rate)*3;
                            var inr_rate3 = parseFloat(rate)*3;

                            // 4
                            var usd_rate4 = parseFloat(rate) / parseFloat(ex_rate)*4;
                            var inr_rate4 = parseFloat(rate)*4;

                            // 5
                            var usd_rate5 = parseFloat(rate) / parseFloat(ex_rate)*5;
                            var inr_rate5 = parseFloat(rate)*5;

                            // 6
                            var usd_rate6 = parseFloat(rate) / parseFloat(ex_rate)*6;
                            var inr_rate6 = parseFloat(rate)*6;

                            // 8
                            var usd_rate8 = parseFloat(rate) / parseFloat(ex_rate)*8;
                            var inr_rate8 = parseFloat(rate)*8;

                            // 10
                            var usd_rate10 = parseFloat(rate) / parseFloat(ex_rate)*10;
                            var inr_rate10 = parseFloat(rate)*10;
                        }else{
                            // 2
                            var usd_rate2 = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate2 = rate;

                            // 3
                            var usd_rate3 = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate3 = rate;

                            // 4
                            var usd_rate4 = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate4 = rate;

                            // 5
                            var usd_rate5 = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate5 = rate;

                            // 6
                            var usd_rate6 = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate6 = rate;

                            // 8
                            var usd_rate8 = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate8 = rate;

                            // 10
                            var usd_rate10 = parseFloat(rate) / parseFloat(ex_rate);
                            var inr_rate10 = rate;
                        }

                    } else if (value.currency_id == currency_id_usd) {
                        if(value.extypid == 4){
                            var usd_rate = parseFloat(quantity)*parseFloat(rate);
                            var inr_rate = parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate);
                        }else{
                            var usd_rate = rate;
                            var inr_rate = parseFloat(rate) * parseFloat(ex_rate);
                        }
                        if(value.extypid == 4){
                            // 2
                            var usd_rate2 = (parseFloat(quantity)*parseFloat(rate))*2;
                            var inr_rate2 = (parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate))*2;

                            // 3
                            var usd_rate3 = parseFloat(quantity)*parseFloat(rate)*3;
                            var inr_rate3 = parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate)*3;

                            // 4
                            var usd_rate4 = parseFloat(quantity)*parseFloat(rate)*4;
                            var inr_rate4 = parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate)*4;

                            // 5
                            var usd_rate5 = parseFloat(quantity)*parseFloat(rate)*5;
                            var inr_rate5 = parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate)*5;

                            // 6
                            var usd_rate6 = parseFloat(quantity)*parseFloat(rate)*6;
                            var inr_rate6 = parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate)*6;

                            // 8
                            var usd_rate8 = parseFloat(quantity)*parseFloat(rate)*8;
                            var inr_rate8 = parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate)*8;

                            // 10
                            var usd_rate10 = parseFloat(quantity)*parseFloat(rate)*10;
                            var inr_rate10 = parseFloat(quantity)*parseFloat(rate) * parseFloat(ex_rate)*10;
                        }else if(value.extypid == 1){
                             // 2
                             var usd_rate2 = (parseFloat(rate))*2;
                            var inr_rate2 = (parseFloat(rate) * parseFloat(ex_rate))*2;

                            // 3
                            var usd_rate3 = parseFloat(rate)*3;
                            var inr_rate3 = parseFloat(rate) * parseFloat(ex_rate)*3;

                            // 4
                            var usd_rate4 = parseFloat(rate)*4;
                            var inr_rate4 = parseFloat(rate) * parseFloat(ex_rate)*4;

                            // 5
                            var usd_rate5 = parseFloat(rate)*5;
                            var inr_rate5 = parseFloat(rate) * parseFloat(ex_rate)*5;

                            // 6
                            var usd_rate6 = parseFloat(rate)*6;
                            var inr_rate6 = parseFloat(rate) * parseFloat(ex_rate)*6;

                            // 8
                            var usd_rate8 = parseFloat(rate)*8;
                            var inr_rate8 = parseFloat(rate) * parseFloat(ex_rate)*8;

                            // 10
                            var usd_rate10 = parseFloat(rate)*10;
                            var inr_rate10 = parseFloat(rate) * parseFloat(ex_rate)*10;
                        }else{
                            // 2
                            var usd_rate2 = rate;
                            var inr_rate2 = parseFloat(rate) * parseFloat(ex_rate);

                            // 3
                            var usd_rate3 = rate;
                            var inr_rate3 = parseFloat(rate) * parseFloat(ex_rate);

                            // 4
                            var usd_rate4 = rate;
                            var inr_rate4 = parseFloat(rate) * parseFloat(ex_rate);

                            // 5
                            var usd_rate5 = rate;
                            var inr_rate5 = parseFloat(rate) * parseFloat(ex_rate);

                            // 6
                            var usd_rate6 = rate;
                            var inr_rate6 = parseFloat(rate) * parseFloat(ex_rate);

                            // 8
                            var usd_rate8 = rate;
                            var inr_rate8 = parseFloat(rate) * parseFloat(ex_rate);

                            // 10
                            var usd_rate10 = rate;
                            var inr_rate10 = parseFloat(rate) * parseFloat(ex_rate);
                        }
                    } else {
                        if(value.extypid == 4){
                            var usd_rate = parseFloat(quantity)*parseFloat(rate);
                            var inr_rate = parseFloat(quantity)*parseFloat(rate);
                        }else{
                            var usd_rate = rate;
                            var inr_rate = rate;
                        }
                        if(value.extypid == 4 ){
                            // 2
                            var usd_rate2 = parseFloat(quantity)*parseFloat(rate)*2;
                            var inr_rate2 = parseFloat(quantity)*parseFloat(rate)*2;

                            // 3
                            var usd_rate3 = parseFloat(quantity)*parseFloat(rate)*3;
                            var inr_rate3 = parseFloat(quantity)*parseFloat(rate)*3;

                            // 4
                            var usd_rate4 = parseFloat(quantity)*parseFloat(rate)*4;
                            var inr_rate4 = parseFloat(quantity)*parseFloat(rate)*4;

                            // 5
                            var usd_rate5 = parseFloat(quantity)*parseFloat(rate)*5;
                            var inr_rate5 = parseFloat(quantity)*parseFloat(rate)*5;

                            // 6
                            var usd_rate6 = parseFloat(quantity)*parseFloat(rate)*6;
                            var inr_rate6 = parseFloat(quantity)*parseFloat(rate)*6;

                            // 8
                            var usd_rate8 = parseFloat(quantity)*parseFloat(rate)*8;
                            var inr_rate8 = parseFloat(quantity)*parseFloat(rate)*8;

                            // 10
                            var usd_rate10 = parseFloat(quantity)*parseFloat(rate)*10;
                            var inr_rate10 = parseFloat(quantity)*parseFloat(rate)*10;

                        }else if(value.extypid == 1){
                            // 2
                            var usd_rate2 = parseFloat(rate)*2;
                            var inr_rate2 = parseFloat(rate)*2;

                            // 3
                            var usd_rate3 = parseFloat(rate)*3;
                            var inr_rate3 = parseFloat(rate)*3;

                            // 4
                            var usd_rate4 = parseFloat(rate)*4;
                            var inr_rate4 = parseFloat(rate)*4;

                            // 5
                            var usd_rate5 = parseFloat(rate)*5;
                            var inr_rate5 = parseFloat(rate)*5;

                            // 6
                            var usd_rate6 = parseFloat(rate)*6;
                            var inr_rate6 = parseFloat(rate)*6;

                            // 8
                            var usd_rate8 = parseFloat(rate)*8;
                            var inr_rate8 = parseFloat(rate)*8;

                            // 10
                            var usd_rate10 = parseFloat(rate)*10;
                            var inr_rate10 = parseFloat(rate)*10;
                        }else{
                            // 2
                            var usd_rate2 = rate;
                            var inr_rate2 = rate;

                            // 3
                            var usd_rate3 = rate;
                            var inr_rate3 = rate;

                            // 4
                            var usd_rate4 = rate;
                            var inr_rate4 = rate;

                            // 4
                            var usd_rate4 = rate;
                            var inr_rate4 = rate;

                            // 5
                            var usd_rate5 = rate;
                            var inr_rate5 = rate;

                            // 6
                            var usd_rate6 = rate;
                            var inr_rate6 = rate;

                            // 8
                            var usd_rate8 = rate;
                            var inr_rate8 = rate;

                            // 10
                            var usd_rate10 = rate;
                            var inr_rate10 = rate;

                        }
                    }

                    exp_objectdata[index].usd_rate2 = usd_rate2;
                    exp_objectdata[index].inr_rate2 = inr_rate2;

                    if (value.lab_name == null) {
                        value.lab_name = '';
                    }
                    if (value.gst_name == null) {
                        value.gst_name = '';
                    }
                    var td_style = '';
                    if (value.buyer_id != null)
					{
                        td_style = 'background-color: #AFD5FF;';
                    }
                    exp_objectdata[index].gst_usd_amt = 0;
                    exp_objectdata[index].gst_inr_amt = 0;

                    // 2
                    exp_objectdata[index].gst_usd_amt2 = 0;
                    exp_objectdata[index].gst_inr_amt2 = 0;

                    // 3
                    exp_objectdata[index].gst_usd_amt3 = 0;
                    exp_objectdata[index].gst_inr_amt3 = 0;

                    // 4
                    exp_objectdata[index].gst_usd_amt4 = 0;
                    exp_objectdata[index].gst_inr_amt4 = 0;

                    // 5
                    exp_objectdata[index].gst_usd_amt5 = 0;
                    exp_objectdata[index].gst_inr_amt5 = 0;

                    // 6
                    exp_objectdata[index].gst_usd_amt6 = 0;
                    exp_objectdata[index].gst_inr_amt6 = 0;

                    // 8
                    exp_objectdata[index].gst_usd_amt8 = 0;
                    exp_objectdata[index].gst_inr_amt8 = 0;

                    // 10
                    exp_objectdata[index].gst_usd_amt10 = 0;
                    exp_objectdata[index].gst_inr_amt10 = 0;

                    checkbox_html = '';
                    if (value.is_checked) {
                        if (exp_objectdata[index].is_checked == '1') {
                            total_usd = parseFloat(total_usd) + parseFloat(usd_rate);
                            total_inr = parseFloat(total_inr) + parseFloat(inr_rate);
                            // 2
                            total_usd2 = parseFloat(total_usd2) + parseFloat(usd_rate2);
                            total_inr2 = parseFloat(total_inr2) + parseFloat(inr_rate2);

                            // 3
                            total_usd3 = parseFloat(total_usd3) + parseFloat(usd_rate3);
                            total_inr3 = parseFloat(total_inr3) + parseFloat(inr_rate3);

                            // 4
                            total_usd4 = parseFloat(total_usd4) + parseFloat(usd_rate4);
                            total_inr4 = parseFloat(total_inr4) + parseFloat(inr_rate4);

                            // 5
                            total_usd5 = parseFloat(total_usd5) + parseFloat(usd_rate5);
                            total_inr5 = parseFloat(total_inr5) + parseFloat(inr_rate5);

                            // 6
                            total_usd6 = parseFloat(total_usd6) + parseFloat(usd_rate6);
                            total_inr6 = parseFloat(total_inr6) + parseFloat(inr_rate6);

                            // 8
                            total_usd8 = parseFloat(total_usd8) + parseFloat(usd_rate8);
                            total_inr8 = parseFloat(total_inr8) + parseFloat(inr_rate8);

                            // 10
                            total_usd10 = parseFloat(total_usd10) + parseFloat(usd_rate10);
                            total_inr10 = parseFloat(total_inr10) + parseFloat(inr_rate10);


                            if (value.gst_name != '') {
                                exp_objectdata[index].gst_usd_amt = parseFloat(usd_rate) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt = parseFloat(inr_rate) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt = total_gst_usd_amt + exp_objectdata[index].gst_usd_amt;
                                total_gst_inr_amt = total_gst_inr_amt + exp_objectdata[index].gst_inr_amt;

                                // 2
                                exp_objectdata[index].gst_usd_amt2 = parseFloat(usd_rate2) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt2 = parseFloat(inr_rate2) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt2 = total_gst_usd_amt2 + exp_objectdata[index].gst_usd_amt2;
                                total_gst_inr_amt2 = total_gst_inr_amt2 + exp_objectdata[index].gst_inr_amt2;


                                // 3
                                exp_objectdata[index].gst_usd_amt3 = parseFloat(usd_rate3) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt3 = parseFloat(inr_rate3) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt3 = total_gst_usd_amt3 + exp_objectdata[index].gst_usd_amt3;
                                total_gst_inr_amt3 = total_gst_inr_amt3 + exp_objectdata[index].gst_inr_amt3;


                                // 4
                                exp_objectdata[index].gst_usd_amt4 = parseFloat(usd_rate4) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt4 = parseFloat(inr_rate4) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt4 = total_gst_usd_amt4 + exp_objectdata[index].gst_usd_amt4;
                                total_gst_inr_amt4 = total_gst_inr_amt4 + exp_objectdata[index].gst_inr_amt4;


                                // 5
                                exp_objectdata[index].gst_usd_amt5 = parseFloat(usd_rate5) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt5 = parseFloat(inr_rate5) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt5 = total_gst_usd_amt5 + exp_objectdata[index].gst_usd_amt5;
                                total_gst_inr_amt5 = total_gst_inr_amt5 + exp_objectdata[index].gst_inr_amt5;

                                // 6
                                exp_objectdata[index].gst_usd_amt6 = parseFloat(usd_rate6) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt6 = parseFloat(inr_rate6) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt6 = total_gst_usd_amt6 + exp_objectdata[index].gst_usd_amt6;
                                total_gst_inr_amt6 = total_gst_inr_amt6 + exp_objectdata[index].gst_inr_amt6;

                                // 8
                                exp_objectdata[index].gst_usd_amt8 = parseFloat(usd_rate8) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt8 = parseFloat(inr_rate8) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt8 = total_gst_usd_amt8 + exp_objectdata[index].gst_usd_amt8;
                                total_gst_inr_amt8 = total_gst_inr_amt8 + exp_objectdata[index].gst_inr_amt8;

                                // 10
                                exp_objectdata[index].gst_usd_amt10 = parseFloat(usd_rate10) * parseFloat(value
                                    .gst_name) / 100;
                                exp_objectdata[index].gst_inr_amt10 = parseFloat(inr_rate10) * parseFloat(value
                                    .gst_name) / 100;
                                total_gst_usd_amt10 = total_gst_usd_amt10 + exp_objectdata[index].gst_usd_amt10;
                                total_gst_inr_amt10 = total_gst_inr_amt10 + exp_objectdata[index].gst_inr_amt10;
                            }
                            checkbox_html = '<td style="' + td_style +
                                '"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id[' +
                                value.id + ']" checked data-key="' + index +
                                '" onchange="set_checkbox_checked(this);"></td>';
                        } else {
                            checkbox_html = '<td style="' + td_style +
                                '"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id[' +
                                value.id + ']"  data-key="' + index +
                                '" onchange="set_checkbox_checked(this);"></td>';
                        }
                    } else {
                            total_usd = parseFloat(total_usd) + parseFloat(usd_rate);
                            total_inr = parseFloat(total_inr) + parseFloat(inr_rate);

                        // 2
                        total_usd2 = parseFloat(total_usd2) + parseFloat(usd_rate2);
                        total_inr2 = parseFloat(total_inr2) + parseFloat(inr_rate2);

                        // 3
                        total_usd3 = parseFloat(total_usd3) + parseFloat(usd_rate3);
                        total_inr3 = parseFloat(total_inr3) + parseFloat(inr_rate3);

                        // 4
                        total_usd4 = parseFloat(total_usd4) + parseFloat(usd_rate4);
                        total_inr4 = parseFloat(total_inr4) + parseFloat(inr_rate4);

                        // 5
                        total_usd5 = parseFloat(total_usd5) + parseFloat(usd_rate5);
                        total_inr5 = parseFloat(total_inr5) + parseFloat(inr_rate5);

                        // 6
                        total_usd6 = parseFloat(total_usd6) + parseFloat(usd_rate6);
                        total_inr6 = parseFloat(total_inr6) + parseFloat(inr_rate6);

                        // 8
                        total_usd8 = parseFloat(total_usd8) + parseFloat(usd_rate8);
                        total_inr8 = parseFloat(total_inr8) + parseFloat(inr_rate8);

                        // 10
                        total_usd10 = parseFloat(total_usd10) + parseFloat(usd_rate10);
                        total_inr10 = parseFloat(total_inr10) + parseFloat(inr_rate10);

                        if (value.gst_name != '') {
                            exp_objectdata[index].gst_usd_amt = parseFloat(usd_rate) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt = parseFloat(inr_rate) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt = total_gst_usd_amt + exp_objectdata[index].gst_usd_amt;
                            total_gst_inr_amt = total_gst_inr_amt + exp_objectdata[index].gst_inr_amt;

                            // 2
                            exp_objectdata[index].gst_usd_amt2 = parseFloat(usd_rate2) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt2 = parseFloat(inr_rate2) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt2 = total_gst_usd_amt2 + exp_objectdata[index].gst_usd_amt2;
                            total_gst_inr_amt2 = total_gst_inr_amt2 + exp_objectdata[index].gst_inr_amt2;

                            // 3
                            exp_objectdata[index].gst_usd_amt3 = parseFloat(usd_rate3) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt3 = parseFloat(inr_rate3) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt3 = total_gst_usd_amt3 + exp_objectdata[index].gst_usd_amt3;
                            total_gst_inr_amt3 = total_gst_inr_amt3 + exp_objectdata[index].gst_inr_amt3;

                            // 4
                            exp_objectdata[index].gst_usd_amt4 = parseFloat(usd_rate4) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt4 = parseFloat(inr_rate4) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt4 = total_gst_usd_amt4 + exp_objectdata[index].gst_usd_amt4;
                            total_gst_inr_amt4 = total_gst_inr_amt4 + exp_objectdata[index].gst_inr_amt4;

                            // 5
                            exp_objectdata[index].gst_usd_amt5 = parseFloat(usd_rate5) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt5 = parseFloat(inr_rate5) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt5 = total_gst_usd_amt5 + exp_objectdata[index].gst_usd_amt5;
                            total_gst_inr_amt5 = total_gst_inr_amt5 + exp_objectdata[index].gst_inr_amt5;

                            // 6
                            exp_objectdata[index].gst_usd_amt6 = parseFloat(usd_rate6) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt6 = parseFloat(inr_rate6) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt6 = total_gst_usd_amt6 + exp_objectdata[index].gst_usd_amt6;
                            total_gst_inr_amt6 = total_gst_inr_amt6 + exp_objectdata[index].gst_inr_amt6;

                            // 8
                            exp_objectdata[index].gst_usd_amt8 = parseFloat(usd_rate8) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt8 = parseFloat(inr_rate8) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt8 = total_gst_usd_amt8 + exp_objectdata[index].gst_usd_amt8;
                            total_gst_inr_amt8 = total_gst_inr_amt8 + exp_objectdata[index].gst_inr_amt8;

                            // 10
                            exp_objectdata[index].gst_usd_amt10 = parseFloat(usd_rate10) * parseFloat(value.gst_name) /
                                100;
                            exp_objectdata[index].gst_inr_amt10 = parseFloat(inr_rate10) * parseFloat(value.gst_name) /
                                100;
                            total_gst_usd_amt10 = total_gst_usd_amt10 + exp_objectdata[index].gst_usd_amt10;
                            total_gst_inr_amt10 = total_gst_inr_amt10 + exp_objectdata[index].gst_inr_amt10;
                        }
                        exp_objectdata[index].is_checked = '1';
                        checkbox_html = '<td style="' + td_style +
                            '"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id[' + value
                            .id + ']" checked data-key="' + index +
                            '" onchange="set_checkbox_checked(this);"></td>';
                    }

                    exp_html += '<tr>';
                    exp_html += checkbox_html;
                    exp_html += '<td style="' + td_style + ' /*white-space:nowrap;*/">' + value.expense_name +
                        '</td>';
                    exp_html += '<td style="' + td_style + '">' + value.lab_name + '</td>';
                    if(TESTMODE)
                    exp_html += '<td style="' + td_style + '">' + value.extypid + '</td>';
                    if(TESTMODE)
                    exp_html += '<td style="' + td_style + '">' + value.expense_type_name + '</td>';
                    exp_html += '<td style="' + td_style + '" align="right">' + value.gst_name + '</td>';
                    exp_html += '<td style="' + td_style + '" align="right">' + parseFloat(usd_rate).toFixed(2) + '</td>';
                    if(TESTMODE)
                    exp_html += '<td style="' + td_style + '" align="right">' + parseFloat(usd_rate2).toFixed(2) + '</td>';
                    exp_html += '<td style="' + td_style + '" align="right">' + parseFloat(inr_rate).toFixed(2) + '</td>';
                    if(TESTMODE)
                    exp_html += '<td style="' + td_style + '" align="right">' + parseFloat(inr_rate2).toFixed(2) + '</td>';
                    exp_html += '</tr>';

                    exp_objectdata[index].id = value.id;
                    exp_objectdata[index].rate = value.rate;
                    exp_objectdata[index].currency_id = value.currency_id;
                    exp_objectdata[index].gst = value.gst_name;
                    exp_objectdata[index].gst_usd_amt = 0;
                    exp_objectdata[index].gst_inr_amt = 0;

                    exp_objectdata[index].usd_rate = usd_rate;
                    exp_objectdata[index].inr_rate = inr_rate;

                    // 2
                    exp_objectdata[index].gst_usd_amt2 = 0;
                    exp_objectdata[index].gst_inr_amt2 = 0;
                    exp_objectdata[index].usd_rate2 = usd_rate2;
                    exp_objectdata[index].inr_rate2 = inr_rate2;

                    // 3
                    exp_objectdata[index].gst_usd_amt3 = 0;
                    exp_objectdata[index].gst_inr_amt3 = 0;
                    exp_objectdata[index].usd_rate3 = usd_rate3;
                    exp_objectdata[index].inr_rate3 = inr_rate3;

                    // 4
                    exp_objectdata[index].gst_usd_amt4 = 0;
                    exp_objectdata[index].gst_inr_amt4 = 0;
                    exp_objectdata[index].usd_rate4 = usd_rate4;
                    exp_objectdata[index].inr_rate4 = inr_rate4;

                    // 5
                    exp_objectdata[index].gst_usd_amt5 = 0;
                    exp_objectdata[index].gst_inr_amt5 = 0;
                    exp_objectdata[index].usd_rate5 = usd_rate5;
                    exp_objectdata[index].inr_rate5 = inr_rate5;

                    // 6
                    exp_objectdata[index].gst_usd_amt6 = 0;
                    exp_objectdata[index].gst_inr_amt6 = 0;
                    exp_objectdata[index].usd_rate6 = usd_rate6;
                    exp_objectdata[index].inr_rate6 = inr_rate6;

                    // 8
                    exp_objectdata[index].gst_usd_amt8 = 0;
                    exp_objectdata[index].gst_inr_amt8 = 0;
                    exp_objectdata[index].usd_rate8 = usd_rate8;
                    exp_objectdata[index].inr_rate8 = inr_rate8;

                    // 10
                    exp_objectdata[index].gst_usd_amt10 = 0;
                    exp_objectdata[index].gst_inr_amt10 = 0;
                    exp_objectdata[index].usd_rate10 = usd_rate10;
                    exp_objectdata[index].inr_rate10 = inr_rate10;

                    //    console.log(exp_objectdata);
                });



                var discount_usd = parseFloat(basic_cost_usd) * parseFloat(discount_per) / 100;
                var discount_inr = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;

                var final_usd = parseFloat(total_usd) + total_gst_usd_amt - discount_usd;
                var final_inr = parseFloat(total_inr) + total_gst_inr_amt - discount_inr;

                discount_usd = parseFloat(discount_usd).toFixed(2);
                discount_inr = parseFloat(discount_inr).toFixed(2);


                // total_without_gst_usd_amt = total_usd - discount_usd;
                // total_without_gst_inr_amt = total_inr - discount_inr;
                // total_without_gst_usd_amt = parseFloat(total_without_gst_usd_amt).toFixed(2);
                // total_without_gst_inr_amt = parseFloat(total_without_gst_inr_amt).toFixed(2);

                // var final_usd = parseFloat(total_usd) + total_gst_usd_amt - discount_usd;
                // var final_inr = parseFloat(total_inr) + total_gst_inr_amt - discount_inr;

                // final_usd = parseFloat(final_usd).toFixed(2);
                // final_inr = parseFloat(final_inr).toFixed(2);
                // var for_1_unit_usd = parseFloat(final_usd) / parseFloat(quantity);
                // var for_1_unit_inr = parseFloat(final_inr) / parseFloat(quantity);
                // for_1_unit_usd = parseFloat(for_1_unit_usd).toFixed(2);
                // for_1_unit_inr = parseFloat(for_1_unit_inr).toFixed(2);
                // var brokerage_amount = total_without_gst_inr_amt * brokerage_per / 100;

                // 2
                var discount_usd2 = parseFloat(basic_cost_usd2) * parseFloat(discount_per) / 100;
                var discount_inr2 = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;
                var final_usd2 = parseFloat(total_usd2) + total_gst_usd_amt2 - discount_usd2;
                var final_inr2 = parseFloat(total_inr2) + total_gst_inr_amt2 - discount_inr2;
                discount_usd2 = parseFloat(discount_usd2).toFixed(2);
                discount_inr2 = parseFloat(discount_inr2).toFixed(2);

                // total_without_gst_usd_amt2 = total_usd2 - discount_usd2;
                // total_without_gst_inr_amt2 = total_inr2 - discount_inr2;
                // total_without_gst_usd_amt2 = parseFloat(total_without_gst_usd_amt2).toFixed(2);
                // total_without_gst_inr_amt2 = parseFloat(total_without_gst_inr_amt2).toFixed(2);
                // var final_usd2 = parseFloat(total_usd2) + total_gst_usd_amt2 - discount_usd2;
                // var final_inr2 = parseFloat(total_inr2) + total_gst_inr_amt2 - discount_inr2;
                // final_usd2 = parseFloat(final_usd2).toFixed(2);
                // final_inr2 = parseFloat(final_inr2).toFixed(2);
                // var for_1_unit_usd2 = parseFloat(final_usd2) / parseFloat(quantity);
                // var for_1_unit_inr2 = parseFloat(final_inr2) / parseFloat(quantity);
                // for_1_unit_usd2 = parseFloat(for_1_unit_usd2).toFixed(2);
                // for_1_unit_inr2 = parseFloat(for_1_unit_inr2).toFixed(2);
                // var brokerage_amount2 = total_without_gst_inr_amt2 * brokerage_per / 100;

                // =IF(Days<25,Total*11*Days/36500 else SUM(Total*11*25/36500+Total*14*(Days-25)/36500))

                // 3
                var discount_usd3 = parseFloat(basic_cost_usd3) * parseFloat(discount_per) / 100;
                var discount_inr3 = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;
                var final_usd3 = parseFloat(total_usd3) + total_gst_usd_amt3 - discount_usd3;
                var final_inr3 = parseFloat(total_inr3) + total_gst_inr_amt3 - discount_inr3;
                discount_usd3 = parseFloat(discount_usd3).toFixed(2);
                discount_inr3 = parseFloat(discount_inr3).toFixed(2);

                // 4
                var discount_usd4 = parseFloat(basic_cost_usd4) * parseFloat(discount_per) / 100;
                var discount_inr4 = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;
                var final_usd4 = parseFloat(total_usd4) + total_gst_usd_amt4 - discount_usd4;
                var final_inr4 = parseFloat(total_inr4) + total_gst_inr_amt4 - discount_inr4;
                discount_usd4 = parseFloat(discount_usd4).toFixed(2);
                discount_inr4 = parseFloat(discount_inr4).toFixed(2);

                // 5
                var discount_usd5 = parseFloat(basic_cost_usd5) * parseFloat(discount_per) / 100;
                var discount_inr5 = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;
                var final_usd5 = parseFloat(total_usd5) + total_gst_usd_amt5 - discount_usd5;
                var final_inr5 = parseFloat(total_inr5) + total_gst_inr_amt5 - discount_inr5;
                discount_usd5 = parseFloat(discount_usd5).toFixed(2);
                discount_inr5 = parseFloat(discount_inr5).toFixed(2);

                // 6
                var discount_usd6 = parseFloat(basic_cost_usd6) * parseFloat(discount_per) / 100;
                var discount_inr6 = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;
                var final_usd6 = parseFloat(total_usd6) + total_gst_usd_amt6 - discount_usd6;
                var final_inr6 = parseFloat(total_inr6) + total_gst_inr_amt6 - discount_inr6;
                discount_usd6 = parseFloat(discount_usd6).toFixed(2);
                discount_inr6 = parseFloat(discount_inr6).toFixed(2);

                // 8
                var discount_usd8 = parseFloat(basic_cost_usd8) * parseFloat(discount_per) / 100;
                var discount_inr8 = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;
                var final_usd8 = parseFloat(total_usd8) + total_gst_usd_amt8 - discount_usd8;
                var final_inr8 = parseFloat(total_inr8) + total_gst_inr_amt8 - discount_inr8;
                discount_usd8 = parseFloat(discount_usd8).toFixed(2);
                discount_inr8 = parseFloat(discount_inr8).toFixed(2);

                // 10
                var discount_usd10 = parseFloat(basic_cost_usd10) * parseFloat(discount_per) / 100;
                var discount_inr10 = parseFloat(basic_cost_inr) * parseFloat(discount_per) / 100;
                var final_usd10 = parseFloat(total_usd10) + total_gst_usd_amt10 - discount_usd10;
                var final_inr10 = parseFloat(total_inr10) + total_gst_inr_amt10 - discount_inr10;
                discount_usd10 = parseFloat(discount_usd10).toFixed(2);
                discount_inr10 = parseFloat(discount_inr10).toFixed(2);



                var bank_int_usd=0;
                var bank_int_inr=0;
                // 2
                var bank_int_usd2=0;
                var bank_int_inr2=0;

                // 3
                var bank_int_usd3=0;
                var bank_int_inr3=0;
                // 4
                var bank_int_usd4=0;
                var bank_int_inr4=0;
                // 5
                var bank_int_usd5=0;
                var bank_int_inr5=0;
                // 6
                var bank_int_usd6=0;
                var bank_int_inr6=0;
                // 8
                var bank_int_usd8=0;
                var bank_int_inr8=0;
                // 10
                var bank_int_usd10=0;
                var bank_int_inr10=0;

                var days=0;

                if($('#days').val() != undefined && $('#days').val() != ''){
                    days=$('#days').val();
                }
                if(days<PenalAfterDay){
                    bank_int_usd=total_usd*normalper*days/36500;
                    bank_int_inr=total_inr*normalper*days/36500;
                    // 2
                    bank_int_usd2=total_usd2*normalper*days/36500;
                    bank_int_inr2=total_inr2*normalper*days/36500;
                    // 3
                    bank_int_usd3=total_usd3*normalper*days/36500;
                    bank_int_inr3=total_inr3*normalper*days/36500;
                    // 4
                    bank_int_usd4=total_usd4*normalper*days/36500;
                    bank_int_inr4=total_inr4*normalper*days/36500;
                    // 5
                    bank_int_usd5=total_usd5*normalper*days/36500;
                    bank_int_inr5=total_inr5*normalper*days/36500;
                    // 6
                    bank_int_usd6=total_usd6*normalper*days/36500;
                    bank_int_inr6=total_inr6*normalper*days/36500;
                    // 8
                    bank_int_usd8=total_usd8*normalper*days/36500;
                    bank_int_inr8=total_inr8*normalper*days/36500;
                    // 10
                    bank_int_usd10=total_usd10*normalper*days/36500;
                    bank_int_inr10=total_inr10*normalper*days/36500;
                }else{
                    bank_int_usd=(total_usd*normalper*PenalAfterDay/36500)+(total_usd*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr=(total_inr*normalper*PenalAfterDay/36500)+(total_inr*penalper*(days-PenalAfterDay)/36500);
                    // 2
                    bank_int_usd2=(total_usd2*normalper*PenalAfterDay/36500)+(total_usd2*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr2=(total_inr2*normalper*PenalAfterDay/36500)+(total_inr2*penalper*(days-PenalAfterDay)/36500);
                    // 3
                    bank_int_usd3=(total_usd3*normalper*PenalAfterDay/36500)+(total_usd3*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr3=(total_inr3*normalper*PenalAfterDay/36500)+(total_inr3*penalper*(days-PenalAfterDay)/36500);
                    // 4
                    bank_int_usd4=(total_usd4*normalper*PenalAfterDay/36500)+(total_usd4*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr4=(total_inr4*normalper*PenalAfterDay/36500)+(total_inr4*penalper*(days-PenalAfterDay)/36500);
                    // 5
                    bank_int_usd5=(total_usd5*normalper*PenalAfterDay/36500)+(total_usd5*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr5=(total_inr5*normalper*PenalAfterDay/36500)+(total_inr5*penalper*(days-PenalAfterDay)/36500);
                    // 6
                    bank_int_usd6=(total_usd6*normalper*PenalAfterDay/36500)+(total_usd6*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr6=(total_inr6*normalper*PenalAfterDay/36500)+(total_inr6*penalper*(days-PenalAfterDay)/36500);
                    // 8
                    bank_int_usd8=(total_usd8*normalper*PenalAfterDay/36500)+(total_usd8*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr8=(total_inr8*normalper*PenalAfterDay/36500)+(total_inr8*penalper*(days-PenalAfterDay)/36500);
                    // 10
                    bank_int_usd10=(total_usd10*normalper*PenalAfterDay/36500)+(total_usd10*penalper*(days-PenalAfterDay)/36500);
                    bank_int_inr10=(total_inr10*normalper*PenalAfterDay/36500)+(total_inr10*penalper*(days-PenalAfterDay)/36500);
                }

                // ADD Bank INT In filnal
                final_usd=parseFloat(final_usd)+parseFloat(bank_int_usd);
                final_inr=parseFloat(final_inr)+parseFloat(bank_int_inr);
                // 2
                final_usd2=parseFloat(final_usd2)+parseFloat(bank_int_usd2);
                final_inr2=parseFloat(final_inr2)+parseFloat(bank_int_inr2);
                // 3
                final_usd3=parseFloat(final_usd3)+parseFloat(bank_int_usd3);
                final_inr3=parseFloat(final_inr3)+parseFloat(bank_int_inr3);
                // 4
                final_usd4=parseFloat(final_usd4)+parseFloat(bank_int_usd4);
                final_inr4=parseFloat(final_inr4)+parseFloat(bank_int_inr4);
                // 5
                final_usd5=parseFloat(final_usd5)+parseFloat(bank_int_usd5);
                final_inr5=parseFloat(final_inr5)+parseFloat(bank_int_inr5);
                // 6
                final_usd6=parseFloat(final_usd6)+parseFloat(bank_int_usd6);
                final_inr6=parseFloat(final_inr6)+parseFloat(bank_int_inr6);
                // 8
                final_usd8=parseFloat(final_usd8)+parseFloat(bank_int_usd8);
                final_inr8=parseFloat(final_inr8)+parseFloat(bank_int_inr8);
                // 10
                final_usd10=parseFloat(final_usd10)+parseFloat(bank_int_usd10);
                final_inr10=parseFloat(final_inr10)+parseFloat(bank_int_inr10);


                // CALCULATE FINAL IN RS
                var final_in_rs_usd = parseFloat(bank_int_usd) + parseFloat(total_usd);
                var final_in_rs_inr = parseFloat(bank_int_inr) + parseFloat(total_inr);
                // 2
                var final_in_rs_usd2 = parseFloat(bank_int_usd2) + parseFloat(total_usd2);
                var final_in_rs_inr2 = parseFloat(bank_int_inr2) + parseFloat(total_inr2);
                // 3
                var final_in_rs_usd3 = parseFloat(bank_int_usd3) + parseFloat(total_usd3);
                var final_in_rs_inr3 = parseFloat(bank_int_inr3) + parseFloat(total_inr3);
                // 4
                var final_in_rs_usd4 = parseFloat(bank_int_usd4) + parseFloat(total_usd4);
                var final_in_rs_inr4 = parseFloat(bank_int_inr4) + parseFloat(total_inr4);
                // 5
                var final_in_rs_usd5 = parseFloat(bank_int_usd5) + parseFloat(total_usd5);
                var final_in_rs_inr5 = parseFloat(bank_int_inr5) + parseFloat(total_inr5);
                // 6
                var final_in_rs_usd6 = parseFloat(bank_int_usd6) + parseFloat(total_usd6);
                var final_in_rs_inr6 = parseFloat(bank_int_inr6) + parseFloat(total_inr6);
                // 8
                var final_in_rs_usd8 = parseFloat(bank_int_usd8) + parseFloat(total_usd8);
                var final_in_rs_inr8 = parseFloat(bank_int_inr8) + parseFloat(total_inr8);
                // 10
                var final_in_rs_usd10 = parseFloat(bank_int_usd10) + parseFloat(total_usd10);
                var final_in_rs_inr10 = parseFloat(bank_int_inr10) + parseFloat(total_inr10);

                // CALCULATE INSURANCE
                var insu_1 = 0;
                var insu_2 = 0;
                if($('#insu_1').val() != ''){
                    insu_1 = $('#insu_1').val();
                }
                if($('#insu_2').val() != ''){
                    insu_2 = $('#insu_2').val();
                }
                var insurance_inr= parseFloat(final_in_rs_inr)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd=parseFloat(insurance_inr)/parseFloat(ex_rate);
                // 2
                var insurance_inr2=parseFloat(final_in_rs_inr2)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd2=parseFloat(insurance_inr2)/parseFloat(ex_rate);
                // 3
                var insurance_inr3=parseFloat(final_in_rs_inr3)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd3=parseFloat(insurance_inr3)/parseFloat(ex_rate);
                // 4
                var insurance_inr4=parseFloat(final_in_rs_inr4)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd4=parseFloat(insurance_inr4)/parseFloat(ex_rate);
                // 5
                var insurance_inr5=parseFloat(final_in_rs_inr5)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd5=parseFloat(insurance_inr5)/parseFloat(ex_rate);
                // 6
                var insurance_inr6=parseFloat(final_in_rs_inr6)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd6=parseFloat(insurance_inr6)/parseFloat(ex_rate);
                //8
                var insurance_inr8=parseFloat(final_in_rs_inr8)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd8=parseFloat(insurance_inr8)/parseFloat(ex_rate);
                //10
                var insurance_inr10=parseFloat(final_in_rs_inr10)*parseFloat(insu_1)*parseFloat(insu_2)/100;
                var insurance_usd10=parseFloat(insurance_inr10)/parseFloat(ex_rate);

                // ADD INSURANCE IN Final
                final_usd=parseFloat(final_usd)+parseFloat(insurance_usd);
                final_inr=parseFloat(final_inr)+parseFloat(insurance_inr);
                // 2
                final_usd2=parseFloat(final_usd2)+parseFloat(insurance_usd2);
                final_inr2=parseFloat(final_inr2)+parseFloat(insurance_inr2);
                // 3
                final_usd3=parseFloat(final_usd3)+parseFloat(insurance_usd3);
                final_inr3=parseFloat(final_inr3)+parseFloat(insurance_inr3);
                // 4
                final_usd4=parseFloat(final_usd4)+parseFloat(insurance_usd4);
                final_inr4=parseFloat(final_inr4)+parseFloat(insurance_inr4);
                // 5
                final_usd5=parseFloat(final_usd5)+parseFloat(insurance_usd5);
                final_inr5=parseFloat(final_inr5)+parseFloat(insurance_inr5);
                // 6
                final_usd6=parseFloat(final_usd6)+parseFloat(insurance_usd6);
                final_inr6=parseFloat(final_inr6)+parseFloat(insurance_inr6);
                // 8
                final_usd8=parseFloat(final_usd8)+parseFloat(insurance_usd8);
                final_inr8=parseFloat(final_inr8)+parseFloat(insurance_inr8);
                // 10
                final_usd10=parseFloat(final_usd10)+parseFloat(insurance_usd10);
                final_inr10=parseFloat(final_inr10)+parseFloat(insurance_inr10);



                // Freight CALCULATION
                var freight = 0;
                if($('#freight').val() != undefined && $('#freight').val() != ''){
                    freight = $('#freight').val();
                }
                var freight_usd = parseFloat(freight);
                var freight_inr = parseFloat(freight_usd)*ex_rate;
                //2
                var freight_usd2 = parseFloat(freight);
                var freight_inr2 = parseFloat(freight_usd2)*ex_rate*2;
                //3
                var freight_usd3 = parseFloat(freight);
                var freight_inr3 = parseFloat(freight_usd3)*ex_rate*3;
                //4
                var freight_usd4 = parseFloat(freight);
                var freight_inr4 = parseFloat(freight_usd4)*ex_rate*4;
                //5
                var freight_usd5 = parseFloat(freight);
                var freight_inr5 = parseFloat(freight_usd5)*ex_rate*5;
                //6
                var freight_usd6 = parseFloat(freight);
                var freight_inr6 = parseFloat(freight_usd6)*ex_rate*6;
                //8
                var freight_usd8 = parseFloat(freight);
                var freight_inr8 = parseFloat(freight_usd8)*ex_rate*8;
                //10
                var freight_usd10 = parseFloat(freight);
                var freight_inr10 = parseFloat(freight_usd10)*ex_rate*10;

                // ADD Freight In Final
                final_usd=parseFloat(final_usd)+parseFloat(freight_usd);
                final_inr=parseFloat(final_inr)+parseFloat(freight_inr);
                // 2
                final_usd2=parseFloat(final_usd2)+parseFloat(freight_usd2);
                final_inr2=parseFloat(final_inr2)+parseFloat(freight_inr2);
                // 3
                final_usd3=parseFloat(final_usd3)+parseFloat(freight_usd3);
                final_inr3=parseFloat(final_inr3)+parseFloat(freight_inr3);
                // 4
                final_usd4=parseFloat(final_usd4)+parseFloat(freight_usd4);
                final_inr4=parseFloat(final_inr4)+parseFloat(freight_inr4);
                // 5
                final_usd5=parseFloat(final_usd5)+parseFloat(freight_usd5);
                final_inr5=parseFloat(final_inr5)+parseFloat(freight_inr5);
                // 6
                final_usd6=parseFloat(final_usd6)+parseFloat(freight_usd6);
                final_inr6=parseFloat(final_inr6)+parseFloat(freight_inr6);
                // 8
                final_usd8=parseFloat(final_usd8)+parseFloat(freight_usd8);
                final_inr8=parseFloat(final_inr8)+parseFloat(freight_inr8);
                // 10
                final_usd10=parseFloat(final_usd10)+parseFloat(freight_usd10);
                final_inr10=parseFloat(final_inr10)+parseFloat(freight_inr10);


                // GET PACKING Data
                var packing_id = $('#packing_id').val();
                var packing_usd = 0;
                var packing_inr = 0;
                // 2
                var packing_usd2 = 0;
                var packing_inr2 = 0;
                // 3
                var packing_usd3 = 0;
                var packing_inr3 = 0;
                // 4
                var packing_usd4 = 0;
                var packing_inr4 = 0;
                // 5
                var packing_usd5 = 0;
                var packing_inr5 = 0;
                // 6
                var packing_usd6 = 0;
                var packing_inr6 = 0;
                // 8
                var packing_usd8 = 0;
                var packing_inr8 = 0;
                // 10
                var packing_usd10 = 0;
                var packing_inr10 = 0;

                var ac_id=$('#buyer_id').val();
                var commodity_id=$('#commodity_id').val();
                var packing_cost_type = '';

                if(packing_id != ''){
                    $.ajax({
                            url: "{{ URL::to('/get_packing_val_by_id/') }}/" + packing_id + "/" +ac_id+ "/" +commodity_id ,
                            type: "GET",
                            cache: false,
                            data: {},
                            async: false,
                            success: function(response) {
                                if(response.success){
                                    packing_cost_type = response.cost_type;
                                    packing_usd = parseFloat(response.packing_cost)*parseFloat(quantity);
                                    packing_inr = parseFloat(packing_usd)*parseFloat(ex_rate);
                                    // 2
                                    packing_usd2 = parseFloat(response.packing_cost)*parseFloat(quantity)*2;
                                    packing_inr2 = parseFloat(packing_usd2)*parseFloat(ex_rate);
                                    // 3
                                    packing_usd3 = parseFloat(response.packing_cost)*parseFloat(quantity)*3;
                                    packing_inr3 = parseFloat(packing_usd3)*parseFloat(ex_rate);
                                    // 4
                                    packing_usd4 = parseFloat(response.packing_cost)*parseFloat(quantity)*4;
                                    packing_inr4 = parseFloat(packing_usd4)*parseFloat(ex_rate);
                                    // 5
                                    packing_usd5 = parseFloat(response.packing_cost)*parseFloat(quantity)*5;
                                    packing_inr5 = parseFloat(packing_usd5)*parseFloat(ex_rate);
                                    // 6
                                    packing_usd6 = parseFloat(response.packing_cost)*parseFloat(quantity)*6;
                                    packing_inr6 = parseFloat(packing_usd6)*parseFloat(ex_rate);
                                    // 8
                                    packing_usd8 = parseFloat(response.packing_cost)*parseFloat(quantity)*8;
                                    packing_inr8 = parseFloat(packing_usd8)*parseFloat(ex_rate);
                                    // 10
                                    packing_usd10 = parseFloat(response.packing_cost)*parseFloat(quantity)*10;
                                    packing_inr10 = parseFloat(packing_usd10)*parseFloat(ex_rate);

                                }
                            }
                        });
                }

                // ADD PACKING In Packing
                final_usd=parseFloat(final_usd)+parseFloat(packing_usd);
                final_inr=parseFloat(final_inr)+parseFloat(packing_inr);
                // 2
                final_usd2=parseFloat(final_usd2)+parseFloat(packing_usd2);
                final_inr2=parseFloat(final_inr2)+parseFloat(packing_inr2);
                // 3
                final_usd3=parseFloat(final_usd3)+parseFloat(packing_usd3);
                final_inr3=parseFloat(final_inr3)+parseFloat(packing_inr3);
                // 4
                final_usd4=parseFloat(final_usd4)+parseFloat(packing_usd4);
                final_inr4=parseFloat(final_inr4)+parseFloat(packing_inr4);
                // 5
                final_usd5=parseFloat(final_usd5)+parseFloat(packing_usd5);
                final_inr5=parseFloat(final_inr5)+parseFloat(packing_inr5);
                // 6
                final_usd6=parseFloat(final_usd6)+parseFloat(packing_usd6);
                final_inr6=parseFloat(final_inr6)+parseFloat(packing_inr6);
                // 8
                final_usd8=parseFloat(final_usd8)+parseFloat(packing_usd8);
                final_inr8=parseFloat(final_inr8)+parseFloat(packing_inr8);
                // 10
                final_usd10=parseFloat(final_usd10)+parseFloat(packing_usd10);
                final_inr10=parseFloat(final_inr10)+parseFloat(packing_inr10);

                // Make Total
                total_without_gst_usd_amt = parseFloat(total_usd) - parseFloat(discount_usd);
                total_without_gst_inr_amt = parseFloat(total_inr) - parseFloat(discount_inr);
                total_without_gst_usd_amt = parseFloat(total_without_gst_usd_amt).toFixed(2);
                total_without_gst_inr_amt = parseFloat(total_without_gst_inr_amt).toFixed(2);
                var for_1_unit_usd = parseFloat(final_usd) / parseFloat(quantity);
                var for_1_unit_inr = parseFloat(final_inr) / parseFloat(quantity);
                for_1_unit_usd = parseFloat(for_1_unit_usd).toFixed(2);
                for_1_unit_inr = parseFloat(for_1_unit_inr).toFixed(2);
                final_usd = parseFloat(final_usd).toFixed(2);
                final_inr = parseFloat(final_inr).toFixed(2);
                var brokerage_amount = total_without_gst_inr_amt * brokerage_per / 100;

                //2
                total_without_gst_usd_amt2 = parseFloat(total_usd2) - parseFloat(discount_usd2);
                total_without_gst_inr_amt2 = parseFloat(total_inr2) - parseFloat(discount_inr2);
                total_without_gst_usd_amt2 = parseFloat(total_without_gst_usd_amt2).toFixed(2);
                total_without_gst_inr_amt2 = parseFloat(total_without_gst_inr_amt2).toFixed(2);
                // var for_1_unit_usd2 = parseFloat(final_usd2) / parseFloat(quantity);
                // var for_1_unit_inr2 = parseFloat(final_inr2) / parseFloat(quantity);

                var for_1_unit_usd2 = parseFloat(final_usd2) / parseFloat(ex_rate)/2;
                var for_1_unit_inr2 = parseFloat(final_inr2) / parseFloat(ex_rate)/2;

                for_1_unit_usd2 = parseFloat(for_1_unit_usd2).toFixed(2);
                for_1_unit_inr2 = parseFloat(for_1_unit_inr2).toFixed(2);
                final_usd2 = parseFloat(final_usd2).toFixed(2);
                final_inr2 = parseFloat(final_inr2).toFixed(2);
                var brokerage_amount2 = total_without_gst_inr_amt2 * brokerage_per / 100;

                //3
                total_without_gst_usd_amt3 = parseFloat(total_usd3) - parseFloat(discount_usd3);
                total_without_gst_inr_amt3 = parseFloat(total_inr3) - parseFloat(discount_inr3);
                total_without_gst_usd_amt3 = parseFloat(total_without_gst_usd_amt3).toFixed(2);
                total_without_gst_inr_amt3 = parseFloat(total_without_gst_inr_amt3).toFixed(2);
                // var for_1_unit_usd3 = parseFloat(final_usd3) / parseFloat(quantity);
                // var for_1_unit_inr3 = parseFloat(final_inr3) / parseFloat(quantity);

                var for_1_unit_usd3 = parseFloat(final_usd3) / parseFloat(ex_rate)/3;
                var for_1_unit_inr3 = parseFloat(final_inr3) / parseFloat(ex_rate)/3;

                for_1_unit_usd3 = parseFloat(for_1_unit_usd3).toFixed(2);
                for_1_unit_inr3 = parseFloat(for_1_unit_inr3).toFixed(2);
                final_usd3 = parseFloat(final_usd3).toFixed(2);
                final_inr3 = parseFloat(final_inr3).toFixed(2);
                var brokerage_amount3 = total_without_gst_inr_amt3 * brokerage_per / 100;

                //4
                total_without_gst_usd_amt4 = parseFloat(total_usd4) - parseFloat(discount_usd4);
                total_without_gst_inr_amt4 = parseFloat(total_inr4) - parseFloat(discount_inr4);
                total_without_gst_usd_amt4 = parseFloat(total_without_gst_usd_amt4).toFixed(2);
                total_without_gst_inr_amt4 = parseFloat(total_without_gst_inr_amt4).toFixed(2);
                // var for_1_unit_usd4 = parseFloat(final_usd4) / parseFloat(quantity);
                // var for_1_unit_inr4 = parseFloat(final_inr4) / parseFloat(quantity);

                var for_1_unit_usd4 = parseFloat(final_usd4) / parseFloat(ex_rate)/4;
                var for_1_unit_inr4 = parseFloat(final_inr4) / parseFloat(ex_rate)/4;

                for_1_unit_usd4 = parseFloat(for_1_unit_usd4).toFixed(2);
                for_1_unit_inr4 = parseFloat(for_1_unit_inr4).toFixed(2);
                final_usd4 = parseFloat(final_usd4).toFixed(4);
                final_inr4 = parseFloat(final_inr4).toFixed(4);
                var brokerage_amount4 = total_without_gst_inr_amt4 * brokerage_per / 100;

                //5
                total_without_gst_usd_amt5 = parseFloat(total_usd5) - parseFloat(discount_usd5);
                total_without_gst_inr_amt5 = parseFloat(total_inr5) - parseFloat(discount_inr5);
                total_without_gst_usd_amt5 = parseFloat(total_without_gst_usd_amt5).toFixed(2);
                total_without_gst_inr_amt5 = parseFloat(total_without_gst_inr_amt5).toFixed(2);
                // var for_1_unit_usd5 = parseFloat(final_usd5) / parseFloat(quantity);
                // var for_1_unit_inr5 = parseFloat(final_inr5) / parseFloat(quantity);

                var for_1_unit_usd5 = parseFloat(final_usd5) / parseFloat(ex_rate)/5;
                var for_1_unit_inr5 = parseFloat(final_inr5) / parseFloat(ex_rate)/5;

                for_1_unit_usd5 = parseFloat(for_1_unit_usd5).toFixed(2);
                for_1_unit_inr5 = parseFloat(for_1_unit_inr5).toFixed(2);
                final_usd5 = parseFloat(final_usd5).toFixed(2);
                final_inr5 = parseFloat(final_inr5).toFixed(2);
                var brokerage_amount5 = total_without_gst_inr_amt5 * brokerage_per / 100;

                //6
                total_without_gst_usd_amt6 = parseFloat(total_usd6) - parseFloat(discount_usd6);
                total_without_gst_inr_amt6 = parseFloat(total_inr6) - parseFloat(discount_inr6);
                total_without_gst_usd_amt6 = parseFloat(total_without_gst_usd_amt6).toFixed(2);
                total_without_gst_inr_amt6 = parseFloat(total_without_gst_inr_amt6).toFixed(2);
                // var for_1_unit_usd6 = parseFloat(final_usd6) / parseFloat(quantity);
                // var for_1_unit_inr6 = parseFloat(final_inr6) / parseFloat(quantity);

                var for_1_unit_usd6 = parseFloat(final_usd6) / parseFloat(ex_rate)/6;
                var for_1_unit_inr6 = parseFloat(final_inr6) / parseFloat(ex_rate)/6;


                for_1_unit_usd6 = parseFloat(for_1_unit_usd6).toFixed(2);
                for_1_unit_inr6 = parseFloat(for_1_unit_inr6).toFixed(2);
                final_usd6 = parseFloat(final_usd6).toFixed(2);
                final_inr6 = parseFloat(final_inr6).toFixed(2);
                var brokerage_amount6 = total_without_gst_inr_amt6 * brokerage_per / 100;

                //8
                total_without_gst_usd_amt8 = parseFloat(total_usd8) - parseFloat(discount_usd8);
                total_without_gst_inr_amt8 = parseFloat(total_inr8) - parseFloat(discount_inr8);
                total_without_gst_usd_amt8 = parseFloat(total_without_gst_usd_amt8).toFixed(2);
                total_without_gst_inr_amt8 = parseFloat(total_without_gst_inr_amt8).toFixed(2);
                // var for_1_unit_usd8 = parseFloat(final_usd8) / parseFloat(quantity);
                // var for_1_unit_inr8 = parseFloat(final_inr8) / parseFloat(quantity);

                var for_1_unit_usd8 = parseFloat(final_usd8) / parseFloat(ex_rate)/8;
                var for_1_unit_inr8 = parseFloat(final_inr8) / parseFloat(ex_rate)/8;

                for_1_unit_usd8 = parseFloat(for_1_unit_usd8).toFixed(2);
                for_1_unit_inr8 = parseFloat(for_1_unit_inr8).toFixed(2);
                final_usd8 = parseFloat(final_usd8).toFixed(2);
                final_inr8 = parseFloat(final_inr8).toFixed(2);
                var brokerage_amount8 = total_without_gst_inr_amt8 * brokerage_per / 100;

                //10
                total_without_gst_usd_amt10 = parseFloat(total_usd10) - parseFloat(discount_usd10);
                total_without_gst_inr_amt10 = parseFloat(total_inr10) - parseFloat(discount_inr10);
                total_without_gst_usd_amt10 = parseFloat(total_without_gst_usd_amt10).toFixed(2);
                total_without_gst_inr_amt10 = parseFloat(total_without_gst_inr_amt10).toFixed(2);
                // var for_1_unit_usd10 = parseFloat(final_usd10) / parseFloat(quantity);
                // var for_1_unit_inr10 = parseFloat(final_inr10) / parseFloat(quantity);

                var for_1_unit_usd10 = parseFloat(final_usd10) / parseFloat(ex_rate)/10;
                var for_1_unit_inr10 = parseFloat(final_inr10) / parseFloat(ex_rate)/10;

                for_1_unit_usd10 = parseFloat(for_1_unit_usd10).toFixed(2);
                for_1_unit_inr10 = parseFloat(for_1_unit_inr10).toFixed(2);
                final_usd10 = parseFloat(final_usd10).toFixed(2);
                final_inr10 = parseFloat(final_inr10).toFixed(2);
                var brokerage_amount10 = total_without_gst_inr_amt10 * brokerage_per / 100;
               
                 //Code By Rashid  Start//
                 var AdditionalLabTaxTotal= parseFloat($('#expenses_total').text()).toFixed();
                //console.log(AdditionalLabTaxTotal);
              
              // total_inr = parseFloat(parseFloat(total_inr) + AdditionalLabTaxTotal).toFixed(2);
                total_inr = parseFloat(parseFloat(total_inr) + parseFloat(AdditionalLabTaxTotal));
              // console.log(total_inr);
              if(total_inr>0)
                {
                   var CreditDays=$('#days').val(); 
             //    total_inr=parseFloat(parseFloat(total_inr)-380).toFixed(2);
              
              var bank_int_normal=  parseFloat($('#bank_int_normal').val()).toFixed(2);
                                   
                                   bank_int_normal=parseFloat(parseFloat(bank_int_normal)+parseFloat(total_inr));
                                  // console.log("Bank Int Normal2 " +bank_int_normal);
                                 //  console.log("Total Inr2 " + total_inr);
                                   bank_int_normal=parseFloat(total_inr*CreditDays*normalper/36500).toFixed(2);
                                    $('#bank_int_normal').val(bank_int_normal);
               // console.log("Final bank Int Normmal--- " +bank_int_normal);
                }

                //Final In Rs Code Start//
                //#final_in_rs
                var bank_int_panel=$('#bank_int_panel').val();
                var final_in_rs= parseFloat(parseFloat(total_inr)+parseFloat(bank_int_normal)+parseFloat(bank_int_panel)).toFixed(2);
               // console.log("Bank Int Normal" +bank_int_normal);
               // console.log("Final In Rs " +final_in_rs);
                $('#final_in_rs').val(final_in_rs);
                 //Final In Rs Code End//
                //Code By rashid End //
              
                $('#brokerage_amt').val(parseFloat(brokerage_amount).toFixed(2));
                // Total
                exp_html += '<tr class="bg-primary">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                // alert(total_inr3);
                }
                exp_html += '<th>Total</th>';
                exp_html += '<td align="right" id="total_usd">' + parseFloat(total_usd).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="total_usd">' + parseFloat(total_usd2).toFixed(2) + '</td>';
                exp_html += '<td class="Total_Inr1" align="right" id="total_inr">' + parseFloat(total_inr).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td class="Total_Inr2" align="right" id="total_inr">' + parseFloat(total_inr2).toFixed(2) + '</td>';
                exp_html += '</tr>';

                // 3 Inputs For Bank Int
                exp_html += '<tr class="bg-gradient-warning text-center col-12">';
                exp_html += '<td class="col-3" colspan="2"><b>Normal : </b><input type="number" class="normalper" name="normalper" value="'+normalper+'"><b> % p.a.</b></td>';
                exp_html += '<td class="col-3" colspan="2"><b>Penal : </b><input type="number" class="penalper" name="penalper" value="'+penalper+'"><b> % p.a.</b></td>';
                exp_html += '<td class="col-5" colspan="2"><b>Penal applicable after days : </b><input type="number" class="PenalAfterDay" name="PenalAfterDay" value="'+PenalAfterDay+'"></td>';
                if(TESTMODE){
                exp_html += '<td></td>'
                exp_html += '<td></td>'
                exp_html += '<td></td>'
                exp_html += '<td></td>'
                }
                exp_html += '</tr>';
                exp_html += '</tr>';

                // BANK INT
                exp_html += '<tr class="bg-info">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>BANK INT</th>';
                exp_html += '<td align="right" id="bank_int_usd">' + parseFloat(bank_int_usd).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="bank_int_usd2">' + parseFloat(bank_int_usd2).toFixed(2) + '</td>';
                exp_html += '<td align="right" id="bank_int_inr">' + parseFloat(bank_int_inr).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="bank_int_inr2">' + parseFloat(bank_int_inr2).toFixed(2) + '</td>';
                exp_html += '</tr>';

                // FINAL IN RS.
                exp_html += '<tr class="bg-info">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>FINAL IN RS.</th>';
                exp_html += '<td align="right" id="final_in_rs_usd">' + parseFloat(final_in_rs_usd).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="final_in_rs_usd2">' + parseFloat(final_in_rs_usd2).toFixed(2) + '</td>';
                exp_html += '<td align="right" id="final_in_rs_inr">' + parseFloat(final_in_rs_inr).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="final_in_rs_inr2">' + parseFloat(final_in_rs_inr2).toFixed(2) + '</td>';
                exp_html += '</tr>';

                // INSURANCE
                exp_html += '<tr class="bg-info">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>INSURANCE</th>';
                exp_html += '<td align="right" id="insurance_usd">' + parseFloat(insurance_usd).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="insurance_usd2">' + parseFloat(insurance_usd2).toFixed(2) + '</td>';
                exp_html += '<td align="right" id="insurance_inr">' + parseFloat(insurance_inr).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="insurance_inr2">' + parseFloat(insurance_inr2).toFixed(2) + '</td>';
                exp_html += '</tr>';

                // Freight
                exp_html += '<tr class="bg-info">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>Freight</th>';
                exp_html += '<td align="right" id="freight_usd">' + parseFloat(freight_usd).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="freight_usd2">' + parseFloat(freight_usd2).toFixed(2) + '</td>';
                exp_html += '<td align="right" id="freight_inr">' + parseFloat(freight_inr).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="freight_inr2">' + parseFloat(freight_inr2).toFixed(2) + '</td>';
                exp_html += '</tr>';

                // Packing
                exp_html += '<tr class="bg-info">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>Packing ('+packing_cost_type+')</th>';
                exp_html += '<td align="right" id="packing_usd">' + parseFloat(packing_usd).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="packing_usd2">' + parseFloat(packing_usd2).toFixed(2) + '</td>';
                exp_html += '<td align="right" id="packing_inr">' + parseFloat(packing_inr).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="packing_inr2">' + parseFloat(packing_inr2).toFixed(2) + '</td>';
                exp_html += '</tr>';

                // Discount
                exp_html += '<tr class="bg-info">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>Discount</th>';
                exp_html += '<td align="right" id="discount_usd">' + discount_usd + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="discount_usd2">' + discount_usd2 + '</td>';
                exp_html += '<td align="right" id="discount_inr">' + discount_inr + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="discount_inr2">' + discount_inr2 + '</td>';
                exp_html += '</tr>';

                // Without GST Total
                // exp_html += '<tr class="bg-info">';
                // exp_html += '<th></th>';
                // exp_html += '<th></th>';
                // exp_html += '<th></th>';
                // exp_html += '<th style="white-space:nowrap;">Without GST Total</th>';
                // exp_html += '<td align="right" id="total_without_gst_usd_amt">' + parseFloat(total_without_gst_usd_amt)
                //     .toFixed(2) + '</td>';
                // exp_html += '<td align="right" id="total_without_gst_inr_amt">' + parseFloat(total_without_gst_inr_amt)
                //     .toFixed(2) + '</td>';
                // exp_html += '</tr>';

                // GST Total Amount
                exp_html += '<tr class="bg-info">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th style="white-space:nowrap;">GST Total Amount</th>';
                exp_html += '<td align="right" id="total_gst_usd_amt">' + parseFloat(total_gst_usd_amt).toFixed(2) +'</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="total_gst_usd_amt2">' + parseFloat(total_gst_usd_amt2).toFixed(2) +'</td>';
                exp_html += '<td align="right" id="total_gst_inr_amt">' + parseFloat(total_gst_inr_amt).toFixed(2) +'</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="total_gst_inr_amt2">' + parseFloat(total_gst_inr_amt2).toFixed(2) +'</td>';
                exp_html += '</tr>';

                // Final
                exp_html += '<tr class="bg-success">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>Final</th>';
                exp_html += '<td align="right" id="final_usd">' + parseFloat(final_usd).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="final_usd">' + parseFloat(final_usd2).toFixed(2) + '</td>';
                exp_html += '<td align="right" id="final_inr">' + parseFloat(final_inr).toFixed(2) + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="final_inr">' + parseFloat(final_inr2).toFixed(2) + '</td>';
                exp_html += '</tr>';

                // for_1_unit
                exp_html += '<tr class="bg-success">';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                if(TESTMODE){
                exp_html += '<th></th>';
                exp_html += '<th></th>';
                }
                exp_html += '<th>' + for_1_unit + '</th>';
                exp_html += '<td align="right" id="for_1_unit_usd">' + for_1_unit_usd + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="for_1_unit_usd2">' + for_1_unit_usd2 + '</td>';
                exp_html += '<td align="right" id="for_1_unit_inr">' + for_1_unit_inr + '</td>';
                if(TESTMODE)
                exp_html += '<td align="right" id="for_1_unit_inr2">' + for_1_unit_inr2 + '</td>';
                exp_html += '</tr>';
                exp_html += '</table>';
                // code start By rashid For table//
                //console.log(lab_id)
                
              /*lab_html = '';
              lab_html += '<table class="table table-striped">';
              lab_html += '<thead>';
              lab_html += '<tr class="bg-gray">';
              lab_html += '<th scope="col">#</th>';
              lab_html += '<th scope="col">Add. Tests</th>';
              
              lab_html += '<th id="lab_names1" class="lab_names1" scope="col">QSS </th>';

              
			 
              lab_html += '</tr>';
              lab_html += '</thead>';
              lab_html += '<tbody>';
    
    
              lab_html += '<tr>';
              lab_html += '<th scope="row"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id"></th>';
              lab_html += '<td>Oil </td>';
              lab_html += '<td> 0 </td>';
              
              lab_html += '</tr>';
			  
              lab_html += '<tr>';
              lab_html += '<th scope="row"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id"></th>';
              lab_html += '<td>Health (QSS) </td>';
              lab_html += '<td> 0 </td>';
              
              lab_html += '</tr>';
              lab_html += '<tr>';
			  
              lab_html += '<th scope="row"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id"></th>';
              lab_html += '<td>Salmonella </td>';
              lab_html += '<td> 0 </td>';
              
              lab_html += '</tr>';  
			  
              lab_html += '<tr>';
              lab_html += '<th scope="row"><input type="checkbox" style="width: 20px; height:20px;" name="expense_id"></th>';
              lab_html += '<td>E-Coli </td>';
              lab_html += '<td> 0 </td>';
              
              lab_html += '</tr>';  

              lab_html += '<tr class="bg-primary">';
              lab_html += '<th scope="row"></th>';
              lab_html += '<td>Total </td>';
              lab_html += '<td> 0 </td>';
             
              lab_html += '</tr>';  
              
              lab_html += '</tbody>';
              lab_html += '</table>';
             
              $('.lab_div').html(lab_html);
              */
               // Code End By rashid For table//
                $('#top_final_usd1').html(final_usd);
                // old 27-07-2022
                // $('#table_top_final_usd1').html(final_usd);
                $('#table_top_perton_final_usd1').html(final_usd);
                var Quantity_Box=$('#quantity').val();
                if(Quantity_Box=='' || Quantity_Box=='null')
                {
                    $('#table_top_final_usd1_1mt').html(parseFloat(0).toFixed(2));   
                }
                else
                {
                $('#table_top_final_usd1_1mt').html(parseFloat(final_usd / $('#quantity').val()).toFixed(2));
                }
                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd = parseFloat(final_usd) + parseFloat(f4);
                $('#top_final_inr').html(final_inr);
                $('#table_top_final_inr').html(final_inr);

                var final4 = parseFloat(final_inr) + parseFloat(f4);
                $('#top_final_4').html(parseFloat(final4).toFixed(2));
                $('#table_top_final_4').html(parseFloat(final4).toFixed(2));

                var final2 = (parseFloat(final_inr) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd').html(parseFloat(final2).toFixed(2));
                $('#table_new_top_final_usd').html(parseFloat(final2).toFixed(2));

                // 2
                $('#top_final_usd2').html(final_usd2);
                // old 27-07-2022
                // $('#table_top_final_usd2').html(for_1_unit_inr2);
                $('#table_top_perton_final_usd2').html(for_1_unit_inr2);
                $('#table_top_final_usd2_1mt').html((parseFloat(for_1_unit_inr2) / parseFloat(quantity)).toFixed(2));
                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd2 = parseFloat(final_usd2) + parseFloat(f4);
                $('#top_final_inr2').html(final_inr2);
                $('#table_top_final_inr2').html(final_inr2);
                var final4_2 = parseFloat(final_inr2) + parseFloat(f4);
                $('#top_final_4_2').html(parseFloat(final4_2).toFixed(2));
                $('#table_top_final_4_2').html(parseFloat(final4_2).toFixed(2));
                var final2_2 = (parseFloat(final_inr2) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd2').html(parseFloat(final2_2).toFixed(2));
                $('#table_new_top_final_usd2').html(parseFloat(final2_2).toFixed(2));

                // 3
                $('#top_final_usd3').html(final_usd3);
                // old 27-07-2022
                // $('#table_top_final_usd3').html(final_usd3);
                $('#table_top_perton_final_usd3').html(for_1_unit_inr3);
                $('#table_top_final_usd3_1mt').html((parseFloat(for_1_unit_inr3) / parseFloat(quantity)).toFixed(2));

                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd3 = parseFloat(final_usd3) + parseFloat(f4);
                $('#top_final_inr3').html(final_inr3);
                $('#table_top_final_inr3').html(final_inr3);

                var final4_3 = parseFloat(final_inr3) + parseFloat(f4);
                $('#top_final_4_3').html(parseFloat(final4_3).toFixed(2));
                $('#table_top_final_4_3').html(parseFloat(final4_3).toFixed(2));

                var final2_3 = (parseFloat(final_inr3) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd3').html(parseFloat(final2_3).toFixed(2));
                $('#table_new_top_final_usd3').html(parseFloat(final2_3).toFixed(2));

                // 4
                $('#top_final_usd4').html(final_usd4);
                // old 27-07-2022
                // $('#table_top_final_usd4').html(final_usd4);
                $('#table_top_perton_final_usd4').html(for_1_unit_inr4);
                $('#table_top_final_usd4_1mt').html((parseFloat(for_1_unit_inr4) / parseFloat(quantity)).toFixed(2));

                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd4 = parseFloat(final_usd4) + parseFloat(f4);
                $('#top_final_inr4').html(final_inr4);
                $('#table_top_final_inr4').html(final_inr4);

                var final4_4 = parseFloat(final_inr4) + parseFloat(f4);
                $('#top_final_4_4').html(parseFloat(final4_4).toFixed(2));
                $('#table_top_final_4_4').html(parseFloat(final4_4).toFixed(2));

                var final2_4 = (parseFloat(final_inr4) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd4').html(parseFloat(final2_4).toFixed(2));
                $('#table_new_top_final_usd4').html(parseFloat(final2_4).toFixed(2));

                // 5
                $('#top_final_usd5').html(final_usd5);
                // old 27-07-2022
                // $('#table_top_final_usd5').html(final_usd5);
                $('#table_top_perton_final_usd5').html(for_1_unit_inr5);
                $('#table_top_final_usd5_1mt').html((parseFloat(for_1_unit_inr5) / parseFloat(quantity)).toFixed(2));

                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd5 = parseFloat(final_usd5) + parseFloat(f4);
                $('#top_final_inr5').html(final_inr5);
                $('#table_top_final_inr5').html(final_inr5);

                var final4_5 = parseFloat(final_inr5) + parseFloat(f4);
                $('#top_final_4_5').html(parseFloat(final4_5).toFixed(2));
                $('#table_top_final_4_5').html(parseFloat(final4_5).toFixed(2));

                var final2_5 = (parseFloat(final_inr5) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd5').html(parseFloat(final2_5).toFixed(2));
                $('#table_new_top_final_usd5').html(parseFloat(final2_5).toFixed(2));

                // 6
                $('#top_final_usd6').html(final_usd6);
                // old 27-07-2022
                // $('#table_top_final_usd6').html(final_usd6);
                $('#table_top_perton_final_usd6').html(for_1_unit_inr6);
                $('#table_top_final_usd6_1mt').html((parseFloat(for_1_unit_inr6) / parseFloat(quantity)).toFixed(2));

                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd6 = parseFloat(final_usd6) + parseFloat(f4);
                $('#top_final_inr6').html(final_inr6);
                $('#table_top_final_inr6').html(final_inr6);

                var final4_6 = parseFloat(final_inr6) + parseFloat(f4);
                $('#top_final_4_6').html(parseFloat(final4_6).toFixed(2));
                $('#table_top_final_4_6').html(parseFloat(final4_6).toFixed(2));

                var final2_6 = (parseFloat(final_inr6) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd6').html(parseFloat(final2_6).toFixed(2));
                $('#table_new_top_final_usd6').html(parseFloat(final2_6).toFixed(2));

                // 8
                $('#top_final_usd8').html(final_usd8);
                // old 27-07-2022
                // $('#table_top_final_usd8').html(final_usd8);
                $('#table_top_perton_final_usd8').html(for_1_unit_inr8);
                $('#table_top_final_usd8_1mt').html((parseFloat(for_1_unit_inr8) / parseFloat(quantity)).toFixed(2));

                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd8 = parseFloat(final_usd8) + parseFloat(f4);
                $('#top_final_inr8').html(final_inr8);
                $('#table_top_final_inr8').html(final_inr8);

                var final4_8 = parseFloat(final_inr8) + parseFloat(f4);
                $('#top_final_4_8').html(parseFloat(final4_8).toFixed(2));
                $('#table_top_final_4_8').html(parseFloat(final4_8).toFixed(2));

                var final2_8 = (parseFloat(final_inr8) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd8').html(parseFloat(final2_8).toFixed(2));
                $('#table_new_top_final_usd8').html(parseFloat(final2_8).toFixed(2));

                // 10
                $('#top_final_usd10').html(final_usd10);
                // old 27-07-2022
                $('#table_top_perton_final_usd10').html(for_1_unit_inr10);
                $('#table_top_final_usd10_1mt').html((parseFloat(for_1_unit_inr10) / parseFloat(quantity)).toFixed(2));

                var f1 = $('#freight').val();
                if (f1 == '' || f1 == null) {
                    f1 = 0;
                }
                var f4 = parseFloat(f1) * parseFloat(no_of_fcls) / parseFloat(quantity);
                var new_final_usd10 = parseFloat(final_usd10) + parseFloat(f4);
                $('#top_final_inr10').html(final_inr10);
                $('#table_top_final_inr10').html(final_inr10);

                var final4_10 = parseFloat(final_inr10) + parseFloat(f4);
                $('#top_final_4_10').html(parseFloat(final4_10).toFixed(2));
                $('#table_top_final_4_10').html(parseFloat(final4_10).toFixed(2));

                var final2_10 = (parseFloat(final_inr10) + parseFloat(f4)) / parseFloat(ex_rate);
                $('#new_top_final_usd10').html(parseFloat(final2_10).toFixed(2));
                $('#table_new_top_final_usd10').html(parseFloat(final2_10).toFixed(2));

                $('.exp_div').html(exp_html);
            }


        }
        function set_expenses11()
        {
            $(document).ready(function() {
            // Function to calculate and display the sum of checked checkboxes
            function calculateSum() {
                var sum = 0;
                $('input[type="checkbox"]:checked').each(function() {
                    sum += parseFloat($(this).val());
                });
                console.log(sum);
                $('#total_inr').text('Sum: ' + sum.toFixed(2));
            }

            // Initial calculation
            calculateSum();
            
            // Recalculate sum when a checkbox is clicked
            $('input[type="checkbox"]').change(function() {
                alert('check success');
                calculateSum();
            });
        }); 
        }   
        function set_expenses()
        {

           var  TotalExpense =0; 
          
           $('#expense_table tbody input:checked').each(function()
            {
                TotalExpense += parseFloat($(this).closest('tr').find('td.item_rates').text());
            });
            $("#expenses_total").text(TotalExpense);
            
            var lab_expense_total= $("#expenses_total").text();
            lab_expense_total=parseFloat(lab_expense_total).toFixed();
            console.log(lab_expense_total);
            var total_inr = $('#total_inr').text();
           //

           $('input[type="checkbox"]').click(function() {
            alert('checked hua')
                if ($(this).is(':checked')) {
                    console.log('Ha')
                    // Get the parent row of the checkbox
                    var $row = $(this).closest('tr');
                    // Get the text of specific cells by their IDs within the row
                    var currentexpense = $row.find('.item_rates').text();
                    console.log(currentexpense);
                total_inr = parseFloat(parseFloat(total_inr) + parseFloat(currentexpense)).toFixed(2);
                total_inr= $('#total_inr').text(total_inr).toFixed(2);
               
                }
            });
           
        }
        function set_expenses1()
        {
            //
            console.log(2);
            //    
           var  TotalExpense =0; 
           $('#expense_table tbody input:checked').each(function()
            {
                TotalExpense += parseFloat($(this).closest('tr').find('td.item_rates').text());
            });
            $("#expenses_total").text(TotalExpense);
            //
             
            var lab_expense_total= $("#expenses_total").text();
             console.log(lab_expense_total);
           var total_inr = $('#total_inr').text();
           $('input[type="checkbox"]').click(function() {
              
                    // Get the parent row of the checkbox
                    var $row = $(this).closest('tr');
                    // Get the text of specific cells by their IDs within the row
                    var currentexpense = $row.find('.item_rates').text();
                   // console.log(currentexpense);
                total_inr = parseFloat(parseFloat(parseFloat(total_inr) - parseFloat(currentexpense)));
                total_inr= $('#total_inr').text(total_inr).toFixed(2);
               
                
            });
            //
            
        }
        function xxxset_amount_oldxxx() {
            ex_rate = $('#ex_rate').val();
            discount_per = $('#discount_per').val();
            total_usd = 0;
            total_inr = 0;
            total_gst_usd_amt = 0;
            total_gst_inr_amt = 0;
            total_without_gst_usd_amt = 0;
            total_without_gst_inr_amt = 0;
            quantity = $('#quantity').val() || 1;
            brokerage_per = $('#brokerage_per').val() || 0;
            if (ex_rate == '' || ex_rate == null) {
                ex_rate = '1';
            }
            if (discount_per == '' || discount_per == null) {
                discount_per = '0';
            }
            if (exp_objectdata != '') {
                total_usd = 0;
                total_inr = 0;
                $.each(exp_objectdata, function(index, value) {
                    if ($("[name='expense_id[" + value.id + "]']").prop('checked') == true) {
                        no_of_fcls = $('#no_of_fcls').val();
                        if (no_of_fcls == '' || no_of_fcls == null) {
                            no_of_fcls = '1';
                        }
                        if (value.expense_type_id != expense_type_id_per_container) {
                            no_of_fcls = '1';
                        }
                        var rate = parseFloat(value.rate) * parseFloat(no_of_fcls);
                        rate = parseFloat(rate).toFixed(2);
                        if (value.currency_id == currency_id_inr) {
                            var usd_rate = parseFloat(rate) / parseFloat(ex_rate);
                            var usd_rate = parseFloat(usd_rate).toFixed(2);
                            var inr_rate = rate;
                        } else if (value.currency_id == currency_id_usd) {
                            var usd_rate = rate;
                            var inr_rate = parseFloat(rate) * parseFloat(ex_rate);
                            var inr_rate = parseFloat(inr_rate).toFixed(2);
                        } else {
                            var usd_rate = rate;
                            var inr_rate = rate;
                        }
                        total_usd = parseFloat(total_usd) + parseFloat(usd_rate);
                        total_inr = parseFloat(total_inr) + parseFloat(inr_rate);
                        total_gst_usd_amt = total_gst_usd_amt + value.gst_usd_amt;
                        total_gst_inr_amt = total_gst_inr_amt + value.gst_inr_amt;
                    } else {

                    }
                });
                total_usd = parseFloat(total_usd).toFixed(2);
                total_inr = parseFloat(total_inr).toFixed(2);
               
                var discount_usd = (parseFloat(total_usd) + parseFloat(total_gst_usd_amt)) * parseFloat(discount_per) / 100;
                var discount_inr = (parseFloat(total_inr) + parseFloat(total_gst_inr_amt)) * parseFloat(discount_per) / 100;
                //            var discount_usd = parseFloat(discount_per) * parseFloat(total_usd) / 100;
                //            var discount_inr = parseFloat(discount_per) * parseFloat(total_inr) / 100;
                discount_usd = parseFloat(discount_usd).toFixed(2);
                discount_inr = parseFloat(discount_inr).toFixed(2);
                var final_usd = parseFloat(total_usd) + total_gst_usd_amt - discount_usd;
                var final_inr = parseFloat(total_inr) + total_gst_inr_amt - discount_inr;
                total_without_gst_usd_amt = total_usd - discount_usd;
                total_without_gst_inr_amt = total_inr - discount_inr;
                total_without_gst_usd_amt = parseFloat(total_without_gst_usd_amt).toFixed(2);
                total_without_gst_inr_amt = parseFloat(total_without_gst_inr_amt).toFixed(2);
                var final_usd = parseFloat(total_usd) - parseFloat(discount_usd);
                var final_inr = parseFloat(total_inr) - parseFloat(discount_inr);
                final_usd = parseFloat(final_usd).toFixed(2);
                final_inr = parseFloat(final_inr).toFixed(2);
                var for_1_unit_usd = parseFloat(final_usd) / parseFloat(quantity);
                var for_1_unit_inr = parseFloat(final_inr) / parseFloat(quantity);
                var brokerage_amount = total_without_gst_inr_amt * brokerage_per / 100;
                $('#brokerage_amt').val(parseFloat(brokerage_amount).toFixed(2));
            }
            $('#total_usd').html('');
            $('#total_usd').html(total_usd);
            $('#total_inr').html('');
            $('#total_inr').html(total_inr);
            $('#discount_usd').html('');
            $('#discount_usd').html(discount_usd);
            $('#discount_inr').html('');
            $('#discount_inr').html(discount_inr);
            $('#total_without_gst_usd_amt').html('');
            $('#total_without_gst_usd_amt').html(parseFloat(total_without_gst_usd_amt).toFixed(2));
            $('#total_without_gst_inr_amt').html('');
            $('#total_without_gst_inr_amt').html(parseFloat(total_without_gst_inr_amt).toFixed(2));
            $('#total_gst_usd_amt').html('');
            $('#total_gst_usd_amt').html(parseFloat(total_gst_usd_amt).toFixed(2));
            $('#total_gst_inr_amt').html('');
            $('#total_gst_inr_amt').html(parseFloat(total_gst_inr_amt).toFixed(2));
            $('#final_usd').html('');
            $('#final_usd').html(final_usd);
            $('#final_inr').html('');
            $('#final_inr').html(final_inr);
            $('#for_1_unit_usd').html('');
            $('#for_1_unit_usd').html(parseFloat(for_1_unit_usd).toFixed(2));
            $('#for_1_unit_inr').html('');
            $('#for_1_unit_inr').html(parseFloat(for_1_unit_inr).toFixed(2));
        }
        //31.1.2023
        function set_dropdown(event) {
            var container_type = $(event).find(':selected').val();
            var commodity_id = $('#commodity_id').find(':selected').val();
            $.ajax({
                url: '{{ URL("admin/get_loadability") }}/'+ container_type+'?commodity_id='+commodity_id,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    //console.log(result, 'data');
                    if(result.data)
                        $('#quantity').val(result.data.loadbility);
                    else
                      //  $('#quantity').val('');   
                        
                        set_amount();
                }
            });
            
        }
    </script>

<script>
    $(document).ready(function(){
        $('#buyer_id').change(function(){
       
            var buyer_id = $(this).val();

            $.ajax({
                url: "{{ route('GetQuality') }}",
                method: 'GET',
                data: {selectedValue: buyer_id},
                success: function(response){
                    // Handle the response, update the view with the fetched data
                   
                   // console.log(response);
                   // $("#quality_box").val(response);
                    $('#quality_box').empty();
                    $.each(response, function(key, value){
                        $('#quality_box').append('<option value="' + value.id + '">' + value.quality + '</option>');
                    });


                },
                error: function(xhr, status, error){
                    // Handle errors
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>
@stop
