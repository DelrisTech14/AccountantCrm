{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Item List')

@section('content_header')
<h1>Item List</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop


@section('content')
<div class="card">
    <div class="card-body">
        @include ('error')

        <div class="table-responsive">
            <table id="dataTable-item" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="100px">Action</th>
                        <th>Item Name</th>
                        <th>Brand</th>
                        <th>Category</th>
                        <th>Sub Category </th>
                        <th>Product Code</th>
                        <th>GST %</th>
                        <th>MRP</th>
                        <th>Sales Rate</th>
                        <th>Location1</th>
                        <th>Location2</th>
                        <th>Opening Stock</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>

        <div class="modal fade" id="deleteitemModel" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Confirmation</h4>
                    </div>
                    <form action="{{url('/admin/itemDelete')}}" method="post" id="dform">
                        <div class="modal-body">
                            <p>Are you sure you want remove this Item ?</p>
                            @csrf
                            <input type="hidden" name="delete_item_id" id="delete_item_id">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Yes</button>
                            <button type="button" class="btn btn-default btn-outline" data-dismiss="modal">No</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@stop

@section('js')
    <script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
        var itemTable;
        $(document).ready( function(){


            $(document).on('click', '.delete_item', function(){
                var delete_item_id = $(this).attr('data-item_id');
                $('#delete_item_id').val(delete_item_id);
                $('#deleteitemModel').modal('show');
                return false;
            });

            unitTable = $('#dataTable-item').DataTable({
                "bServerSide": true,
                "processing": true,
                "bRetrieve": true,
                "pageLength": 10,
                "ajax": {
                    "url": "{{ URL::to('/admin/getItemDatatable/') }}",
                    "type": "GET",
                    "data": function (d) {
//                        d.unit_id = $('#unit_id').val();
                    },
                },
                "columns": [{
                    "data": 'id',
                    "sClass": 'text-nowrap',
                    "render": function( data, type, full, meta ) {
//                        var edit_button = '<a href="/admin/item_details/'+ data +'"><button class="btn btn-sm btn-info edit_item" ><i class="fa far fa-edit"></i></button></a>';
                        var delete_button = '<button class="btn btn-sm btn-danger delete_item" data-item_id="'+ data +'" title="Delete"><span class="fa fa-times-circle"></span></button>';
//                        return edit_button + ' ' + delete_button;
                        return delete_button;
                    }
                }, 
                {
                    "data": "item_name",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "brand_name",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "category_name",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "sub_category_name",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "item_code",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "gst_per",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "mrp",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "sales_rate",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "location_1",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "location_2",
                    "defaultContent": '-',
                    "searchable": false,
                },
                {
                    "data": "opening_qty",
                    "defaultContent": '-',
                    "searchable": false,
                },
                ],
                "ordering": false,
                "searching": false,
            });
        });
    </script>
@stop
