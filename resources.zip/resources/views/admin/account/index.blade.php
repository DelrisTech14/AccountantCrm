{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dhaval Agri | Accounts')

@section('content_header')
<h1>Accounts</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        @include ('error')
        <p class="float-right">
            <a class="btn btn-primary" href="{!!route('accounts.create')!!}"><i class="fa fa-plus"></i> Create Account</a>
        </p>
        <div class="row">


        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
      

        <div class="table-responsive">
            <table id="dataTable-city" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="20%">Action</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Phone</th>
                        <th>Whatsapp</th>
                        <th>Shipping marks</th>
                        <th>Email</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($accounts as $rows)
                   
                    <tr>
                    <td>
                    <button class="btn btn-sm btn-info edit_city" data-city_id="'+ data +'"><i class="fa far fa-edit"></i></button>
                    <a href="" target="_blank" class="btn btn-sm btn-warning print_contract" title="Print"><span class="fa fa-print"></span></a>   
                    <a href="{{ route('delete', $rows->id) }}" onclick="return confirm('Are you sure you want to delete this record?')" class="btn btn-sm btn-danger delete_contract" title="Delete"><span class="fa fa-times-circle"></span></a>
                </td>

                     <td>{{ $rows->name }}</td>
                     <td>{{ $rows->mobile }}</td>
                     <td>{{ $rows->phone }}</td>
                     <td>{{ $rows->whatsapp }}</td>
                     <td>{{ $rows->shipping_marks }}</td>
                     <td>{{ $rows->email }}</td>
                     <td>{{   $rows->created_at }}</td>
                     
                     
                     

                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
    </script>
@stop