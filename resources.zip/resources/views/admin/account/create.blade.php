@extends('adminlte::page')

@section('title', 'Dhaval Agri | Create Account')

@section('content_header')
<h1>Create Account</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        @include ('error')
        {{ Form::open( ['name'=>'save_account', 'id' => 'save_account', 'method' => 'post', 'enctype' => 'multipart/form-data', 'data-parsley-validate' => '']) }}
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('account_name', 'Account Name', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                        {{ Form::text('account_name','', ['id' => 'account_name', 'required' => 'required', 'class' => 'form-control', 'placeholder' => 'Account Name']) }}
                        <p class="text-danger">@error('account_name'){{$message}}@enderror</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('group_id', 'Account Groups', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                        <select class="form-control select2" required='required' id="group_id" name="group_id">
                            <option value="">Select</option>
                            @foreach($accountgroups as $accountgroup)
                                <option value="{{$accountgroup->id}}">{{$accountgroup->name}}</option>
                            @endforeach
                        </select>
                        <p class="text-danger">@error('group_id'){{$message}}@enderror</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('phone', 'Phone', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('phone', '', ['id' => 'phone', 'class' => 'form-control num_only', 'placeholder' => 'Phone']) }}
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('mobile', 'Mobile', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                {{ Form::text('mobile', '', ['id' => 'mobile', 'class' => 'form-control num_only', 'placeholder' => 'Mobile']) }}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('whatsapp', 'WhatsApp', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                {{ Form::text('whatsapp', '', ['id' => 'whatsapp', 'class' => 'form-control num_only', 'placeholder' => 'WhatsApp']) }}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        {{ Form::label('country_id', 'Country', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                        <select class="form-control select2" id="country_id" name="country_id">
                                            <option value="">Select Country</option>
                                            @foreach($countries as $country)
                                                <option value="{{$country->id}}">{{$country->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        {{ Form::label('state_id', 'State', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                        <select class="form-control select2" id="state_id" name="state_id">
                                            <option value="">Select State</option>
                                            @foreach($states as $state)
                                                <option value="{{$state->id}}">{{$state->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        {{ Form::label('city_id', 'City', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                        <select class="form-control select2"  id="city_id" name="city_id">
                                        <option value="">Select City</option>
                                        @foreach($cities as $city)
                                            <option value="{{$city->city_name}}">{{$city->city_name}}</option>
                                        @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        {{ Form::label('pincode', 'Pincode', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                        {{ Form::text('pincode', '', ['id' => 'pincode', 'class' => 'form-control', 'placeholder' => 'Pincode']) }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('address', 'Address', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::textarea('address','', ['id' => 'address', 'class' => 'form-control', 'rows' => 4, 'cols' => 40, 'placeholder' => 'Address']) }}
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12"><hr /><h5>Default</h5></div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('shipping_marks', 'Shipping Marks', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('shipping_marks', '', ['id' => 'shipping_marks',  'class' => 'form-control', 'placeholder' => 'Shipping Marks']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('default_bank', 'Bank Details', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="default_bank" name="default_bank">
                            <option value="">Select Bank</option>
                            @foreach($banks as $bank)
                                <option value="{{$bank->id}}">{{$bank->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('payment_terms', 'Payment Terms', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('payment_terms', '', ['id' => 'payment_terms', 'class' => 'form-control', 'placeholder' => 'Payment Terms']) }}
                    </div>
                </div>
                <div class="col-md-3" id="surveyor_select" >
                    <div class="form-group">
                        {{ Form::label('surveyor_id', 'Surveyor', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="surveyor_id" name="surveyor_id">
                            <option value="">Select Surveyor</option>
                            @foreach($surveyors as $surveyor)
                                <option value="{{$surveyor->id}}">{{$surveyor->name}}</option>
                            @endforeach
                        </select>
                        {{ Form::hidden('surveyor_name', '', ['id' => 'surveyor_name']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('currency_id', 'Currency', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select name="currency_id" class="form-control select2"   id="currency_id">
                            <option value="">Select Currency</option>
                            @foreach($currencies as $currency)
                                <option value="{{$currency->id}}">{{$currency->currency}}</option>
                            @endforeach
                        </select>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('default_port', 'Port of Destination', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select name="default_port" class="form-control select2" id="default_port" >
                            <option value="">Port of Destination</option>
                            @foreach($ports as $port)
                            @if ($port->is_destination == 1)
                                <option value="{{$port->id}}">{{$port->name}}</option>
                            @endif
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('credit_days', 'Credit Days', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('credit_days', '', ['id' => 'credit_days',  'class' => 'form-control num_only', 'placeholder' => 'Credit Days']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('discount_per', 'Discount(%)', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('discount_per', '', ['id' => 'discount_per','class' => 'form-control num_only', 'placeholder' => 'Discount(%)']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('broker_id', 'Broker', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="broker_id" name="broker_id">
                            <option value="">Select Broker</option>
                            @foreach($brokers as $broker)
                                <option value="{{$broker->id}}">{{$broker->name}}</option>
                            @endforeach
                        </select>
                        {{ Form::hidden('broker_name', '', ['id' => 'broker_name']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('brokerage_per', 'Brokerage(%)', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('brokerage_per', '', ['id' => 'brokerage_per','class' => 'form-control num_only', 'placeholder' => 'Brokerage(%)']) }}
                    </div>
                </div>
            </div><hr />
            <h4>Account + Commodity wise different</h4>
            <div class="row">
                <div class="col-md-12">
                    <hr />
                    <h5 class="line_item_form">Account wise Quality of Commodity</h5>
                    <input type="hidden" name="line_items_data[line_items_index]" id="line_items_index" />
                    <input type="hidden" name="line_items_data[lineitem_id]" id="lineitem_id" value="" autofocus=""/>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('commodity_id', 'Commodity', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                                <select name="line_items_data[commodity_id]" id="commodity_id" class="form-control select2" ></select>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('quality_id', 'Quality', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                                <select name="line_items_data[quality_id]" id="quality_id" class="form-control select2" ></select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label></label><br>
                                <div class="checkbox icheck-success">
                                    <input type="checkbox" name="line_items_data[is_default]" id="is_default" />
                                    <label for="is_default">Is Default?</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group" style="margin-top:18px;">
                                {{ Form::button('<i class="fa fa-plus" ></i> Add', ['id' => 'add_lineitem', 'class' => 'btn btn-primary btn-sm']) }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-bordered" id="" style="width:100%">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Commodity</th>
                                <th>Quality</th>
                                <th>Default</th>
                            </tr>
                        </thead>
                        <tbody id="lineitem_list"></tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <hr />
                    <h5 class="line_item_1_form">Account and Commodity wise Default</h5>
                    <input type="hidden" name="line_items_1_data[line_items_1_index]" id="line_items_1_index" />
                    <input type="hidden" name="line_items_1_data[lineitem_1_id]" id="lineitem_1_id" value="" autofocus=""/>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('commodity_d_id', 'Commodity', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                                <select name="line_items_1_data[commodity_id]" id="commodity_d_id" class="form-control select2" ></select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('packing_id', 'Packing', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                                <select name="line_items_1_data[packing_id]" id="packing_id" class="form-control select2" ></select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('cost_for', 'Cost For', ['class' => 'control-label']) }}
                                <select name="line_items_1_data[cost_for]" id="cost_for" class="form-control select2" >
                                        <option value="0">-- Select Cost For --</option>
                                        <option value="1">Cost For Gross</option>
                                        <option value="2">Cost For Net</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('fumigation_dosage_id', 'Fumigation Dosage', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select name="line_items_1_data[fumigation_dosage_id]" id="fumigation_dosage_id" class="form-control select2" ></select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('container_type_id', 'Container Type', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select name="line_items_1_data[container_type_id]" id="container_type_id" class="form-control select2" ></select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                {{ Form::label('lab_id', 'Lab', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select name="line_items_1_data[lab_id]" id="lab_id" class="form-control select2" ></select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group" style="margin-top:18px;">
                                {{ Form::button('<i class="fa fa-plus" ></i> Add', ['id' => 'add_1_lineitem', 'class' => 'btn btn-primary btn-sm']) }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-bordered" id="" style="width:100%">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Commodity</th>
                                <th>Packing</th>
                                <th>Cost For</th>
                                <th>Fumigation Dosage</th>
                                <th>Container Type</th>
                                <th>Lab</th>
                            </tr>
                        </thead>
                        <tbody id="lineitem_1_list"></tbody>
                    </table>
                </div>
            </div>
            {{ Form::submit('Save', ['class' => 'btn btn-primary module_save_btn']) }}
        {{ Form::close() }}
    </div>
</div>

@stop

@section('js')
<script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
<script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
<script type="text/javascript">
    $('#surveyor_select').hide();
    var lineitem_objectdata = [];
    <?php if (isset($account_data->account_quality_of_commodity)) { ?>
        var lineitem_objectdata = <?php echo $account_data->account_quality_of_commodity; ?>;
        console.log(lineitem_objectdata);
    <?php } ?>
    display_lineitem_html(lineitem_objectdata);
    var lineitem_1_objectdata = [];
    <?php if (isset($account_data->account_commodity_wise_default)) { ?>
        var lineitem_1_objectdata = <?php echo $account_data->account_commodity_wise_default; ?>;
        console.log(lineitem_1_objectdata);
    <?php } ?>
    display_lineitem_1_html(lineitem_1_objectdata);
    $(document).ready( function(){
        $('#group_id, #country_id, #state_id, #city_id, #default_bank, #surveyor_id, #currency_id, #default_port, #broker_id').select2();
        initAjaxSelect2($("#commodity_id"), "{{ URL::to('/commodity_select2_source') }}");
        initAjaxSelect2($("#quality_id"), "{{ URL::to('/quality_select2_source') }}");
        initAjaxSelect2($("#commodity_d_id"), "{{ URL::to('/commodity_select2_source') }}");
        initAjaxSelect2($("#packing_id"), "{{ URL::to('/packing_select2_source') }}");
        initAjaxSelect2($("#fumigation_dosage_id"), "{{ URL::to('/fumigation_dosage_select2_source') }}");
        initAjaxSelect2($("#container_type_id"), "{{ URL::to('/container_type_select2_source') }}");
        initAjaxSelect2($("#lab_id"), "{{ URL::to('/lab_select2_source') }}");

        $(document).on('click', '#add_lineitem', function () {
            var commodity_id = $("#commodity_id").val();
            var quality_id = $("#quality_id").val();
            if (commodity_id == '' || commodity_id == null) {
                bootbox.alert('<span class="text-error">Commodity is required !</span>');
                return false;
            }
            if (quality_id == '' || quality_id == null) {
                bootbox.alert('<span class="text-error">Quality is required !</span>');
                return false;
            }
            var line_items_index = $("#line_items_index").val();
            $("#add_lineitem").attr('disabled', 'disabled');
            var key = '';
            var value = '';
            var lineitem = {};
            $('select[name^="line_items_data"]').each(function (e) {
                key = $(this).attr('name');
                key = key.replace("line_items_data[", "");
                key = key.replace("]", "");
                value = $(this).val();
                lineitem[key] = value;
            });
            $('input[name^="line_items_data"]').each(function () {
                key = $(this).attr('name');
                key = key.replace("line_items_data[", "");
                key = key.replace("]", "");
                value = $(this).val();
                lineitem[key] = value;
            });
            $('textarea[name^="line_items_data"]').each(function () {
                key = $(this).attr('name');
                key = key.replace("line_items_data[", "");
                key = key.replace("]", "");
                value = $(this).val();
                lineitem[key] = value;
            });

            var commodity_id_data = $('#commodity_id option:selected').html();
            if(commodity_id == null || commodity_id == ''){
                lineitem['commodity_name'] = '';
            } else {
                lineitem['commodity_name'] = commodity_id_data;
            }
            var quality_id_data = $('#quality_id option:selected').html();
            if(quality_id == null || quality_id == ''){
                lineitem['quality_name'] = '';
            } else {
                lineitem['quality_name'] = quality_id_data;
            }
            lineitem['is_default'] = '';
            if($("#is_default").is(':checked')){  // checked
                lineitem['is_default'] = '1';
            }
            var new_lineitem = JSON.parse(JSON.stringify(lineitem));
            var line_items_index = $("#line_items_index").val();
            if (line_items_index != '') {
                lineitem_objectdata.splice(line_items_index, 1, new_lineitem);
            } else {
                lineitem_objectdata.push(new_lineitem);
            }
            display_lineitem_html(lineitem_objectdata);
            $("#commodity_id").val('').trigger("change");
            $("#quality_id").val('').trigger("change");
            $("#is_default").prop('checked', false);
            $("#line_items_index").val('');
            $("#add_lineitem").removeAttr('disabled', 'disabled');
            $(".remove_lineitem").show();
            $('html, body').animate({
                scrollTop: $(".line_item_form").offset().top
            }, 1000);
        });

        $(document).on('click', '#add_1_lineitem', function () {
            var commodity_d_id = $("#commodity_d_id").val();
            if (commodity_d_id == '' || commodity_d_id == null) {
                bootbox.alert('<span class="text-error">Commodity is required !</span>');
                return false;
            }
            var packing_id = $("#packing_id").val();
            if (packing_id == '' || packing_id == null) {
                bootbox.alert('<span class="text-error">Packing is required !</span>');
                return false;
            }
            var fumigation_dosage_id = $("#fumigation_dosage_id").val();
            var container_type_id = $("#container_type_id").val();
            var lab_id = $("#lab_id").val();
            var line_items_1_index = $("#line_items_1_index").val();
            $("#add_1_lineitem").attr('disabled', 'disabled');
            var key = '';
            var value = '';
            var lineitem = {};
            $('select[name^="line_items_1_data"]').each(function (e) {
                key = $(this).attr('name');
                key = key.replace("line_items_1_data[", "");
                key = key.replace("]", "");
                value = $(this).val();
                lineitem[key] = value;
            });
            $('input[name^="line_items_1_data"]').each(function () {
                key = $(this).attr('name');
                key = key.replace("line_items_1_data[", "");
                key = key.replace("]", "");
                value = $(this).val();
                lineitem[key] = value;
            });
            $('textarea[name^="line_items_1_data"]').each(function () {
                key = $(this).attr('name');
                key = key.replace("line_items_1_data[", "");
                key = key.replace("]", "");
                value = $(this).val();
                lineitem[key] = value;
            });

            var commodity_d_id_data = $('#commodity_d_id option:selected').html();
            if(commodity_d_id == null || commodity_d_id == ''){
                lineitem['commodity_name'] = '';
            } else {
                lineitem['commodity_name'] = commodity_d_id_data;
            }
            var packing_id_data = $('#packing_id option:selected').html();
            if(packing_id == null || packing_id == ''){
                lineitem['packing_name'] = '';
            } else {
                lineitem['packing_name'] = packing_id_data;
            }
            var cost_for_data = $('#cost_for option:selected').html();
            if(cost_for == null || cost_for == ''){
                lineitem['cost_for_name'] = '';
            } else {
                lineitem['cost_for_name'] = cost_for_data;
            }
            var fumigation_dosage_id_data = $('#fumigation_dosage_id option:selected').html();
            if(fumigation_dosage_id == null || fumigation_dosage_id == ''){
                lineitem['fumigation_dosage_name'] = '';
            } else {
                lineitem['fumigation_dosage_name'] = fumigation_dosage_id_data;
            }
            var container_type_id_data = $('#container_type_id option:selected').html();
            if(container_type_id == null || container_type_id == ''){
                lineitem['container_type_name'] = '';
            } else {
                lineitem['container_type_name'] = container_type_id_data;
            }
            var lab_id_data = $('#lab_id option:selected').html();
            if(lab_id == null || lab_id == ''){
                lineitem['lab_name'] = '';
            } else {
                lineitem['lab_name'] = lab_id_data;
            }
            var new_1_lineitem = JSON.parse(JSON.stringify(lineitem));
            var line_items_1_index = $("#line_items_1_index").val();
            if (line_items_1_index != '') {
                lineitem_1_objectdata.splice(line_items_1_index, 1, new_1_lineitem);
            } else {
                lineitem_1_objectdata.push(new_1_lineitem);
            }
            display_lineitem_1_html(lineitem_1_objectdata);
            $("#commodity_d_id").val('').trigger("change");
            $("#packing_id").val('').trigger("change");
            $("#cost_for").val('').trigger("change");
            $("#fumigation_dosage_id").val('').trigger("change");
            $("#container_type_id").val('').trigger("change");
            $("#lab_id").val('').trigger("change");
            $("#line_items_1_index").val('');
            $("#add_1_lineitem").removeAttr('disabled', 'disabled');
            $(".remove_1_lineitem").show();
            $('html, body').animate({
                scrollTop: $(".line_item_1_form").offset().top
            }, 1000);
        });

        $(document).on('submit', '#save_account', function (e) {
            e.preventDefault();
            $('.module_save_btn').attr('disabled', 'disabled');
            var postData = new FormData(this);
            var lineitem_objectdata_stringify = JSON.stringify(lineitem_objectdata);
            postData.append('account_quality_of_commodity', lineitem_objectdata_stringify);
            var lineitem_1_objectdata_stringify = JSON.stringify(lineitem_1_objectdata);
            postData.append('account_commodity_wise_default', lineitem_1_objectdata_stringify);

            $.ajax({
                url: "{{ URL::to('/admin/save_account') }}",
                type: "POST",
                processData: false,
                contentType: false,
                cache: false,
                data: postData,
                datatype: 'json',
                async: false,
                success: function (response) {
                    $('.module_save_btn').removeAttr('disabled', 'disabled');
                    var json = $.parseJSON(response);
//                    console.log(json); return false;
                    if (json['success'] == 'Added') {
                        redirectWithFlashMessage("{{ URL::to('/admin/accounts/') }}/", 'success', 'Successfully Added.');
                    } else if (json['success'] == 'Updated') {
                        redirectWithFlashMessage("{{ URL::to('/admin/accounts/') }}/", 'success', 'Successfully Updated.');
                    } else {
                        bootbox.alert('<span class="text-danger">Something error occurred</span>');
                        return false;
                    }
                    return false;
                },
            });
            return false;
        });

    });

    function display_lineitem_html(lineitem_objectdata) {
        var new_lineitem_html = '';
        $.each(lineitem_objectdata, function (index, value) {
            var value_commodity_name = '';
            if(value.commodity_name != '' && value.commodity_name != null){ value_commodity_name = value.commodity_name; }
            var value_quality_name = '';
            if(value.quality_name != '' && value.quality_name != null){ value_quality_name = value.quality_name; }
            var value_is_default = '';
            if(value.is_default == '1'){ value_is_default = 'default'; }
            var lineitem_edit_btn = '<a class="btn btn-xs btn-primary btn-edit-item edit_lineitem_' + index + '" href="javascript:void(0);" onclick="edit_lineitem(' + index + ')"><i class="fa fa-edit"></i></a> ';
            var lineitem_delete_btn = '<a class="btn btn-xs btn-danger btn-delete-item remove_lineitem" data-id="'+ index +'" href="javascript:void(0);" onclick="remove_lineitem(' + index + ')"><span class="fa fa-times-circle"></span></a>';
            var row_html = '<tr class="lineitem_index_' + index + '"><td class="">'  +
                    lineitem_edit_btn +
                    lineitem_delete_btn +
                    '</td>' +
                    '<td>' + value_commodity_name + '</td>' +
                    '<td>' + value_quality_name + '</td>' +
                    '<td>' + value_is_default + '</td>';
            new_lineitem_html += row_html;
        });
        $('tbody#lineitem_list').html(new_lineitem_html);
    }

    function edit_lineitem(index) {
        $('html, body').animate({
            scrollTop: $(".line_item_form").offset().top
        }, 1000);
        $(".remove_lineitem").hide();
        var value = lineitem_objectdata[index];
        if(typeof(value.lineitem_id) != "undefined" && value.lineitem_id !== null) {
            $("#lineitem_id").val(value.lineitem_id);
        }
        $("#line_items_index").val(index);
        if((value.commodity_id != '0') && (value.commodity_id != null) && (value.commodity_id != '')){
            setSelect2Value($("#commodity_id"), "{{ URL::to('/set_commodity_select2_val_by_id/') }}/" + value.commodity_id);
        }
        if((value.quality_id != '0') && (value.quality_id != null) && (value.quality_id != '')){
            setSelect2Value($("#quality_id"), "{{ URL::to('/set_quality_select2_val_by_id/') }}/" + value.quality_id);
        }
        if(typeof(value.lineitem_id) != "undefined" && value.lineitem_id !== null) {
            $("#lineitem_id").val(value.lineitem_id);
        }
        if(typeof(value.is_default) != "undefined" && value.is_default == '1') {
            $("#is_default").prop('checked', true);
        }
    }

    function remove_lineitem(index) {
        if (confirm('Are you sure ?')) {
            value = lineitem_objectdata[index];
            lineitem_objectdata.splice(index, 1);
            display_lineitem_html(lineitem_objectdata);
        }
    }

    function display_lineitem_1_html(lineitem_1_objectdata) {
        var new_lineitem_1_html = '';
        $.each(lineitem_1_objectdata, function (index, value) {
            var value_commodity_name = '';
            if(value.commodity_name != '' && value.commodity_name != null){ value_commodity_name = value.commodity_name; }
            var value_packing_name = '';
            if(value.packing_name != '' && value.packing_name != null){ value_packing_name = value.packing_name; }
            var value_cost_for_name = '';
            if(value.cost_for_name != '' && value.cost_for_name != null){ value_cost_for_name = value.cost_for_name; }
            var value_fumigation_dosage_name = '';
            if(value.fumigation_dosage_name != '' && value.fumigation_dosage_name != null){ value_fumigation_dosage_name = value.fumigation_dosage_name; }
            var value_container_type_name = '';
            if(value.container_type_name != '' && value.container_type_name != null){ value_container_type_name = value.container_type_name; }
            var value_lab_name = '';
            if(value.lab_name != '' && value.lab_name != null){ value_lab_name = value.lab_name; }
            var lineitem_1_edit_btn = '<a class="btn btn-xs btn-primary btn-edit-item edit_1_lineitem_' + index + '" href="javascript:void(0);" onclick="edit_1_lineitem(' + index + ')"><i class="fa fa-edit"></i></a> ';
            var lineitem_1_delete_btn = '<a class="btn btn-xs btn-danger btn-delete-item remove_1_lineitem" data-id="'+ index +'" href="javascript:void(0);" onclick="remove_1_lineitem(' + index + ')"><span class="fa fa-times-circle"></span></a>';
            var row_html = '<tr class="lineitem_1_index_' + index + '"><td class="">'  +
                    lineitem_1_edit_btn +
                    lineitem_1_delete_btn +
                    '</td>' +
                    '<td>' + value_commodity_name + '</td>' +
                    '<td>' + value_packing_name + '</td>' +
                    '<td>' + value_cost_for_name + '</td>' +
                    '<td>' + value_fumigation_dosage_name + '</td>' +
                    '<td>' + value_container_type_name + '</td>' +
                    '<td>' + value_lab_name + '</td>';
            new_lineitem_1_html += row_html;
        });
        $('tbody#lineitem_1_list').html(new_lineitem_1_html);
    }

    function edit_1_lineitem(index) {
        $('html, body').animate({
            scrollTop: $(".line_item_1_form").offset().top
        }, 1000);
        $(".remove_1_lineitem").hide();
        var value = lineitem_1_objectdata[index];
        if(typeof(value.lineitem_1_id) != "undefined" && value.lineitem_1_id !== null) {
            $("#lineitem_1_id").val(value.lineitem_1_id);
        }
        $("#line_items_1_index").val(index);
        if((value.commodity_id != '0') && (value.commodity_id != null) && (value.commodity_id != '')){
            setSelect2Value($("#commodity_d_id"), "{{ URL::to('/set_commodity_select2_val_by_id/') }}/" + value.commodity_id);
        }
        if((value.packing_id != '0') && (value.packing_id != null) && (value.packing_id != '')){
            setSelect2Value($("#packing_id"), "{{ URL::to('/set_packing_select2_val_by_id/') }}/" + value.packing_id);
        }
        if((value.cost_for != '0') && (value.cost_for != null) && (value.cost_for != '')){
            $("#cost_for").val(value.cost_for);
        }
        if((value.fumigation_dosage_id != '0') && (value.fumigation_dosage_id != null) && (value.fumigation_dosage_id != '')){
            setSelect2Value($("#fumigation_dosage_id"), "{{ URL::to('/set_fumigation_dosage_select2_val_by_id/') }}/" + value.fumigation_dosage_id);
        }
        if((value.container_type_id != '0') && (value.container_type_id != null) && (value.container_type_id != '')){
            setSelect2Value($("#container_type_id"), "{{ URL::to('/set_container_type_select2_val_by_id/') }}/" + value.container_type_id);
        }
        if((value.lab_id != '0') && (value.lab_id != null) && (value.lab_id != '')){
            setSelect2Value($("#lab_id"), "{{ URL::to('/set_lab_select2_val_by_id/') }}/" + value.lab_id);
        }
        if(typeof(value.lineitem_1_id) != "undefined" && value.lineitem_1_id !== null) {
            $("#lineitem_1_id").val(value.lineitem_1_id);
        }
    }

    function remove_1_lineitem(index) {
        if (confirm('Are you sure ?')) {
            value = lineitem_1_objectdata[index];
            lineitem_1_objectdata.splice(index, 1);
            display_lineitem_1_html(lineitem_1_objectdata);
        }
    }
</script>
@stop
