<?php
    $path = public_path('/images/pdf-top-logo.png');
    $type = pathinfo($path, PATHINFO_EXTENSION);
    $data = file_get_contents($path);
    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

    $path = public_path('/images/pdf-bottom-logo.png');
    $data = file_get_contents($path);
    $base642 = 'data:image/' . $type . ';base64,' . base64_encode($data);
?>
<html>
    <head>
        <style>
            /** 
                Set the margins of the page to 0, so the footer and the header
                can be of the full height and width !
             **/
            @page {
                margin: 0cm 0cm;
            }

            /** Define now the real margins of every page in the PDF **/
            body {
                margin-top: 3.22cm;
                margin-left: 2cm;
                margin-right: 2cm;
                margin-bottom: 3.22cm;
                font-family: 'arial';
                font-size:15px;
            }

            /** Define the header rules **/
            header {
                position: fixed;
                top: 0cm;
                left: 0cm;
                right: 0cm;
                height: 3.22cm;

                /** Extra personal styles **/
                /* background-color: ''; */
                color: white;
                text-align: left;
                line-height: 1.5cm;
            }

            /** Define the footer rules **/
            footer {
                position: fixed; 
                bottom: 0cm; 
                left: 0cm; 
                right: 0cm;
                height: 3.22cm;

                /** Extra personal styles **/
                /* background-color: #03a9f4; */
                color: white;
                text-align: left;
                /* line-height: 1.5cm; */
            }
        </style>
    </head>
    <body>
        <!-- Define header and footer blocks before your content -->
        <header>
            <img src="{{ $base64 }}"  />
        </header>

        <footer>
            <img src="{{ $base642 }}"  />
        </footer>

        <!-- Wrap the content of your PDF inside a main tag -->
        
        <main>
            <table border="0" width="100%">
                <tr>
                    <td nowrwap>CONFIRMATION NO DAE # 12465.19</td>
                    <td style="float:right">20TH DECEMBER 2019</td>
                </tr>
            </table>
            <table border="0" width="100%">
                <tr>
                    <td colspan="2" style="text-align:left">WE HEREBY CONFIRM HAVING SOLD TO YOU AND YOU HAVING BOUGHT FROM US:</td>
                </tr>
                <tr>
                    <td valign="top">SELLER</td>
                    <td >
                        <table border="0" width="100%">
                            <tr>
                                <td>
                                    <strong>DHAVAL AGRI EXPORTS LLP</strong>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    A-75, NEW MARKET YARD,
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    MORBI ROAD, VILLAGE BEDI,
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    RAJKOT-360 003, GUJARAT,
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>INDIA.</strong>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="top">CONSIGNEE</td>
                    <td >
                        <table border="0" width="100%">
                            <tr>
                                <td>
                                    <strong>FRAM, LLC</strong>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    ROOM I, OFFICE 1, ROCHDELSKAYA STREET,
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    15, BUILD.16,
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    MOSCOW 123022,
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>RUSSIA.</strong>
                                    <br />
                                    (ALL DOCUMENTS WILL APPEAR THE ABOVE NAME)
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="top">COMMODITY</td>
                    <td style="text-align:left">SESAME SEEDS AND AMARANTH SEEDS</td>
                </tr>
                <tr>
                    <td valign="top">QUALITY QUANTITY AND PRICE</td>
                    <td style="text-align:left">
                        [1] <strong>930 CARTONS</strong> ROASTED HULLED SESAME SEEDS<br />
                        @ <strong>USD 2425/MT</strong> – 1 KG PACK<br />
                        [2] <strong>365 CARTONS</strong> HULLED SESAME SEEDS COLOUR SORTEXED<br />
				            PURITY 99.97% @ <strong>USD 2255/MT</strong> – 1 KG PACK<br />
                        [3] <strong>3 MTS</strong> AMARANTH SEEDS @ <strong>USD 1500/MT</strong> – 25 KG PACK
                    </td>
                </tr>
                <tr>
                    <td valign="top">QUANTITY</td>
                    <td >01 X 40’ FCL [ABOUT 23.00 MT +/- 5% QUANTITY TOLERANCE]</td>
                </tr>
                <tr>
                    <td valign="top">PACKING</td>
                    <td >1 KG PP IN OUTER CARTON AND 25 KG NET PP BAG</td>
                </tr>
                <tr>
                    <td valign="top">SHIPPING MARKS</td>
                    <td >AS PER INSTRUCTIONS</td>
                </tr>
                <tr>
                    <td valign="top">SHIPMENT</td>
                    <td >01 X 40’ FCL SHIPMENT BY 19TH FEBRUARY 2020
                    SHIPMENT DATES ARE SUBJECT TO FORCES MAJ
                    </td>
                </tr>
                <tr>
                    <td valign="top">PORT OF LOADING</td>
                    <td >MUNDRA / KANDLA / PIPAVAV [INDIA]</td>
                </tr>
                <tr>
                    <td valign="top">PORT OF DESTINATION</td>
                    <td >ST. PETERSBERG [RUSSIA]</td>
                </tr>
                <tr>
                    <td valign="top">PAYMENT TERMS</td>
                    <td >CAD/ DP AT SIGHT/ X DAYS FROM BL DATE / 20% ADVANCE AND BALANCE PAYMENT TT OR CAD OR DP AT SIGHT</td>
                </tr>
                <tr>
                    <td valign="top">BANK DETAILS</td>
                    <td >
                        <table border="0" width="100%">
                            <tr>
                                <td colspan="2">
                                    <strong>HDFC Bank Limited.</strong>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>Account Number: </strong>
                                </td>
                                <td >
                                    000610203220323
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>IFSC: </strong>
                                </td>
                                <td >
                                    3566543
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>IBAN: </strong>
                                </td>
                                <td >
                                    AL47 2121 1009 0000 0002 3569 87411
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>SWIFT Codes: </strong>
                                </td>
                                <td >
                                    NO 93 8601 11179474
                                </td>
                            </tr>                            
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="top">USA REFERENCE BANK</td>
                    <td >
                        <table border="0" width="100%">
                            <tr>
                                <td colspan="2">
                                    <strong>New York Limited.</strong>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>Account Number: </strong>
                                </td>
                                <td >
                                    NY120610203220323
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>IFSC: </strong>
                                </td>
                                <td >
                                    3566543
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>IBAN: </strong>
                                </td>
                                <td >
                                    AL47 2121 1009 0000 0002 3569 87411
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    <strong>SWIFT Codes: </strong>
                                </td>
                                <td >
                                    NO 93 8601 11179474
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="top">SURVEYOR</td>
                    <td >GEO CHEM ANALYSIS AS PER RUSSIAN STANDARDS / SGS/ QSSLAB / OTHER LAB</td>
                </tr>
                <tr>
                    <td valign="top">DOCUMENTS REQUIRED</td>
                    <td >
                    : COMMERCIAL INVOICE 
                    <strong>PACKING LIST </strong><br/ >
                    : BILL OF LADING<br/ >
                    : CERTIFICATE OF ORIGIN <br/ >
                    : PHYTOSANITARY CERTIFICATE<br/ >
                    : FUMIGATION CERTIFICATE<br/ >
                    : INSURANCE CERTIFICATE<br/ >
                    <strong>HEALTH CERTIFICATE (EIA)</strong><br/ >
                    : GEOCHEM CERTIFICATE AS PER RUSSIAN STANDARDS<br/ >
		            GSP / APTA / CEPA / FORM AI
                    </td>
                </tr>
                <tr>
                    
                    <td colspan="2">
                    OTHER TERMS AND CONDITION: -
                        <ol>
                        <li>Shipped quantity, quality & weight final as per ANY INDEPENDENT SURVEYOR & certified quantity, quality, result and analysis reports will be final based at the load port only.</li>
                        <li>Above contract as per FOSFA No. 13, contract terms & condition & applicable for this commodity as on date.</li>
                        <li>Advance payment (If any) to be paid within 7 days from signing the contract.</li>
                        <li>ALL Taxes, Duties, Licenses in importing country are on buyer account and in exporting country are on seller account.</li>
                        <li>Buyer’s banker charges on buyers account and Seller’s banker charges on seller account.</li>
                        </ol>
                        Kindly sign the duplicate copy of this contract as token of your acceptance of above terms and condition and return the same to us. However, your failure to return the same duly signed documents does not in any way effect or alters the validity of this contract.
                    </td>
                </tr>
                <tr>
                    <td colspan="2" height="10"></td>
                </tr>
                <tr>
                    <td valign="top">
                        BUYER<br/ >
                        <strong>FRAM, LLC
                    </td>
                    <td valign="top" style="text-align:right">
                        SELLER<br/ >
                        <strong>DHAVAL AGRI EXPORTS LLP</strong>
                    </td>
                </tr>

            </table>
        </main>
    </body>
</html>
