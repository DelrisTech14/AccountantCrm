{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dhaval Agri | Create Contract')

@section('css')
<link rel="stylesheet" href="{{ asset('vendor/select2/css/select2.min.css') }}" type="text/css" />
<link id="bsdp-css" href="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/css/bootstrap-datepicker3.min.css" rel="stylesheet">

<style>
    table .actions{
        white-space: nowrap;
    }
</style>
@stop
@section('content_header')
<h1>Create Contract</h1>
@stop

@section('content')
<div class="card" id="sellapp" style="font-size: 14px !important;">
    <div class="card-body">
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>
                    {{ $error }}
                </li>
                @endforeach
            </ul>
        </div>
        @endif
        <div class="box-body">
            {{ Form::open( ['name'=>'save_item', 'id' => 'save_item', 'method' => 'post', 'url' => 'admin/contracts/store',  'enctype' => 'multipart/form-data', 'data-parsley-validate' => '']) }}
            <div class="row">
                <div class="col-md-4 pull-md-right">
                    <div class="form-group">
                        {{ Form::label('date', 'Date', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                        {{ Form::text('date', date('m/d/Y'), ['required' => 'required', 'class' => 'form-control', 'placeholder' => 'mm/dd/yyyy','autofocus' => 'autofocus']) }}
                        <p class="text-danger">@error('item_name'){{$message}}@enderror</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12"><h3>Seller Info</h3></div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('seller_id', 'Seller', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" required='required' id="seller_id" name="seller_id">
                            <option>Select Seller</option>
                            @foreach($sellers as $seller)
                                <option
                                    data-address="{{$seller->address}}"
                                    data-city="{{$seller->city_id}}"
                                    data-pincode="{{$seller->pincode}}"
                                    data-country="{{$seller->country_id}}"
                                    data-state_id="{{$seller->state_id}}"
                                    data-surveyor_id="{{$seller->surveyor_id}}"
                                    data-default_bank="{{$seller->default_bank}}"
                                    data-default_port="{{$seller->default_port}}"
                                    
                                    value="{{$seller->id}}">{{$seller->name}}</option>
                            @endforeach
                        </select>
                        {{ Form::hidden('seller_name', '', ['id' => 'seller_name']) }}

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('seller_address', 'Seller Address', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::textarea('seller_address','', ['id' => 'seller_address', 'required' => 'required', 'class' => 'form-control', 'rows' => 4, 'cols' => 40, 'placeholder' => 'Seller Address']) }}
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('city', 'City', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select class="form-control select2" required='required'  id="city" name="city">
                                <option>Select City</option>
                                @foreach($cities as $city)
                                    <option value="{{$city->id}}">{{$city->city_name}}</option>
                                @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('pincode', 'Pincode', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                {{ Form::text('pincode', '', ['id' => 'pincode', 'required' => 'required', 'class' => 'form-control', 'placeholder' => 'Pincode']) }}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('state', 'State', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select class="form-control select2" required='required' id="state" name="state">
                                    <option>Select State</option>
                                    @foreach($states as $state)
                                        <option value="{{$state->id}}">{{$state->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('country', 'Country', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select class="form-control select2" required='required' id="country" name="country">
                                    <option>Select Country</option>
                                    @foreach($countries as $country)
                                        <option value="{{$country->id}}">{{$country->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12"><hr /></div>
            </div>            
            <div class="row">
                <div class="col-md-12"><h3>Buyer Info</h3></div>

                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('buyer_id', 'Buyer', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" required='required' id="buyer_id" name="buyer_id">
                            @foreach($buyers as $buyer)
                                <option
                                    data-address="{{$buyer->address}}"
                                    data-city="{{$buyer->city_id}}"
                                    data-pincode="{{$buyer->pincode}}"
                                    data-country="{{$buyer->country_id}}"
                                    data-state_id="{{$buyer->state_id}}"
                                    data-surveyor_id="{{$buyer->surveyor_id}}"
                                    data-currency="{{$buyer->currency_id}}"
                                    data-shipping_marks="{{$seller->shipping_marks}}"
                                    data-default_port="{{$seller->default_port}}"
                                    value="{{$buyer->id}}"
                                >{{$buyer->name}}</option>
                            @endforeach

                        </select>
                        {{ Form::hidden('buyer_name', '', ['id'=>'buyer_name']) }}

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('buyer_address', 'Buyer Address', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::textarea('buyer_address','', ['id' => 'buyer_address', 'required' => 'required', 'class' => 'form-control', 'rows' => 4, 'cols' => 40, 'placeholder' => 'Buyer Address']) }}
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('buyer_city', 'City', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select class="form-control select2" required='required' id="buyer_city" name="buyer_city">
                                    <option>Select City</option>
                                    @foreach($cities as $city)
                                        <option value="{{$city->id}}">{{$city->city_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('buyer_pincode', 'Pincode', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                {{ Form::text('buyer_pincode', '', ['id' => 'buyer_pincode', 'required' => 'required', 'class' => 'form-control', 'placeholder' => 'Pincode']) }}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('buyer_state', 'State', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select class="form-control select2" required='required' id="buyer_state" name="buyer_state">
                                    <option>Select State</option>
                                    @foreach($states as $state)
                                        <option value="{{$state->id}}">{{$state->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('buyer_country', 'Country', ['class' => 'control-label']) }} <span class="text-danger"></span>                                
                                <select class="form-control select2" required='required' id="buyer_country" name="buyer_country">
                                    <option>Select Country</option>
                                    @foreach($countries as $country)
                                        <option value="{{$country->id}}">{{$country->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12"><hr /></div>
            </div>
            <div class="row">
                <div class="col-md-12"><h3>Commodity Info</h3></div>
            </div>
            <div class="row checkEvent" id="cloneCommodityFrom">
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('item_id_input', 'Commodity', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="item_id_input">
                            <option>Select Commodity</option>
                            @foreach($commodities as $commodity)
                                <option
                                    data-quality="{{$commodity->quality_id}}"
                                    data-unit="{{$commodity->quantity_unit_id}}"
                                    data-price_unit_id="{{$commodity->price_unit_id}}"
                                    value="{{$commodity->id}}"
                                >{{$commodity->name}}</option>
                            @endforeach
                        </select>
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        {{ Form::label('quality_input', 'Quality', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="quality_input">
                            <option>Select Quality</option>
                            @foreach($qualities as $quality)
                                <option value="{{$quality->id}}">{{$quality->quality}}</option>
                            @endforeach
                        </select>
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group ">
                        {{ Form::label('tolerance_id_input', 'Tolerance', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2"  id="tolerance_id_input">
                            @foreach($tolerances as $tolerance)
                                <option value="{{$tolerance->id}}">{{$tolerance->tolerance}}</option>
                            @endforeach
                        </select>
                        
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        {{ Form::label('quantity_input', 'Quantity', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('', '', ['id'=>'quantity_input', 'class' => 'form-control', 'placeholder' => 'Quantity']) }}
                        
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        {{ Form::label('unit_input', 'Unit', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="unit_input">
                            <option>Select Unit</option>
                            @foreach($units as $unit)
                                <option @if ($unit->quantity_in == 'MT') selected @endif value="{{$unit->id}}">{{$unit->quantity_in}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        {{ Form::label('price_input', 'Price', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('', '', ['id'=>'price_input', 'class' => 'form-control', 'placeholder' => 'Price']) }}
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        {{ Form::label('currency_input', 'Currency', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2"   id="currency_input">
                            <option>Select Currency</option>
                            @foreach($currencies as $currency)
                                <option value="{{$currency->id}}">{{$currency->currency}}</option>
                            @endforeach
                        </select>
                        
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        {{ Form::label('price_in_unit_input', 'Price in Unit', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="price_in_unit_input">
                            <option>Price in Unit</option>
                            @foreach($units as $unit)
                                <option @if ($unit->quantity_in == 'MT') selected @endif value="{{$unit->id}}">{{$unit->quantity_in}}</option>
                            @endforeach
                        </select>
                        
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="form-group">
                        {{ Form::label('cif_fob_input', 'CIF / FOB', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2 cif_fob"  id="cif_fob_input">
                            <option value="FOB">FOB</option>
                            <option value="CIF">CIF</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group portDiv">
                        {{ Form::label('port_input', 'Port', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" id="port_input">
                            <option>Select Port</option>
                            @foreach($ports as $port)
                                @if ($port->is_fob == 1)
                                    <option value="{{$port->id}}">{{$port->name}}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('packing_input', 'Packing', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('', '', ['id' => 'packing_input','class' => 'form-control', 'placeholder' => 'Packing']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('shipping_marks_input', 'Shipping Marks', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('', '', ['id' => 'shipping_marks_input',  'class' => 'form-control', 'placeholder' => 'Shipping Marks']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('shipment_input', 'Shipment', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('', '', ['id' => 'shipment_input',  'class' => 'form-control', 'placeholder' => 'Shipment']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('port_of_loading_input', 'Port of Loading', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2"  id="port_of_loading_input">
                            <option>Port of Loading</option>
                            @foreach($ports as $port)
                                @if ($port->is_loading == 1)
                                    <option value="{{$port->id}}">{{$port->name}}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                {{ Form::label('port_of_destination_input', 'Port of Destination', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                <select class="form-control select2" id="port_of_destination_input" >
                                    <option>Port of Destination</option>
                                    @foreach($ports as $port)
                                    @if ($port->is_destination == 1)
                                        <option value="{{$port->id}}">{{$port->name}}</option>
                                    @endif
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                {{ Form::label('shipment_date_input', 'Shipment Date', ['class' => 'control-label']) }} <span class="text-danger"></span>
                                {{ Form::text('', '', ['id' => 'shipment_date_input', 'class' => 'form-control ', 'placeholder' => 'mm/dd/yyyy']) }}
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group " id="cloneCommodityButton" style="margin-top:18px;">
                                {{ Form::button('<i class="fa fa-plus" ></i> Add Line Item', ['id' => 'cloneCommodity', 'class' => 'btn btn-primary']) }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row checkEvent" >
                <div class="col-md-12">
                    <table width="100%" class="table table-responsive" id="tableInfo">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Item</th>
                                <th>Quality</th>
                                <th>Tolerance</th>
                                <th>Quantity</th>
                                <th>Unit</th>
                                <th>Price</th>
                                <th>Price in Unit</th>
                                <th>Currency</th>
                                <th>CIF / FOB</th>
                                <th>Port</th>
                                <th>Packing</th>
                                <th>Shipping Marks</th>
                                <th>Shipment</th>
                                <th>Port of Loading</th>
                                <th>Port of Destination</th>
                                <th>Shipment Date</th>
                            </tr>
                        </thead>
                        <tbody id="tableData">
                        <tbody>
                    <table>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12"><hr /></div>
            </div>
            <div class="row">
                <div class="col-md-12"><h3 class="title">Payment Info</h3></div>

                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('payment_terms', 'Payment Terms', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        {{ Form::text('payment_terms', '', ['id' => 'payment_terms','required' => 'required',  'class' => 'form-control', 'placeholder' => 'Payment Terms']) }}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('bank', 'Bank Details', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" required='required' id="bank" name="bank">
                            <option>Select Bank</option>
                            @foreach($banks as $bank)
                                <option value="{{$bank->id}}">{{$bank->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('usa_reference_bank', 'USA Reference Bank', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" required='required' id="usa_reference_bank" name="usa_reference_bank">
                            <option>Select Reference Bank</option>
                            @foreach($banks as $bank)
                                @if ($bank->is_reference == 1)
                                <option value="{{$bank->id}}">{{$bank->name}}</option>
                                @endif
                            @endforeach
                        </select>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {{ Form::label('surveyor', 'Surveyor', ['class' => 'control-label']) }} <span class="text-danger"></span>
                        <select class="form-control select2" required='required' id="surveyor" name="surveyor">
                            <option>Select Surveyor</option>
                            @foreach($surveyors as $surveyor)
                                <option value="{{$surveyor->id}}">{{$surveyor->name}}</option>
                            @endforeach
                        </select>
                        {{ Form::hidden('surveyor_name', '', ['id' => 'surveyor_name']) }}
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12"><hr /></div>
            </div>
            {{ Form::submit('Save', ['class' => 'btn btn-primary module_save_btn']) }}
            {{ Form::close() }}
        </div>
        <div class="box-footer with-border">
        </div>
    </div>
</div>

@stop

@section('js')
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.4.0/bootbox.min.js" integrity="sha256-sfG8c9ILUB8EXQ5muswfjZsKICbRIJUG/kBogvvV5sY=" crossorigin="anonymous"></script>
<script src="{{ asset('vendor/select2/js/select2.min.js') }}"></script>
<script src="{{ asset('vendor/select2/select2.js') }}"></script>
<script src="{{ asset('vendor/jquery.validate.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script src="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/js/bootstrap-datepicker.min.js"></script>

<script type="text/javascript">
let currentIndex = $("#tableData").children('tr').length;

function editThis(index) {
    var inputs = $("table#tableInfo tr#index_"+index+"").find('input');
    $.each(inputs, function(key, input) {
        var setId = $(input).attr('id');
        $("#"+setId+"_input").val($("#"+setId).val());
        $("#"+setId+"_input").change();
    })
    $("table#tableInfo tr#index_"+index+"").remove();
}
function deleteThis(index) {
    $("table#tableInfo tr#index_"+index+"").remove();
}
$(document).ready(function() {
    let cloneCommodityTo = [];
    $("#item_id_input").on("change", function() {
        $("#quality_input").val(
            $("#item_id_input option:selected").attr("data-quality")
        );
        $("#unit_input").val(
            $("#item_id_input option:selected").attr("data-unit")
        );
        $("#price_in_unit_input").val(
            $("#item_id_input option:selected").attr("data-price_unit_id")
        );
        // price_in_unit_input
    });
    $("#seller_id").on("change", function() {
        let seller_id = $("#seller_id option:selected").val();
        $("#seller_name").val($("#seller_id option:selected").text());
        $("#seller_address").text($("#seller_id option:selected").attr('data-address'));
        $("#pincode").val($("#seller_id option:selected").attr('data-pincode'));
        $("#city").val($("#seller_id option:selected").attr('data-city')).trigger('change');
        $("#country").val($("#seller_id option:selected").attr('data-country')).trigger('change');
        $("#state").val($("#seller_id option:selected").attr('data-state_id')).trigger('change');
        $("#port_of_loading").val($("#seller_id option:selected").attr('data-default_port')).trigger('change');
        $("#bank").val($("#seller_id option:selected").attr('data-default_bank')).trigger('change');
        
    });

    $("#buyer_id").on("change", function() {
        let buyer_id = $("#buyer_id option:selected").val();
        $("#buyer_name").val($("#buyer_id option:selected").text());
        $("#buyer_address").text($("#buyer_id option:selected").attr('data-address'));
        $("#buyer_pincode").val($("#buyer_id option:selected").attr('data-pincode'));
        $("#buyer_city").val($("#buyer_id option:selected").attr('data-city')).trigger('change');
        $("#buyer_country").val($("#buyer_id option:selected").attr('data-country')).trigger('change');
        $("#buyer_state").val($("#buyer_id option:selected").attr('data-state_id')).trigger('change');
        $("#surveyor").val($("#buyer_id option:selected").attr('data-surveyor_id')).trigger('change');
        $("#shipping_marks_input").val($("#buyer_id option:selected").attr('data-shipping_marks'));
        
        // currency from buyer table
        $("#currency_input").val(
            $("#buyer_id option:selected").attr("data-currency")
        );
    });
    $("#buyer_id").change();
    $("#surveyor").on('change', function() {
        $("#surveyor_name").val($("#surveyor option:selected").text());
    });
    $("#shipment_date_input").datepicker({
        format: 'mm/dd/yyyy',
        startDate: '-3d'
    });
    $("#shipment_date_input").datepicker({
        format: 'mm/dd/yyyy',
        startDate: '-3d'
    });
    $("#date").datepicker({
        format: 'mm/dd/yyyy',
        startDate: '-3d'
    });


    $("#cloneCommodity").on("click", function() {
        let inputAndSelect = $("#cloneCommodityFrom").find("input, select");
        let cloneToPush = [];
        currentIndex++
        let html = "<tr id='index_"+currentIndex+"'>";
        html += "<td>";
        html += "<a href='javascript:void(0)' onClick='editThis("+currentIndex+")' ><i class='fa fa-edit' ></i></a>";
        html += "<a href='javascript:void(0)' class='text-danger' onClick='deleteThis("+currentIndex+")' ><i class='fa fa-trash' ></i></a>";
        html += "</td>";
        // 
        $.each(inputAndSelect, function(key, val) {
            var id = $(val).attr("id");
            elementName = id.replace('_input', '')
            input = '<input type="hidden" value="'+$("#"+id).val()+'" name="'+elementName+'[]" id="'+elementName+'" />'
            html += "<td>";
            if ($(val).is('input')) {
                html += $("#"+id).val();
                $("#"+id).val($("#"+id).data("original-value"));
            } else {
                html += $("#"+id+" option:selected").text();
                $("#"+id+" option:selected").prop('selected', function() {
                    return this.defaultSelected;
                });
            }
            // 
            html +=  input + "</td>";
        });
        html += "</tr>";
        $("#tableData").append(html)
        // $("#cloneCommodityFrom").find("input, select").reset();
    });

    $(document).on("change", '.cif_fob', function() {
        if ($(this).val() == 'CIF') {
            $(this).parent().parent().next().children(".portDiv").hide();
        } else {
            $(this).parent().parent().next().children(".portDiv").show();
            
        }
    });
});
jQuery(document).keydown(function (event) {
    // If Control or Command key is pressed and the S key is pressed
    // run save function. 83 is the key code for S.
    if ((event.ctrlKey || event.metaKey) && event.which == 83) {
        $("#submit_info").click();
        // Save Function
        event.preventDefault();
        return false;
    }
});

</script>
@stop
