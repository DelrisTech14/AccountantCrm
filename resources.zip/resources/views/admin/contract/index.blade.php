{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dhaval Agri | Contracts')

@section('content_header')
<h1>Contracts</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        @include ('error')
        <p class="float-right">
            <a class="btn btn-primary" href="{!!route('contracts.create')!!}"><i class="fa fa-plus"></i> Create Contract</a>
        </p>
        
        <div class="table-responsive">
            <table id="contracts" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="100px">Action</th>
                        <th>DAE #</th>
                        <th>Date</th>
                        <th>Buyer Name</th>
                        <th>Seller Name</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
    var cityTable;
        $(document).ready( function(){
            $(document).on('click', '.delete_contract', function(){
                var delete_city_id = $(this).attr('data-city_id');
                $('#delete_city_id').val(delete_city_id);
                $('#deleteCityModel').modal('show');
                return false;
            });

            let contracts = $('#contracts').DataTable({
                "bServerSide": true,
                "processing": true,
                "bRetrieve": true,
                "pageLength": 10,
                "ajax": {
                    "url": "{{ URL::to('/admin/contracts/') }}",
                    "type": "GET",
                    "data": function () {

                    },
                },
                "columns": [{
                    "data": 'id',
                    "sClass": 'text-nowrap',
                    "render": function( data, type, full, meta ) {
                        var edit_button = '<button class="btn btn-sm btn-info edit_city" data-city_id="'+ data +'"><i class="fa far fa-edit"></i></button>';
                        var print_button = '<a href="{{ URL::to('/admin/contracts/print') }}/'+data+'" target="_blank" class="btn btn-sm btn-warning print_contract" title="Print"><span class="fa fa-print"></span></a>';
                        var delete_button = '<button class="btn btn-sm btn-danger delete_contract" title="Delete"><span class="fa fa-times-circle"></span></button>';
                        return edit_button + ' ' + print_button + ' ' + delete_button;
                    }
                }, {
                    "data": "con_no",
                    "defaultContent": '-',
                    "searchable": false,
                }, {
                    "data": "date",
                    "defaultContent": '-',
                    "searchable": false,
                }, {
                    "data": "seller_name",
                    "defaultContent": '-',
                    "searchable": false,
                }, {
                    "data": "buyer_name",
                    "defaultContent": '-',
                    "searchable": false,
                }],
                "ordering": true,
                "searching": true,
            });
        });
    </script>
@stop