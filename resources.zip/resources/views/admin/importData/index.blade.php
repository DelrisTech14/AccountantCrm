{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dhaval Agri | Import Data')

@section('content_header')
<h4 class="mb-0">Import Data</h4>
@stop

@section('css')
@stop

@section('content')
@include ('error')
<div class="box-body">
    <div class="card-body bg-white">
            {{ Form::open(['id' => 'save_import_data', 'method' => 'post', 'enctype' => 'multipart/form-data', 'data-parsley-validate' => '']) }}
            {{ csrf_field() }}
            <div class="row">
                <div class="col-md-12">
                    <div class="row mlr-0">
                        <div class="col-12">
                            <label for="">Import For</label>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio1" value="import_freight_data" class=""> &nbsp; 
                                <label for="import_radio1">Freight Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/freight-sample.xlsx') }}">Download Freight Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio2" value="import_port_data" class=""> &nbsp; 
                                <label for="import_radio2">Port Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/port-sample.xlsx') }}">Download Port Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio3" value="import_quality_data" class=""> &nbsp; 
                                <label for="import_radio3">Qualities Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/qualities-sample.xlsx') }}">Download Qualities Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio4" value="import_city_data" class=""> &nbsp; 
                                <label for="import_radio4">City Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/city-sample.xlsx') }}">Download City Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio5" value="import_expenses_name_data" class=""> &nbsp; 
                                <label for="import_radio5">Expenses Name Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/expenses_name-sample.xlsx') }}">Download Expenses Name Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio6" value="import_bank_data" class=""> &nbsp; 
                                <label for="import_radio6">Bank Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/bank-sample.xlsx') }}">Download Bank Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio7" value="import_container_types_data" class=""> &nbsp; 
                                <label for="import_radio7">Container Types Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/container_types-sample.xlsx') }}">Download Container Types Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio8" value="import_currency_data" class=""> &nbsp; 
                                <label for="import_radio8">Currency Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/currency-sample.xlsx') }}">Download Currency Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio9" value="import_payment_terms_data" class=""> &nbsp; 
                                <label for="import_radio9">Payment Terms Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/payment_terms-sample.xlsx') }}">Download Payment Terms Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio10" value="import_quantity_in_data" class=""> &nbsp; 
                                <label for="import_radio10">QuantityIn Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/quantity_in-sample.xlsx') }}">Download QuantityIn Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio11" value="import_lab_data" class=""> &nbsp; 
                                <label for="import_radio11">Lab Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/lab-sample.xlsx') }}">Download Lab Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio12" value="import_state_data" class=""> &nbsp; 
                                <label for="import_radio12">State Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/state-sample.xlsx') }}">Download State Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio13" value="import_tolerance_data" class=""> &nbsp; 
                                <label for="import_radio13">Tolerance Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/tolerance-sample.xlsx') }}">Download Tolerance Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio14" value="import_packing_data" class=""> &nbsp; 
                                <label for="import_radio14">Packing Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/packing-sample.xlsx') }}">Download Packing Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio15" value="import_fumigation_and_fumigation_dosage_data" class=""> &nbsp; 
                                <label for="import_radio15">Fumigation & Fumigation Dosage Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/import_fumigation_and_fumigation_dosage_data-sample.xlsx') }}">Download Fumigation & Fumigation Dosage Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio16" value="import_expense_data" class=""> &nbsp; 
                                <label for="import_radio16">Expense Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/expense_data-sample.xlsx') }}">Download Expense Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio17" value="import_commodities_data" class=""> &nbsp; 
                                <label for="import_radio17">Commodities Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/commodities_data-sample.xlsx') }}">Download Commodities Sample</a>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <input type="radio" name="import_radio" id="import_radio18" value="import_commodity_container_type_wise_qty_data" class=""> &nbsp; 
                                <label for="import_radio18">Commodity + Container Type Wise Default Qty Data</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <a href="{{asset('sample/Commodity_Container_Type_Wise_Qty_sample.xlsx') }}">Download Commodity + Container Type Wise Default Qty Sample</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row mlr-0">
                        <div class="col-6">
                            <div class="form-group">
                                {{ Form::label('import_file', 'Import File', ['class' => 'control-label']) }} <span class="text-danger">*</span>
                                <input type="file" name="import_file" id="import_file" class="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row ml-12">
                <div class="col-md-2 "><br>
                    {{ Form::submit('Upload', ['class' => 'btn btn-primary module_save_btn']) }}
                </div>
                <div class="col-md-3"><br>
                    <h4 class="ajax_waiting_div text-danger blink_div d-none">Waiting, File Uploading..</h4>
                </div>
            </div>
        {{ Form::close() }}
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>
        $(document).ready( function(){
            $(document).on('change', '#import_file', function () {
                var radio = $('input[name="import_radio"]:checked').val()
                if(typeof(radio) == 'undefined') {
                    bootbox.alert('<span class="text-danger">First Please Select Import Options</span>');
                    $('#import_file').val('');
                    return false;
                }
                var fileExtension = ['xls','xlsx'];
                if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                    bootbox.alert('<span class="text-danger">Only .xls or .xlsx format is allowed</span>');
                    $('#import_file').val('');
                    $('#import_file').focus();
                    return false;
                }
            });

            $(document).on('submit', '#save_import_data', function (e) {
//                e.preventDefault();
                if($('#import_file').val() == ""){
                    bootbox.alert('<span class="text-danger">Please Upload file !</span>');
                    $('#import_file').focus();
                    return false;
                }
                var radio = $('input[name="import_radio"]:checked').val()
                if(typeof(radio) == 'undefined') {
                    bootbox.alert('<span class="text-danger">Please Select Import Options !</span>');
                    return false;
                }
                $('.module_save_btn').attr('disabled', 'disabled');
                $('.ajax_waiting_div').removeClass('d-none');
                var postData = new FormData(this);
                setTimeout(function(){
                    $.ajax({
                        url: "{{ URL::to('/admin/importData/store') }}",
                        type: "POST",
                        processData: false,
                        contentType: false,
                        cache: false,
                        data: postData,
                        datatype: 'json',
                        async: false,
                        success: function (response) {
                            $('.module_save_btn').removeAttr('disabled', 'disabled');
                            $('.ajax_waiting_div').addClass('d-none');
                            var json = $.parseJSON(response);
                            if (json['success'] == 'Added') {
                                row_html = '';
                                if ((json['not_inserted_data'] != '') || (json['master_inserted_data'] != '')) {
                                    row_html = '<b>Import Data Successfully.</b><br/><br/>';
                                    if(json['not_inserted_data'] != ''){
                                        $.each(json['not_inserted_data'], function (mkey, mval) {
                                            row_html += '<table border="1" cellpadding="5" style="border-color: #DC143C;">';
                                            row_html += '<tr>';
                                            row_html += '<th>'+mkey+' : Data Not Available</th>';
                                            row_html += '</tr>';
                                            $.each(json['not_inserted_data'][mkey], function (key, val) {
                                                row_html += '<tr>';
                                                row_html += '<td>'+val+'</td>';
                                                row_html += '</tr>';
                                            });
                                            row_html += '</table><br/>';
                                        });
                                    }
                                    if(json['master_inserted_data'] != ''){
                                        $.each(json['master_inserted_data'], function (mkey, mval) {
                                            row_html += '<table border="1" cellpadding="5" style="border-color: #000000;">';
                                            row_html += '<tr>';
                                            row_html += '<th>'+mkey+' : Master Data Inserted</th>';
                                            row_html += '</tr>';
                                            $.each(json['master_inserted_data'][mkey], function (key, val) {
                                                row_html += '<tr>';
                                                row_html += '<td>'+val+'</td>';
                                                row_html += '</tr>';
                                            });
                                            row_html += '</table><br/>';
                                        });
                                    }
                                    console.log(row_html);
                                    redirectWithFlashMessage("{{ URL::to('/admin/importData/') }}/", 'success_with_data', row_html);
                                    return false;
                                } else {
                                    redirectWithFlashMessage("{{ URL::to('/admin/importData/') }}/", 'success', 'Import Data Successfully.');
                                }
                            } else {
                                bootbox.alert('<span class="text-danger">Something error occurred</span>');
                                return false;
                            }

                            return false;
                        },
                    });
                }, 1000);
                return false;
            });

        });
    </script>
@stop