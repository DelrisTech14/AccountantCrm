{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dhaval Agri | Loadability')

@section('content_header')
<h1>Loadability</h1>
@stop

@section('css')
<link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{asset('vendor/parsleyjs/src/parsley.css') }}">
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <div id="error_msg"></div>
           <form action="{{ isset($loadabilityedit)? route('update',$loadabilityedit->id) : route('store') }}" method="post">
            @csrf
            @include ('error')
            
            <div class="row py-2" id="all-row-py-2">
                <div class="col-sm-3"> <label for="commodity_id">Commodity</label>
                    <select name="commodity_id" id="commodity_id" class="form-control">
                        
                        <option value="" >Select Commodity</option>
                       
                        @foreach ($commodity as $cd)
                        <option value="{{$cd->id}}" {{@$loadabilityedit->commodity_id === $cd->id ? 'selected':''}} >{{$cd->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-sm-3"> <label for="quality_id">Quality</label>
                    <select name="quality_id" id="quality_id" class="form-control chosen-select">
                        <option value="" >Select Quality</option>
                    </select>
                </div>
                <div class="col-sm-3"> <label for="container_type_id">Container Type</label>
                    <select name="container_type_id" id="container_type_id" class="form-control">
                        <option value="">Select Container_type</option>
                        @foreach ($container_type as $ct)
                        <option value="{{$ct->id}}" {{@$loadabilityedit->container_type_id === $ct->id ? 'selected':''}}>{{$ct->container_type_name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-sm-3">
                    <label for="loadability">Loadability</label>
                    <input type="text" name="loadbility" value="{{@$loadabilityedit->loadbility}}" id="loadability" class="form-control">

                </div>
            </div>

            <div class="row">
                <button type="submit" class="btn btn-success">
                    @if(@$loadabilityedit)
                    Update
                    @else
                    Save
                    @endif
                </button>
            </div>
           </form>
    </div>
</div>



<div class="card">
    <div class="card-body">
        @include ('error')
        <div class="table-responsive">
            <table id="dataTable-quantity_in" class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-nowrap" width="100px">Action</th>
                        <th>Commodity</th>
                        <th>Quality</th>
                        <th>Container Type</th>
                        <th>Loadability</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($loadabilities as $lb)
                    <tr>
                        <td>
                            <a href="{{route('edit',$lb->id)}}" class="btn btn-sm btn-info edit_container_type" ><i class="fa far fa-edit"></i></a>
                            <a href="{{route('destroy',$lb->id)}}" class="btn btn-sm btn-danger edit_container_type" ><i class="fa fa-times-circle"></i></a>
                            
                        </td>
                        <td>{{$lb->commodity->name}}</td>
                        <td>{{$lb->quality->quality}}</td>
                        <td>{{$lb->containerType->container_type_name}}</td>
                        <td>{{$lb->loadbility}}</td>

                        
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>
        </div>
        
    </div>
</div>

@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{asset('vendor/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
    <script src="{{asset('vendor/bootbox/bootbox.min.js') }}"></script>
    <script>




        $(document).ready(function(){

            @if($mode=='edit')
            loadData({{$loadabilityedit->quality_id}})
            @endif
            $('#commodity_id').change(function(){
                
                // console.log(data)
                loadData(0)

            })
        })

        function loadData(quality_id){
            let commodity_id=$('#commodity_id').val()

            console.log(quality_id, 'quality_id')

                $.ajax({
                    url: '/get_commodity/'+ commodity_id,
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        console.log(data, 'data')
                        let html='<option value="" >Select Quality</option>'

                        data.map(function(d){
                            html +=`<option value='${d.id}'`
                            if(quality_id==d.id) {
                                html +=`selected`  
                            }
                            html +=`>${d.quality}</option>`
                        })

                        $('#quality_id').empty().append(html)
                    }
                });

        }


    </script>
@stop
