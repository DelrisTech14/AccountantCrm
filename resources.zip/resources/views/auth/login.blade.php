@extends('adminlte::master')

@section('adminlte_css_pre')
    <link rel="stylesheet" href="{{ asset('vendor/icheck-bootstrap/icheck-bootstrap.min.css') }}">
@stop
@section('title', 'Dhaval Agri | Login')

@section('adminlte_css')
    @stack('css')
    @yield('css')
@stop

@section('classes_body', 'login-page')

@php( $login_url = View::getSection('login_url') ?? config('adminlte.login_url', 'login') )
@php( $register_url = View::getSection('register_url') ?? config('adminlte.register_url', 'register') )
@php( $password_reset_url = View::getSection('password_reset_url') ?? config('adminlte.password_reset_url', 'password/reset') )
@php( $dashboard_url = View::getSection('dashboard_url') ?? config('adminlte.dashboard_url', 'home') )

@if (config('adminlte.use_route_url', false))
    @php( $login_url = $login_url ? route($login_url) : '' )
    @php( $register_url = $register_url ? route($register_url) : '' )
    @php( $password_reset_url = $password_reset_url ? route($password_reset_url) : '' )
    @php( $dashboard_url = $dashboard_url ? route($dashboard_url) : '' )
@else
    @php( $login_url = $login_url ? url($login_url) : '' )
    @php( $register_url = $register_url ? url($register_url) : '' )
    @php( $password_reset_url = $password_reset_url ? url($password_reset_url) : '' )
    @php( $dashboard_url = $dashboard_url ? url($dashboard_url) : '' )
@endif

@section('body')
    <div class="login-box" style="width: auto;">
        <div class="card">
            <div class="card-body login-card-body" style="padding: 20px;">
                <div class="row">
                    <div class="col-md-6 col-md-offset-1" style="border-right: 1px solid #ced4da; padding-right: 20px;">
                        <p class="login-box-msg">{{ __('adminlte::adminlte.login_message') }}</p>
                        <form action="{{ $login_url }}" method="post">
                            {{ csrf_field() }}
                            <div class="input-group mb-3">
                                <?php /*<input type="email" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" value="{{ old('email') }}" placeholder="{{ __('adminlte::adminlte.email') }}" autofocus>*/ ?>
                                <input type="text" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" value="{{ old('email') }}" placeholder="Email" autofocus>
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <?php /*<span class="fas fa-envelope"></span>*/ ?>
                                        <span class="fas fa-envelope"></span>
                                    </div>
                                </div>
                                @if ($errors->has('email'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('email') }}
                                    </div>
                                @endif
                            </div>
                            <div class="input-group mb-3">
                                <input type="password" name="password" class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}" placeholder="{{ __('adminlte::adminlte.password') }}">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <span class="fas fa-lock"></span>
                                    </div>
                                </div>
                                @if ($errors->has('password'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('password') }}
                                    </div>
                                @endif
                            </div>
                            <div class="row">
                                <div class="col-7">
                                    <div class="icheck-primary">
                                        <input type="checkbox" name="remember" id="remember">
                                        <label for="remember" style="font-size: 14px;">{{ __('adminlte::adminlte.remember_me') }}</label>
                                    </div>
                                </div>
                                <div class="col-5">
                                    <button type="submit" class="btn btn-primary btn-block btn-flat">
                                        {{ __('adminlte::adminlte.sign_in') }}
                                    </button>
                                </div>
                            </div>
                        </form>
                        @if ($password_reset_url)
                            <p class="mt-2 mb-1">
                                <a href="{{ $password_reset_url }}">
                                    {{ __('adminlte::adminlte.i_forgot_my_password') }}
                                </a>
                            </p>
                        @endif

                        @if ($register_url)
                            <p class="mb-0">
                                <a href="{{ $register_url }}">
                                    {{ __('adminlte::adminlte.register_a_new_membership') }}
                                </a>
                            </p>
                        @endif
                    </div>
                    <div class="col-md-6 col-md-offset-1">
                        <div class="login-logo" style="display: table-cell; text-align: center; vertical-align: middle; height: 250px; min-width: 250px;">
                            <img src="{{ asset('images/logo.jpg') }}" alt="Dhaval Agri Logo" title="Dhaval Agri Logo" style="width: 200px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

@section('adminlte_js')
    <script src="{{ asset('vendor/adminlte/dist/js/adminlte.min.js') }}"></script>
    @stack('js')
    @yield('js')
@stop
