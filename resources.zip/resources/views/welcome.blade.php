{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
<div class="container">
  <div class="row">
    <div class="col">
        <div class="js-event-log"></div>
        <select class="js-example-basic-single" name="state">
        </select>
    </div>
    <div class="col">
        <h5>Nick name</h5>
        <div id="nickname"></div>
    </div>
    <div class="col">
        <h5>Alternate product name</h5>
        <div id="altname"></div>
    </div>
  </div>
  <div class="row">
    <div class="col">
    </div>
    <div class="col">
        <h5>Product used at</h5>
        <div id="used_by"></div>
    </div>
    <div class="col">
    </div>
  </div>
</div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> 
        var studentSelect = $('.js-example-basic-single');
            studentSelect.select2();

            $(document).on('change', ".js-example-basic-single", function(){
                console.log($(this).val());
            });
            
        $("body").on('keyup', ".select2,.select2-dropdown,.js-example-basic-single", function (e) {
            var KEYS = { UP: 38, DOWN: 40 };
            var $sel2 = $(this).closest(".select2");
            // if we can't find it by traveersing the dom, search page for an open container
            // ASSUMES only one open at a time - 
            // don't really know how to cross walk from dropdown back to coresponding element
            if ($sel2.length == 0) {
                $sel2 = $(".select2.select2-container--open");
            }
            $(".js-example-basic-single").trigger("click");

            // make sure we found the <select> el
            //console.log($sel.length,"length");
            var $sel = $sel2.data("element");
            console.log($sel.length,"length");
            //console.log($sel);
            if ($sel.length) {
                var newValue

                if (e.keyCode === KEYS.DOWN && !e.altKey) {
                    console.log(KEYS.DOWN,"down");
                    console.log($sel.find('option:selected').nextAll().first());
                    newValue = $sel.find('option:selected').nextAll().first().val();
                    //$sel.find('option:selected').remove();
                    $sel.find('option:selected').nextAll(":enabled").first().attr("selected","selected");
                    console.log(newValue);
                } else if (e.keyCode === KEYS.UP) {
                    console.log(KEYS.UP,"up");
                    console.log($sel.find('option:selected').prevAll(":enabled").first());
                    
                    newValue = $sel.find('option:selected').prevAll(":enabled").first().val();
                    //$sel.find('option:selected').remove();
                    $sel.find('option:selected').prevAll(":enabled").first().attr("selected","selected");
                    //console.log($sel.find('option:selected').nextAll(":enabled").first().attr('original-id'));
                    console.log(newValue);
                }

                // if we got a value, set it and update
                console.log(newValue)
                if (newValue != undefined) {
                    console.log("in the new value");
                    $sel.val(newValue);
                    $sel.trigger('change');
                    $.ajax({
                        type: 'GET',
                        url: '/admin/getProduct/'+newValue
                    }).then(function (data) {
                        console.log(data);
                        $('#altname').text('');
                        // create the option and append to Select2
                        //console.log("hello",data);
                       // $('#nickname').text(data.nickname);
                        //$('#used_by').text(data.used_at);
                        var alt_prod;
                        $.each(data.alt_prod, function(key,value) {
                            //console.log(key,value,alt_prod);
                            if(typeof alt_prod==="undifined")
                                $('#altname').append(value);//var alt_prod=value;
                            else
                                $('#altname').append(value+",");//alt_prod+=value+",";
                            //alert(value);
                        }); 
                        $('#nickname').text(data.nickname);
                        $('#used_by').text(data.used_at);
                        $('#altname').text(alt_prod);
                    });
                }
            }
        });

        $(document).ready(function() {
            var studentSelect = $('.js-example-basic-single');
            studentSelect.select2();
            studentSelect.on("select2:select", function(e) { 
                console.log($(this).val(),"on select");
            });
           
            $(".js-example-basic-single").select2({
                ajax: {
                    url: "/admin/getProducts",
                    type: "get",
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        //console.log("params",params);
                        return {
                            searchTerm: params.term // search term
                        };
                    },
                    processResults: function (response) {
                        //console.log(response);
                        var myselect = $('.js-example-basic-single');
                        //var barcodes = JSON.parse(response);
                        myselect.find('option').remove();

                        //console.log(response[0]);
                        for (var i = 0; i < response.length; i++) {
                            //console.log(i,"==i",response[i].nickname);
                            if(i==0)
                            {
                                $('#nickname').text(response[i].nickname);
                                $('#used_by').text(response[i].used_at);
                                $('#altname').text(response[i].alt_prod);
                                var options = ('<option value="' + response[i].id + '" original-id='+response[i].id+' selected>' + response[i].text + '</option>');
                            }
                            else
                            {
                                var options = ('<option value="' + response[i].id + '" original-id='+response[i].id+'>' + response[i].text + '</option>');
                            }
                            //var options = ('<option value="' + response[i].id + '">' + response[i].text + '</option>');
                            

                            myselect.append(options); // Missing this line
                        }
                        $('.js-example-basic-single').trigger('change');
                        //console.log("asd");
                        //$('#nickname').text(data.nickname);
                        //$('#used_by').text(data.used_at);

                        return {
                            results: response
                        };
                    },
                    cache: false
                }
            });
            
           
            
            studentSelect.on("select2:select", function (e) { 
                console.log("select2:select", e.params)
                $.ajax({
                    type: 'GET',
                    url: '/admin/getProduct/'+e.params.data.id
                }).then(function (data) {
                    $('#altname').text('');
                    // create the option and append to Select2
                    //console.log("hello",data);
                    $('#nickname').text(data.nickname);
                    $('#used_by').text(data.used_at);
                    var alt_prod;
                    $.each(data.alt_prod, function(key,value) {
                        //console.log(key,value,alt_prod);
                        if(key==0)
                        {
                            $('#nickname').text(response[i].nickname);
                            $('#used_by').text(response[i].used_at);
                        }
                        if(typeof alt_prod==="undifined")
                            $('#altname').append(value);//var alt_prod=value;
                        else
                            $('#altname').append(value+",");//alt_prod+=value+",";
                        //alert(value);
                    }); 
                    $('#altname').text(alt_prod);
                    
                    //var option = new Option(data.full_name, data.id, true, true);
                    
                });
                console.log(e.params.data.text);
                console.log(e.params.data.id);
            });
            
           
        });
    
    </script>
@stop