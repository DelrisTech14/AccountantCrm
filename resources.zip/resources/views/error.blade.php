@if(Session::has('success'))
    <div class="alert alert-success alert_flash_message">
        <button data-dismiss="alert" class="close">&times;</button>
        {{Session::get('success')}}
    </div>
@elseif(Session::has('success_with_data'))
    <div class="alert alert-success">
        <button data-dismiss="alert" class="close">&times;</button>
        {!! session()->get('success_with_data') !!}
    </div>
@elseif(Session::has('danger'))
    <div class="alert alert-danger alert_flash_message">
        <button data-dismiss="alert" class="close">&times;</button>
        {{Session::get('danger')}}
    </div>
@elseif(Session::has('warning'))
    <div class="alert alert-warning alert_flash_message">
        <button data-dismiss="alert" class="close">&times;</button>
        {{Session::get('warning')}}
    </div>
@endif
@if (Session::get('status') && Session::has('message'))
    <div class="alert alert-{{ Session::get('status') }}" alert_flash_message>
        <button data-dismiss="alert" class="close">&times;</button>
        {{ Session::get('message') }}
    </div>
@endif