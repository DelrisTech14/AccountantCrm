{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Demo2')

@section('content_header')
    <h1>Demo2</h1>
@stop

@section('css')
    <link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css') }}">
@stop

@section('content')
<div class="container">
    <div class="row">
        <div class="col-4 plr-0 pr-2">
            <div class="form-group">
                {{ Form::label('item_id', 'Item', ['class' => 'control-label']) }} <span class="text-danger">*</span> <span class="text-muted item_details_tooltip" data-toggle="tooltip" data-placement="top" data-html="true" title="" ><small>Details</small></span>
                <select class="form-control" id="item_id" name="line_items_data[item_id]"></select>
            </div>
        </div>
        <div class="col">
            <h5>Nick name</h5>
            <div id="nickname"></div>
        </div>
        <div class="col">
            <h5>Alternate product name</h5>
            <div id="altname"></div>
        </div>
    </div>
    <div class="row">
        <div class="col">
        </div>
        <div class="col">
            <h5>Product used at</h5>
            <div id="used_by"></div>
        </div>
        <div class="col">
        </div>
    </div>
</div>
@stop

@section('js')
    <script src="{{asset('vendor/select2/js/select2.min.js') }}"></script>
    <script>
    $("body").on('keyup', ".select2,.select2-dropdown", function (e) {
        var KEYS = {UP: 38, DOWN: 40};
        var $sel2 = $(this).closest(".select2");
        // if we can't find it by traveersing the dom, search page for an open container
        // ASSUMES only one open at a time - 
        // don't really know how to cross walk from dropdown back to coresponding element
        if ($sel2.length == 0) {
            $sel2 = $(".select2.select2-container--open");
        }

        // make sure we found the <select> el
        var $sel = $sel2.data("element")
        console.log($sel.length);
        if ($sel.length) {
            var newValue

            if (e.keyCode === KEYS.DOWN && !e.altKey) {
                console.log(KEYS.DOWN, "down");
                newValue = $sel.find('option:selected').nextAll(":enabled").first().val();
                console.log(newValue);
            } else if (e.keyCode === KEYS.UP) {
                console.log(KEYS.UP, "up");
                newValue = $sel.find('option:selected').prevAll(":enabled").first().val();
                console.log(newValue);
            }

            // if we got a value, set it and update
            console.log(newValue)
            if (newValue != undefined) {
                console.log("in the new value");
                $sel.val(newValue);
                $sel.trigger('change');
                get_item_data(newValue, newValue);
            }
        }
    });

    $(document).ready(function () {
        initAjaxSelect2($("#item_id"), "{{ URL::to('/item_select2_source') }}/?id=0");
        $('[data-toggle="tooltip"]').tooltip();

        $(document).on("select2:select", "#item_id", function (e) {
            //console.log("select2:select", e)
            get_item_data(e.params.data.id, e.params.data.text);
            console.log(e.params.data.text);
            console.log(e.params.data.id);
        });

    });

    function get_item_data(item_id, item_text) {
        if (item_id != '') {
            $.ajax({
                url: "{{ URL::to('/admin/get_item_data') }}/" + item_id,
                type: "GET",
                processData: false,
                contentType: false,
                cache: false,
                data: {},
                async: false,
                success: function (response) {
                    var json = $.parseJSON(response);
                    console.log(json);
                    var item_details_tooltip = '';
                    item_details_tooltip += '<em>Tooltip</em> <u>with</u> <b>HTML</b><br>' + json['location_1'];
                    $('.item_details_tooltip').attr('title', item_details_tooltip);
//                    $('.item_details_tooltip').tooltip().trigger('hover');
                    return false;
                },
            });
        }
    }

    </script>
@stop